# Devlog - accept-adr-030

- 2026-10-03: Accept ADR-030, which lets compass run start sessions (evidence: EV-T-AA-1, EV-CHECK-1)
