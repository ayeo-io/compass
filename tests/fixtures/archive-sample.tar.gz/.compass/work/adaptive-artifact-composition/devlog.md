# Devlog - adaptive-artifact-composition

## 2026-08-24 - re-assessment

- **Event:** Re-assessed from **initiative** to **feature**, recorded through
  the evaluator with a reason so `compass retro` sees it.
- **Measured before splitting, not after:** the rename half of this issue -
  `design.md`, `prd.md`, `distribution-map.md` - reaches 333 occurrences across
  100+ files, and 52 documents already on disk. It is now
  `artifact-filenames-rename-slice`.
- **What remains closes a promise the framework already makes.**
  `RP-REQUIRE-005` and `RP-REQUIRE-006` add a `threat-model` and a
  `rollback-plan` to an issue that earns one, and neither kind has a template.
  An auth issue is told it owes a threat model and given nothing to start from.
  That is the routing half shipping ahead of the writing half - the same error
  `the-human-front-door` corrected in its revision 3, one layer down.
- **Artifact:** `delivery-approach.md` revision 2, `task.yml`,
  `architecture-loaded.yml`, `README.md`.
- **Next:** define the acceptance criteria.

## 2026-08-24 - revision 3, the reframe

- **Event:** Scope set by research rather than by preference. Six sources -
  Martin, the ThoughtWorks Radar, the Threat Modeling Manifesto, Farley,
  *Design Docs at Google*, SWEBOK - and they converge: fewer documents, and the
  ones that survive produce something executable.
- **Three documents became one template plus a mechanism.** The threat model
  produces scenarios (Radar's "evil user stories" are Compass scenarios). The
  rollback plan produces a rehearsal record (Farley: the mechanism, not the
  document; SWEBOK: rehearsed before deploying). The test strategy is mostly
  already in `task.yml`.
- **`test-plan` and `release-plan` dropped.** Neither has a concise form worth
  borrowing, and writing one would be inventing a form. Martin's First Law of
  Documentation answers it: produce no document unless its need is immediate
  and significant.
- **An objection of mine that was wrong, recorded because it nearly changed the
  design:** I argued that moving work out of documents costs the review page
  its signal. It does not - the page already renders a scenario list and an
  evidence list, so the signal moves rather than disappears.
- **Approach re-checked, not assumed:** the evaluator reported "no route change
  detected" and declined to log a re-assessment. Correct - the work shrank but
  the dimensions read the same.
- **Next:** define the acceptance criteria.

## 2026-08-24 - acceptance criteria

- **Event:** 10 scenarios in four groups, traced to four intents. Nine are
  mechanical; TRC-D2 is narrative.
- **The criteria carry a table of where each borrowed shape came from**, with
  the quotes, so a reviewer can check the borrowing rather than my taste. That
  is the point of borrowing: a paraphrase is a fork of a standard with none of
  its authority.
- **The two scenarios that make the templates fail loudly rather than
  quietly:** TRC-A2 - a threat whose "what are we going to do about it" is
  empty shows as unanswered rather than as a completed row, which answers the
  Manifesto's "Admiration for the Problem" structurally. TRC-B3 - a rollback
  plan stating no rehearsal is reported, and an issue with no rollback plan
  reports nothing to check rather than passing.
- **TRC-D1 is the defect that opened the issue, stated so it cannot return:**
  every artifact kind the routing policy names must have a template. The policy
  gained two before either existed.
- **TRC-D2 is narrative and says why:** no test can observe whether a
  document's need was "immediate and significant". What is recorded instead is
  the decision - three of the five planned documents were dropped, with the
  reason.
- **Next:** requirements review, light weight per the approach.

## 2026-08-24 - requirements review

- **Event:** Five findings - one gap, four decisions - all resolved. 10
  scenarios became 11.
- **AMB-1 is a worked instance of S10.** The scan for "every kind the policy
  names" was written first with a hard-coded path that does not exist in the
  policy. It reported ZERO missing templates while two were missing. A
  recursive walk finds nine kinds and both gaps. The guard now fails when it
  finds nothing, rather than passing.
- **Two checks became one.** TRC-A2 and TRC-B3 both needed a guard on a
  filled-in document; one check under G4 reads whichever exists and reports
  what is unanswered. Less mechanism than two, and the freeze baseline gets one
  declaration instead of two.
- **The gap that would have embarrassed the issue:** every source cited argues
  for concision, the whole research thread was about not writing long
  documents, and nothing held either template to a length. TRC-D3 caps both at
  120 lines - measured against `prd.md` at 106 and `design.md` at 223, not felt.
- **The prediction was wrong; the approach is right.** §4c predicted one
  question and this found five, which is the trigger I wrote for re-assessing.
  Read honestly, the trigger was about the review needing more weight - it did
  not, all five were resolvable here, and the work got smaller. Recorded rather
  than buried: a triage guessing one and meeting five is what `compass retro`
  aggregates.
- **Definition of Ready:** all seven boxes checked.
- **Next:** design.

## 2026-08-24 - design

- **Event:** Six design decisions, each with what was rejected. Governance
  check passed, no guardrail crossed, no strategy departure. Five work units.
- **The load-bearing decision is D1:** the threat model's "what are we going to
  do about it" column holds a scenario id, not prose. That hands the work to
  machinery the framework already has - G1 forces a test on every scenario, G3
  forces a trace, and the evidence gate answers the Manifesto's fourth
  question. Its cost, stated: a threat cannot be recorded until a scenario
  exists for it, with `risk accepted` plus a reason as the deliberate escape.
- **D2 halves the mechanism:** one check reads both documents rather than one
  each, because both fail the same way - a section written and not answered.
  It returns NOTHING_TO_CHECK when neither file exists, since most issues earn
  neither.
- **D4 adds nothing to the vocabulary.** The `rollback-plan` evidence type
  already exists and its description is the problem: "a recorded plan for
  reverting a change safely". Amending what it demands is the same change with
  none of the mechanism, and the freeze test does not cover descriptions.
- **A shared surface named rather than discovered:** U2 and U4 both edit
  `guardrails.yml`, and both would want the version bumped. The bump happens
  once, in U4.
- **Evidence:** `compass design lint` PASS, `compass policy lint` PASS.
- **Next:** implementation. Solo - U1, U2, U3 in any order, then U4 and U5.

## 2026-08-24 - implementation and verify

- **Event:** Two templates, one module, one description, one design section.
  All six gates GREEN. Suite 1316 -> 1326.
- **The templates came in at 81 and 79 lines** against a 120 cap - room for a
  worked example, not for a form.
- **Thirteen mutations, four missed on the first pass, and three shared one
  cause worth naming as a class:** the guard read the template's INSTRUCTIONAL
  COMMENT rather than what the section asks for. Both templates open with a
  block quoting their sources, so those blocks contain "rehearsal", "scenario"
  and "evidence" whatever the headings say. Two guards passed with their
  headings renamed away; a third passed with its opening clause reverted
  because the quotation after it still said "rehearsed". They now strip
  comments before asserting.
- **The fourth was the budget-nothing-can-breach shape:** raising the 120-line
  cap to 10,000 changed nothing observable, because the templates are 81 and 79
  lines. The cap is now bounded against `design.md`'s own length.
- **The terminology guard caught a bare guardrail code in my own template**,
  which is ADR-017 working on the person who has been writing about it all
  week.
- **checks.py breached its size cap**, and the honest answer was the same as
  last time: the check reads two templates and nothing else in that file
  touches them, so it moved to `borrowed_docs.py` beside them.
- **Evidence:** EV-MUT-1, EV-CHK-1, EV-REVIEW-1.
- **Next:** ship.
