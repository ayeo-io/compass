# Delivery approach - assess-before-edit-under-conflict

**Approach:** spike · **Assessed:** 2026-09-29 · **Gates:** 1 (`spike.conclude`)

| Dimension | Value | Why |
|---|---|---|
| Risk | `contained` | Measurement only; no shipped code or text changes. |
| Familiarity | `brownfield-mapped` | The harness, the judge and D38's run records were read on 29 September. |
| Size | `small` | Ten eval sessions and a written finding. |
| Goal and role | `exploration`, engineer | a planning spec: it is not yet known whether there is a regression or what caused it. |

The spike runs `conflicting-instruction` under Compass, 5 times at the
commit before B3 (`93387c2`) and 5 times at the commit between B3 and B11
(`51b9343`), each from its own worktree, and scores those and D38's five
with both judges. The maintainer approved the spend on 29 September. It
concludes with a written finding; any fix is its own spec.
