<!-- compass: moved -->
# Moved

This issue's delivery-approach.md is now at:

    docs/compass/2026-08-12-ci-lints-every-issue/delivery-approach.md

The manifest's `artifacts:` registry names that path, and every
current reader asks the registry. This file is here only so a
Compass installed before the registry existed still finds
something at the old name instead of blocking every code edit.

Delete it once every install reading this project is current.
