# Devlog - ci-lints-every-issue

> **Issue:** The sweep skips schema linting for not-yet-started issues, then claims every issue lints clean. · **Opened:** 2026-08-12

---

## 2026-08-12 15:00 - Triage

- **Event:** found by the PR #43 review, re-reproduced here. A spine with `schema_version: "9.9"` and `risk: nonsense-value` gets `compass ci: PASS - governance valid; every issue lints clean and checks green`, while `compass issue lint` rejects it outright.
- **Approach:** feature - see `delivery-approach.md`. RG-FLOOR-006 added the fitness gate.
- **Whose defect it is:** mine, from `sweep-respects-queued`, earlier in this same release. The `continue` was placed above `cmd_task_lint` as well as `cmd_check`. The justification I wrote for it - that the acceptance criteria and evidence do not exist yet - is true of the check and not of the lint, which validates the spine's structure at any stage.
- **The sharper half:** `status: parked` is now a one-word way to remove an issue from the sweep, and the summary still reports everything clean.
- **The class, again:** a check reporting success while checking nothing, introduced by the fix for another member of the same class. That is the pattern the next cycle is framed around, arriving before the cycle does.
- **Next:** define acceptance criteria, then a red on the false PASS.

## 2026-08-12 12:41 - edit: <project>/tests/test_ci_lints_every_issue.py

- **Tool:** Write

## 2026-08-12 12:42 - edit: <project>/cli/compass_pkg/analyze.py

- **Tool:** Edit

## 2026-08-12 12:43 - edit: <project>/tests/test_ci_lints_every_issue.py

- **Tool:** Edit

## 2026-08-12 15:40 - Verify and ship

- **Fixed:** the lint runs for every issue at every stage; only the gate checks are skipped for work that has not started. The summary carries counts. On this repository it now reads "70 issue(s) fully checked, 9 lint-only (not in flight)" where it used to claim every issue was clean.
- **The control earned its place.** TRC-2 asserts a well-formed queued issue still passes. Without it, TRC-1 would pass against a sweep that failed everything - which would undo `sweep-respects-queued` and put back the defect where framing work early reddens the build. The fix had to hold both properties at once, and only the pair proves it does.
- **One test assertion was adjusted, and it is worth saying so.** TRC-3 originally asserted the word "skipped" appeared in the summary; the implementation chose clearer wording and the test failed on phrasing rather than on the property. The assertion now looks for the counts the scenario asks for. The scenario did not change - only the proxy the test used for it. Changing a test to match an implementation is the kind of thing that should never pass unremarked.
- **Next:** the empty-quote hole in `verify-archive-quotes.py`, then the five cannot-fail tests.
