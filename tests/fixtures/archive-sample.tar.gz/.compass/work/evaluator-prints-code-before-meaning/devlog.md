# Devlog - evaluator-prints-code-before-meaning

## 2026-08-23 - verified as already fixed, closed without a change

Picked up as third of four. **The defect was already fixed.** Closed after
verifying it rather than on the strength of one look at the output.

## What the bug report asked for, and what is true today

**1. Meaning first, code in brackets - FIXED.**

The report quotes the defect as:

```
    [RP-FLOOR-002] floor: You cannot safely change behaviour you have not first written down.
```

It prints today as:

```
    Critical changes coordinate, or they break things quietly (RP-FLOOR-001, floor)
        - approach raised feature -> initiative
```

Landed 2026-08-16 in `f9c03bd`, "Print the meaning before the code on the
evaluator's screen too" - the same day this issue was filed, and after it. The
fix carries a comment in `cli/compass_pkg/routing.py` naming this exact
situation: the receipt's renderer was corrected and this one was missed, and the
two print the same data through different code, which is how they came apart.

**2. The bare `floor` / `requirement` / `role_rule` labels - DECIDED, not
removed.**

The report asked for this to be "decided in the same pass". It was, and the
reasoning is recorded beside the code:

> The KIND stays. It says whether the rule raised the whole approach or only
> attached a single gate, and an earlier issue exists because every entry in the
> floors block reported itself as a floor including the four that only add a
> gate. Dropping it to shorten the line would have quietly undone that work.

So the label is still bare to a first-time reader, and that is a choice with a
reason rather than an oversight. Anyone who disagrees is disagreeing with a
recorded decision, which is the state this project asks for.

**3. The printed-output guard covers this command - CONFIRMED.**

`tests/test_plain_language.py` checks both screens - the evaluator and the
receipt - through the same assertion, so they cannot come apart the way they did
before. Its own comment records a brittle-matcher failure it already survived:
an earlier pattern demanded a closing bracket immediately after the code and
failed against a correct line.

## Proved rather than assumed

The report says "prove it can fail before counting it done." Done, on a
disposable copy: the renderer was reverted to `[RP-FLOOR-002] floor: ...`,
exactly as the report quotes the defect, and the guard **failed**. Restored, it
passes. The guard is connected to the thing it names.

## Why the status is `abandoned` and not `landed`

Marking it `landed` was the first attempt and `compass check` refused it -
`scenarios-have-tests`, `suite-passed`, `scenario-has-id-and-intent` and
`gate-evidence-present` all failed, because **`landed` asserts an issue cleared
its gates and this one cleared none.** Land is a record, not a rubber stamp.

`abandoned` is the honest state: this issue will not be resumed, because there
is nothing left in it to do. The defect it describes was fixed by `f9c03bd`
under different work. Recording it as landed would put a fifth entry on the pile
of issues this project already has whose status claims a verification that never
happened.

## Closed with no change

Nothing was committed. The working tree is untouched; this issue is a record
that the defect it describes was fixed by `f9c03bd` and is now guarded.

**The re-capture note in the report still stands** and is not this issue's to
settle: the demo's second shot is built on this screen, and the shot shows the
old wording. The demo script's re-capture list is where that lives.
