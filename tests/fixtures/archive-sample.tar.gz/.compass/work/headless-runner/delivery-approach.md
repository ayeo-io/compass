# Delivery approach - headless-runner

**Approach:** initiative · **Assessed:** 2026-10-03

| Dimension | Value | Why |
|---|---|---|
| Risk | `cross-cutting` | The first CLI verb that starts a host process. It needs an ADR that makes an exception to ADR-025, and it changes the eval harness's launcher. |
| Familiarity | `brownfield-mapped` | `evals/harness.py` already launches `claude -p`, and its tests pin it. |
| Size | `large` | A new verb with a loop, ceilings, a stop file, redaction and a run record; a launcher moved out of the harness; an ADR; a reference workflow; docs. Estimated up. |
| Goal and role | `delivery`, engineer | a planning spec, from a private analysis (intent 4, headless runner). |

## Policy rules fired

- RP-REQUIRE-003: architecture checked before cross-cutting or critical changes land. It adds the `verify.architecture` gate.

## Stages

Every stage runs at full weight, and breakdown is multiagent. No stage is skipped or collapsed.

## Gates

verify.correctness, verify.governance, verify.traceability, verify.regression, verify.security, verify.clarity, verify.claims, verify.architecture.

## Orchestration

One builder, solo, recorded as one subtask. The runner, the launcher and the tests share the launcher's interface, so a second builder would wait on the first.

## Scope set by the architect's ruling

The maintainer is offline. The compass:architect agent ruled on their behalf (`.compass/rulings/headless-runner.md`), and this issue follows it:

- Build `compass run`, its ADR, the ceilings, the stop file, redaction and the run record, tested against a stub `claude` executable.
- No live run and no secret. The reference workflow goes under `ci/`, started only by hand, and is not active.
- The spec's first acceptance, a quick-fix example run assess-to-ship in CI, is not met here. It waits for the maintainer.

Touches `cli/`, so it goes through a PR. Stop at the first passing review.
