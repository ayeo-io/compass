# Claims - headless-runner

This change makes no public claim. README.md gains one line in its CLI block naming `compass run`, which is a description of a verb, backed by HR-A to HR-J. `docs/headless-runner.md` states plainly that the live acceptance is not met. No positioning or launch text claims unattended runs in CI.
