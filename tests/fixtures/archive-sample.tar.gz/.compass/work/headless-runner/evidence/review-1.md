Verdict: FAIL

# Review - headless-runner (`compass run`)

The runner does most of what acceptance criteria HR-A to HR-J ask for, and its 20 tests pass. It fails the gate for six reasons, each reproduced:

1. Six existing tests that pin the top-level CLI verb set now fail (regression).
2. A credential that straddles the 2,000-character error tail leaks in part into the run record (security).
3. A second run reuses run number 1 and overwrites the first run's record, including the only record of a fail-closed stop (correctness, traceability).
4. After a timed-out session, the runner overwrites the manifest that session wrote with a stale copy (correctness).
5. The minute ceiling ends the `claude` process but not the processes it started (correctness, HR-H).
6. The test guard that criterion HR-F names cannot fail when a `claude` other than the stub runs (correctness, HR-F).

Scope of this review: `git diff HEAD` in the worktree `.compass-worktrees/headless-runner`, the criteria, the technical design and the requirements review in `docs/compass/2026-10-03-headless-runner/`, and `tests/test_headless_runner.py`. Every probe used a stub `claude`. The real `claude` was never run.

How the probes ran: a scratch script built a project as the test fixture does, with a stub `claude` that does one scripted thing per call, then ran `cli/compass run`.

## Regression

**issue (blocks)** - six tests that pass on `main` fail with this change. Each pins the set of top-level CLI verbs, and `run` is a new one.

- `tests/test_cli_surface_drift.py::test_trc_a1_readme_cli_block_tracks_compass_help` - the `README.md` CLI block does not list `compass run`.
- `tests/test_governance_drift_noop.py::test_trc_f6_the_framework_should_grow_by_artifacts_and_checks_only`
- `tests/test_phase2_invariants.py::test_trc_f3_the_framework_should_grow_by_artifacts_and_checks_only`
- `tests/test_fresh_eyes_verify_sweeps.py::test_trc_f1_no_new_gate_guardrail_check_cli_verb_or_vocabulary`
- `tests/cross_cutting/test_stream_d_invariants.py::test_trc_d2_only_two_new_public_cli_verbs`
- `tests/test_bdd_extract.py::test_trc_a6_bdd_is_on_the_documented_subcommand_surface`

Reproduced by running the full suite (`pytest -n 8 tests`) on `main` (d7b3b83) and in the worktree, then diffing the failure lists. These six are the only difference. Other failures (`test_quick_fix_verbs.py`, `test_red_must_show_a_failure.py`, three in `test_eval_harness.py` and others) fail on `main` too in this environment, so they are not counted against this change.

The fix is not only to add `run` to six lists. These tests record a rule that the framework grows by artifacts and checks, not by verbs. Adding `run` to their expected sets needs a sentence in each saying why, and ADR-030 should say it sanctions a new top-level verb.

The change has no full-suite record in `evidence/`. Only the per-scenario red and green runs are there, which is why these were not seen.

## Security

**issue (blocks)** - `cli/compass_pkg/run_cmd.py:231` cuts the error output to its last 2,000 characters and then redacts. A credential that starts before the cut loses its recognisable prefix, so neither the shape list nor the environment-value match finds it.

- Reproduced with a stub that writes 5,000 characters, then a 93-character `sk-ant-api03-...` token, then 1,950 more to standard error, and exits 1. The run record held the last 50 characters of the token and no `[REDACTED]` mark.
- Fix: redact the whole of `launched.stderr`, then cut the tail.

**suggestion** - `run_cmd.py:50-51` denies `git push`, `gh pr merge` and `compass ship-commit` by prefix. Prefix rules do not cover `git -C . push` or `compass issue set-status ... landed`, which also lands an issue. The after-cycle landed check (`run_cmd.py:244`) catches a landing, but only after it happened. `docs/headless-runner.md:36` says these commands "are denied to it". It should say this is a prefix list, and that the landed check is the backstop. I have not checked how a real `claude -p` session in `acceptEdits` mode treats these forms.

**suggestion** - `cli/compass_pkg/redact.py:28-36` does not cover credentials in a URL (`https://user:pass@host`) or `Authorization: Basic ...`. Neither is in the HR-E list, so this does not block. Reproduced by calling `redact` on both forms: both came back unchanged.

**suggestion** - `ci/headless-verify.yml:36`: `actions/checkout@v4` leaves the job's GitHub token in `.git/config`, where the session can read it. Add `persist-credentials: false`. `permissions: contents: read` already stops a push.

Checked and sound:

- The slug cannot escape `.compass/work/`. `resolve_issue_dir` refuses anything that is not one path segment (`core.py:202-215`).
- The runner itself runs no `git` command and never pushes or lands. Read from `run_cmd.py`.
- The stop file path is only tested with `os.path.exists`. Where it appears in the record and the manifest, it is redacted, and the manifest is written with `yaml.safe_dump`.
- Every `HR-E` shape is redacted: `ghp_`, `gho_`, `ghs_`, `github_pat_`, `AKIA`, bearer, `key=value`, `"api_key": "..."` and secret-named environment values. Checked by calling `redact` on each.
- The HR-E test fails with redaction switched off. Checked with a `sitecustomize.py` that replaces `redact` with the identity function: `assert TOKEN not in text` failed. The recorded red for HR-E (`evidence/red-HR-E.json`) fails because the verb did not exist yet, not because redaction was off. This review supplies the evidence the criterion asks for.

## Correctness

**issue (blocks)** - `run_cmd.py:201-202` and `:167-170`. The run number is the length of the manifest's `runs:` list plus one, and the record is opened with mode `w`. A run that stops on an unreadable manifest writes `run-1.md` but no `runs:` entry, by design. The next run is also number 1 and overwrites that record.

- Reproduced: a stub that corrupts the manifest gave `run-1.md` saying "the manifest cannot be read after cycle 1". After the manifest was restored and a second run started, `run-1.md` said "the stop file ... exists". The first record was gone, and it was the only trace of the fail-closed stop.
- Two runs of the same issue started together also collide. Reproduced with two runs whose stub sleeps for 3 seconds: the manifest held one `runs:` entry (`n: 1`) and one record. One run left no trace.
- Fix: number from the highest of the existing `run-*.md` files and `runs:` entries, open the record with mode `x`, and refuse a second run of the same issue while a lock file exists.

**issue (blocks)** - `run_cmd.py:270-274`. When the loop ends on a timeout, the runner re-reads the manifest and, if that fails, saves the copy it read before the session. A session that wrote an unreadable manifest and then timed out has its write replaced, without notice, by the old content. The record gives the reason as the minute ceiling, not as an unreadable manifest.

- Reproduced with a stub that writes `issue: [unclosed` to the manifest and then sleeps, run with `--max-minutes 0.03`. The run exited 4 with "the minute ceiling ... is reached", and the manifest was back to its pre-session content.
- This breaks the rule that the runner fails closed on a manifest it cannot read (HR-G). Fix: when the final read fails, do not write the manifest, and record the unreadable manifest as the reason.

**issue (blocks)** - `cli/compass_pkg/host_launch.py:37-46`. A timeout kills the `claude` process only. Any process it started keeps running after the run has recorded itself and exited, and can still write to the manifest and the evidence.

- Reproduced with a stub that starts `sleep 20` and then sleeps itself, run with `--max-minutes 0.03`. The runner exited 4 in 1.9 seconds, and `pgrep` still showed the `sleep 20` process.
- HR-H and `docs/headless-runner.md:32` say the session is ended. Fix: start the process with `start_new_session=True` and kill its process group on timeout.
- I have not checked how a real `claude` lays out the processes it starts for its tools.

**issue (blocks)** - `tests/test_headless_runner.py:131-139`, with the claim at `:9-12`. The guard `_calls` compares the stub's log lines with the stub's markers. The stub writes both, so a `claude` that is not the stub writes neither, and the guard passes with 0 = 0. HR-F asks for "a guard [that] fails the tests if anything but the stub ran".

- Reproduced with a copy of the test file that passes `--claude /usr/bin/true`. A probe test started one cycle, and `_calls(project) == []` passed. The refusal tests (HR-A) and the stop-file-at-start test (HR-C) also passed. Those are exactly the tests where a wrongly started session would cost money.
- Tests that assert a call count do catch it, so the gap is in the guard, not in every test. Fix: assert that the run record's "Session executable" line, or the resolved `claude`, is the stub's path.

**issue (does not block)** - `run_cmd.py:273`. A session that writes `runs: oops` into the manifest makes the runner crash with `AttributeError: 'str' object has no attribute 'append'`, exit 1. That exit code is outside the documented 0, 2 and 4. The record is written but the manifest entry is not. Reproduced with a stub that appends that line. Not blocking: a session has to corrupt one specific key.

**question** - a session that deletes the `evidence/` folder counts as progress, because the evidence digest changes. A verify run is done when every gate in the manifest says `pass`, whatever the evidence holds. Both match HR-D and HR-G as written. Is that the intended meaning of "done" for an unattended verify run? Reproduced with a stub that alternately writes and deletes the evidence folder: the run went on to the cycle ceiling.

Checked and sound:

- A manifest that becomes a YAML list stops the run (exit 4) and is left as the session wrote it.
- A session that deletes the whole issue directory stops the run (exit 4), and the record is written.
- A partial output on timeout is decoded from bytes (`host_launch.py:42-46`), so it does not crash the runner.
- The digest leaves out `runs:` (`run_cmd.py:108`), so the runner's own write does not count as progress.

## Clarity

**issue (does not block)** - `ci/headless-verify.yml:10-13` says a run "leaves its record in the issue's documents for a person to read". In a CI job the record is written on a runner machine that is discarded when the job ends. No step uploads it or commits it. Reproduced by reading the workflow: it has no upload step. Not blocking, because the workflow is a reference and is not active. It must be fixed before anyone copies it.

**issue (does not block)** - `docs/headless-runner.md:16` does not say that a relative `--stop-file` path is read from the project root, not from the current directory. The stop reason repeats the path as given (`run_cmd.py:213`), so the record does not say which file was checked either.

- Reproduced by running from `src/` with `--stop-file STOP` while `src/STOP` existed. The run started 2 sessions and stopped at the cycle ceiling.
- The behaviour follows the requirements review's answer to its question about stop-file paths. The doc should state it, and the reason should name the resolved path.

**suggestion** - `run_cmd.py:80-82`. With a project `governance/` copied from before this change, the refusal reads "compass: compass run: routing-policy.yml sets no cycle ceiling ... Add the `loop_ceilings` rule." A reader cannot tell which rule to add or which file to add it to. Name `run_cycles` and `run_minutes`, the rule ids, and the file path. Reproduced by copying `main`'s `governance/` into a probe project. The prefix repeats "compass" twice, as other verbs' errors do.

**suggestion** - `cli/compass_pkg/loop_ceilings.py:3-10` still describes "the loop ceilings of a multiagent run" and lists four ceilings. It now also holds the two `compass run` ceilings. Its owning doc, `docs/multiagent-protocol.md`, has no mention of them. Read from the files.

**nitpick** - `docs/headless-runner.md:17`, `:18` and `:30` put a rule id in front of its meaning: "the RP-LOOP-006 ceiling, 30". Write "the cycle ceiling in the routing policy, 30 (RP-LOOP-006)". Keep the ids, because the checks read them.

**nitpick** - `docs/headless-runner.md:3` names ADR-030 without a link. Link it to `architecture/decisions/ADR-030-compass-run-starts-host-sessions.md`.

House rules: no em dash, no agent attribution and no US spelling in the added lines. Checked with `grep` over `git diff HEAD`. `scripts/voice-tells.py` over the new docs and the issue documents reports clean.

## Architecture

- **praise** - the ADR-025 and ADR-030 boundary is clean. Only `compass run` starts a session. The orchestrator and the hooks are untouched. ADR-030 stays `proposed` and says plainly that accepting it is the maintainer's decision.
- **praise** - the launcher is shared without a change in behaviour for the eval harness. `evals/harness.py` builds the same argument list in the same order, and passes no timeout, as before. The AST check in `tests/test_eval_harness.py` counts `launch_claude` as starting a process, so the harness's existing process-start test still means what it did. HR-I passes. The three harness failures fail on `main` too.
- ADR-006 backward compatibility holds. `runs:` and the two ceiling names are additive in both schemas. An older manifest still validates (`issue lint` passes in HR-B). An older project `governance/` is refused by `compass run` only, with exit 2. That is fail-closed for a new verb, not a break of an old one.
- The new top-level verb is the open architecture point. It is covered under Regression above.
- **nitpick** - `tests/test_headless_runner.py:339-340` adds to `sys.path` without undoing it. Use `monkeypatch.syspath_prepend`.

## Traceability

Every criterion from HR-A to HR-J has a test, and a red and a green record in `evidence/`. Two of those records do not prove what the criterion says:

- The HR-E red does not show the test failing with redaction off. This review checked it instead (see Security).
- The HR-F green rests on a guard that cannot fail (see Correctness).

The record-overwrite defect breaks the record-to-run chain: `stopped_reason.evidence` can name a `run-<n>.md` that a later run has overwritten.
