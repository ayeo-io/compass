Verdict: FAIL

# Review round 2 - headless-runner (`compass run`)

All six blocking findings from round 1 are fixed, and I reproduced each fix against the new code. Two of the round-2 fixes add a defect of their own, and both block:

1. Interrupting a run leaves its `claude` session running after the runner has exited and released the lock (`cli/compass_pkg/host_launch.py:51-63`).
2. A session that deletes the issue folder or `run.lock` makes the runner crash with exit 1, where round 1 stopped cleanly with exit 4 (`cli/compass_pkg/run_cmd.py:216-217`).

Both fixes are a few lines.

Scope: `git diff HEAD` in the worktree `.compass-worktrees/headless-runner`, read in full again. The round-1 report is kept as `review-1.md`. Every probe used a stub `claude`; the real `claude` was never run. The probes ran a scratch script that builds a project as the test fixture does, with a stub that does one scripted thing per call.

## Round-1 blockers, rechecked

| Round-1 finding | Result now | How it was checked |
|---|---|---|
| Six tests that pin the verb list failed | Fixed | The six tests pass. The full suite (`pytest -n 8 tests`) gives the same failure set as `main` (d7b3b83): 98 lines on each, none only in the worktree. Those failures come from this environment, not from the change. |
| A credential cut by the 2,000-character tail leaked in part | Fixed | The 93-character token probe from round 1: no part of the token is in the record, and `[REDACTED]` is. |
| A later run reused run number 1 and overwrote its record | Fixed | After an unreadable-manifest stop, the next run wrote `run-2.md`, and `run-1.md` kept its original reason. |
| Two runs at once lost one run's trace | Fixed | A second run started 0.8 seconds after the first was refused with exit 2, naming `run.lock`. The first run finished, and the lock was removed. |
| A timed-out session's broken manifest was overwritten | Fixed | The manifest kept the session's `issue: [unclosed` text. The reason given is "the manifest cannot be read". |
| A timeout left the session's child processes running | Fixed for an ordinary child | A stub that starts `sleep 20`: no `sleep` process remained after the run. |
| The stub guard could not fail | Fixed | `_calls` now also compares with the cycle rows in the run records. The new test `test_hr_f_the_guard_fails_when_another_claude_runs` shows the guard failing when `/usr/bin/true` runs. |

## Correctness

**issue (blocks)** - `cli/compass_pkg/host_launch.py:51-63`. With a timeout, the session now starts in its own process group (`start_new_session=True`), and only `TimeoutExpired` kills that group. Any other exception that leaves `communicate` does not end the session. That includes `KeyboardInterrupt`, from Ctrl-C or the `SIGINT` a CI cancel sends.

- Because the session is in its own group, Ctrl-C at the terminal no longer reaches it either.
- The runner then exits, and `run_cmd.py:216-217` removes `run.lock`. A second run can start while the first session is still working on the same issue.
- Before this round, `subprocess.run` killed the child on any exception: its `except:` branch calls `process.kill()`, as read from the venv's `subprocess.run` source.
- Reproduced: I sent `SIGINT` to a runner whose stub sleeps for 25 seconds and then writes to `evidence/`. The runner exited 130, the lock was gone, and the stub's process was still alive.
- Fix: catch `BaseException` around `communicate`, kill the group, and re-raise. Also handle `SIGTERM`: the round-2 probe showed `SIGTERM` leaves both the lock and, by the same path, the session.

**issue (blocks)** - `cli/compass_pkg/run_cmd.py:216-217`. `os.remove(lock)` in the `finally` block raises `FileNotFoundError` when the lock is already gone. That replaces the run's exit code with a traceback and exit 1.

- Reproduced in two ways:
  - A stub that deletes the whole issue folder: in round 1 this stopped cleanly with exit 4. It now prints the stop line and then a `FileNotFoundError` traceback, and exits 1.
  - A stub that deletes only `run.lock`: the run reaches its cycle ceiling and writes its `runs:` entry, then exits 1 with the same traceback.
- Fix: ignore `FileNotFoundError` when removing the lock.

**issue (does not block)** - `host_launch.py:61`. After the group is killed, `proc.communicate()` waits with no timeout. A process that left the group (a `setsid` daemon) and still holds the output pipes keeps the runner waiting until that process exits.

- Reproduced with a stub that starts a 15-second child with `start_new_session=True`, run with `--max-minutes 0.03`. The run took 15.5 seconds instead of about 2.
- Not blocking: a process has to leave its group on purpose. A short timeout on the second `communicate`, then closing the pipes, would bound it.

**issue (does not block, carried over)** - `run_cmd.py:322`. A session that writes `runs: oops` still crashes the runner (`AttributeError`, exit 1). Reproduced again.

**note** - a run killed with `SIGTERM` or `SIGKILL` leaves `run.lock`, and the next run is refused with exit 2 until a person deletes it. Reproduced with `SIGTERM`. `docs/headless-runner.md:23` documents this, so it does not block. Fixing the first blocker's `SIGTERM` half would remove the common case.

**question (carried over)** - a session that deletes `evidence/` still counts as progress, and a verify run is still done when the manifest's gates say `pass`, whatever the evidence holds. Is that the intended meaning of "done" for an unattended verify run?

## Security

- The tail redaction is fixed (see the table above).
- **praise** - `docs/headless-runner.md:38` now says the deny list matches by how a command starts, gives `git -C . push` as a form it misses, and says the after-session landed check is what stops a landing.
- **suggestion (carried over)** - `redact.py` still does not cover credentials in a URL or `Authorization: Basic`. Neither is in the criteria.
- **suggestion (carried over)** - `ci/headless-verify.yml:36` still has no `persist-credentials: false`, so the job's read-only token stays in `.git/config`. Checked with `grep`.
- Slug confinement and the runner's own lack of `git` calls are unchanged since round 1.

## Clarity

- Fixed:
  - The workflow uploads `docs/compass/*/run-*.md` with `if: always()`.
  - The doc says a relative stop file is read from the project root, and describes the lock.
  - The missing-ceiling refusal names RP-LOOP-006 (`run_cycles`), RP-LOOP-007 (`run_minutes`) and the file.
  - The header of `loop_ceilings.py` names the run ceilings.
- **nitpick (carried over)** - `docs/headless-runner.md:17-18` and `:32` still put the rule id before its meaning ("the RP-LOOP-006 ceiling, 30"). Write "the cycle ceiling in the routing policy, 30 (RP-LOOP-006)".
- **nitpick (carried over)** - `docs/headless-runner.md:3` names ADR-030 without a link.
- House rules hold: no em dash, no agent attribution and no US spelling in the added lines (checked with `grep` over `git diff HEAD`). `tests/test_house_style.py` and `tests/test_terminology.py` pass, and `scripts/voice-tells.py` reports clean.

## Architecture

- **praise** - ADR-030 now says it adds a top-level verb, and each of the six verb-list tests names it as the reason. The ADR-025 boundary is unchanged: only `compass run` starts a session.
- The launcher change keeps the eval harness on its old path. Without a timeout, `launch_claude` still calls `subprocess.run`, so the harness behaves as before. The harness tests give the same result as on `main`.
- ADR-006 backward compatibility holds as in round 1.
- **nitpick (carried over)** - `tests/test_headless_runner.py:363-364` add to `sys.path` without undoing it.

## Traceability

Each round-2 fix has a test, added at the end of `tests/test_headless_runner.py`, and all 31 tests in the runner file and the six verb pins pass. The guard behind criterion HR-F can now fail, and the HR-E tail case is tested. No test covers either new blocker:

- an interrupted run;
- a session that deletes the lock or the issue folder.
