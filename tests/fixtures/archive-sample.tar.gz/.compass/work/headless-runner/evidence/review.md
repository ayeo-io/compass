Verdict: PASS

# Review round 3 - headless-runner (`compass run`)

Both round-2 blockers are fixed, and I reproduced each fix against the new code. The round-3 changes add no blocking defect. Four non-blocking findings remain, listed below.

Scope: `git diff HEAD` in the worktree `.compass-worktrees/headless-runner`, including the SIGTERM handler added in `cli/compass_pkg/run_cmd.py:220-228`. Earlier rounds are kept as `review-1.md` and `review-2.md`. Every probe used a stub `claude`; the real `claude` was never run. The probes ran a scratch script that builds a project as the test fixture does, with a stub that does one scripted thing per call.

## Round-2 blockers, rechecked

| Round-2 finding | Result now | How it was checked |
|---|---|---|
| An interrupted run left its session running | Fixed for SIGINT and SIGTERM | I started a run whose stub records its pid and sleeps for 25 seconds, then sent the signal to the runner only. With SIGINT the runner exited 130; with SIGTERM it exited 143. Both times the stub's process was gone and `run.lock` was removed. |
| Removing a lock that was already gone crashed the run | Fixed | A stub that deletes the issue folder: exit 4, "the manifest cannot be read". A stub that deletes only `run.lock`: exit 4 at the cycle ceiling, with the `runs:` entry written. No traceback in either case. |

The SIGTERM test catches a missing handler. I made `signal.signal` ignore SIGTERM through a `sitecustomize.py`, and `test_hr_h_an_interrupted_run_ends_its_session[SIGTERM]` failed. Without that change both cases pass.

## Regression

- The full suite (`pytest -n 8 tests`) gives the same failure set as `main` (d7b3b83): 98 lines on each, none only in the worktree. The failures come from this environment: three in `test_eval_harness.py`, and others in `test_quick_fix_verbs.py`, `test_red_must_show_a_failure.py` and `test_tdd_red_integrity.py`.
- All tests in `tests/test_headless_runner.py` pass, as do the six tests that pin the verb list.
- I re-ran every earlier probe against the new code, and all hold:
  - a credential cut by the tail;
  - record numbering after an unreadable-manifest stop;
  - two runs at once;
  - a timed-out session that breaks the manifest;
  - a timed-out session's child process;
  - a manifest that becomes a list.

## Correctness

**issue (does not block)** - a run that is interrupted leaves an empty run record and no `runs:` entry. `_reserve_record` creates `run-<n>.md` empty at the start, and an interrupt exits before `_write_record` runs.

- Reproduced: SIGTERM during the first session gave exit 143, a `run-1.md` of 0 bytes and no `runs:` entry.
- The session is ended, so nothing is unsafe. A reader just finds an empty file with no reason in it.
- Fix: write a stopped record in the `finally` block.

**issue (does not block)** - `run_cmd.py:318-336`. When the last session both finishes the stage and breaks `runs:`, the record says "Outcome: done" while the run prints "stopped" and exits 4. The record was written before the outcome changed, and the note appended below it does not correct the outcome line.

- Reproduced with a stub that adds a passing gate and `runs: oops` in one session.

**suggestion** - `run_cmd.py:192`. An empty `runs:` key (YAML null) is refused at start as "not a list". Reproduced: exit 2. Compass never writes that form, so this matters only for a hand-edited manifest. Treating null as an empty list would accept it.

**issue (does not block, carried over and accepted as a documented limit)** - `host_launch.py:61`. A process that leaves the session's process group and keeps the output pipes open holds the runner until it exits. The coordinator chose not to change this, and process groups cannot reach such a process.

**question (carried over)** - a session that deletes `evidence/` counts as progress, and a verify run is done when the manifest's gates say `pass`. That matches criteria HR-D and HR-G as written. The maintainer may want a stricter meaning of "done" for unattended runs.

## Security

- `ci/headless-verify.yml:38` now checks out with `persist-credentials: false`. Read from the file.
- The redaction fix from round 2 still holds (see Regression).
- **suggestion (carried over)** - `redact.py` does not cover credentials in a URL or `Authorization: Basic`. Neither is in the criteria.
- The ADR-030 boundary is unchanged: the runner itself runs no `git` command and never lands. The SIGTERM handler is installed only for the run, and the previous handler is restored afterwards (`run_cmd.py:223-228`).

## Clarity

- **nitpick (carried over, not changed by choice)** - `docs/headless-runner.md:17-18` and `:32` put the rule id before its meaning ("the RP-LOOP-006 ceiling, 30").
- **nitpick (carried over)** - `docs/headless-runner.md:3` names ADR-030 without a link.
- House rules hold: no em dash and no agent attribution in the added lines, checked with `grep` over `git diff HEAD`. `scripts/voice-tells.py` reports clean.

## Architecture

- The launcher keeps the eval harness on its old path: without a timeout it still calls `subprocess.run`. The harness tests give the same result as on `main`.
- ADR-006 backward compatibility holds as in earlier rounds.
- **nitpick (carried over, not changed by choice)** - `tests/test_headless_runner.py` adds to `sys.path` without undoing it.

## Traceability

Each fix since round 1 has a test at the end of `tests/test_headless_runner.py`, and each new test fails without its fix. I checked that for the SIGTERM handler here, and for redaction in round 1. Criteria HR-A to HR-J are met against a stub `claude`. The live acceptance, a quick-fix example run assess-to-ship in CI, stays unmet, as ADR-030 and `docs/headless-runner.md` say.
