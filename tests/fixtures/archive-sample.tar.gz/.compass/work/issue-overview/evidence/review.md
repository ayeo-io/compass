Verdict: FAIL - one blocking finding. The flowchart draws scenarios that have no green record through to another scenario's green record (finding 1). Every other finding is non-blocking.

# Review - issue-overview (a planning spec, GitHub issue #296), feature delivery approach

Reviewed: the staged diff `git diff --cached HEAD` (`cli/compass_pkg/dashboard.py`, `tests/test_issue_overview.py`), the acceptance criteria (IO-A to IO-E), the technical design, `delivery-approach.md`, a planning spec and a planning spec.

## Findings

### 1. issue (blocking) - a shared test node joins a scenario with no green to another scenario's evidence

`cli/compass_pkg/dashboard.py:145-149`. A test node's id comes from the test path alone (`_node(test)`). When two scenarios list the same test, both scenarios point at one node. The proven scenario's `test --> green-X.json` edge then hangs off that shared node. A reader who follows the arrows from the unproven scenario reaches evidence that belongs to a different scenario. The table on the same page says ○, so the page contradicts itself. That breaks acceptance criterion IO-B, a flowchart "from each intent to its scenarios, tests and evidence", and it breaks the purpose of the feature.

Reproduced on real issues:

- This issue's own page. IO-A, IO-B, IO-C and IO-E have no green, and each one reaches `green-IO-D.json` through `tests_test_issue_overview_py`:
  ```
  IO_A --> tests_test_issue_overview_py["tests/test_issue_overview.py"]
  ...
  tests_test_issue_overview_py --> green_IO_D_json["green-IO-D.json"]
  ```
- `clickable-paths`: CP-B and CP-D have no red and no green, and both reach `green-CP-A.json`.
- Across `.compass/work/`, 85 unproven scenarios in charts below the collapse limit reach another scenario's green this way. I counted them with `_records` and `_node` from the changed module.

Fix: scope the test node id to its scenario, for example `_node(sid + "__" + test)`. Another option is to draw the evidence edge from the scenario node. Add a test with two scenarios sharing one test, one proven and one open, and assert that the open one has no path to evidence.

### 2. suggestion (not blocking) - node ids and labels are not escaped

`cli/compass_pkg/dashboard.py:103-106` and the `["%s"]` labels at lines 136-149. I parsed every chart with mermaid-cli 11 (`mmdc`):

- All 9 real pages I rendered parse. These were a feature, a quick fix, an initiative past 25 scenarios, the two issues with list intents, a test id containing `[`, `]`, `$` and `<lambda>`, a free-text test, and shared tests.
- A `"` in a test id breaks the whole block. I built a scenario with test `tests/t.py::test_x[say "hi"]`, and mmdc reported `Parse error on line 4`. No real manifest has one today, but test ids are free text and pytest parameter ids can contain quotes.
- A scenario with id `end` breaks the block (`Parse error on line 3`), because `end` is a Mermaid keyword.
- `<lambda>` is dropped from the rendered label because it is read as an HTML tag. `version-bump-1-1-0` renders as `...plugin.json $.version-]`. This is real data, and the label loses text silently.
- Ids are not prefixed by kind. A scenario `INT-1` under intent `INT 1` gives `INT_1["INT 1"] --> INT_1["INT-1"]`, which is a self-loop with a relabelled node.

Fix: prefix node ids by kind (`i_`, `s_`, `t_`, `e_`), which also covers keywords. Encode `"`, `<` and `>` in labels as `#quot;`, `#lt;` and `#gt;`.

### 3. issue (not blocking) - old pages now decline permanently, and the decline is easy to miss

`cli/compass_pkg/dashboard.py:279-283`. Answers to the review questions:

- An old-format page declines and does not fail. This is correct under ADR-006 ("every new mechanism no-ops cleanly").
- A new-format page that goes stale still fails. `test_d2_stale_dashboard_fails_a_guardrail_check` in `tests/test_issue_dashboard.py` covers this through `_check_dashboard_current`, and the IO-D test covers it through `dashboard_is_current`.
- A generated new-format page cannot decline wrongly. Only a hand edit that deletes the marker line makes it decline.

The cost: all 18 generated pages in this repository passed `dashboard-current` on main with "matches the manifest". On this tree all 18 decline. Until someone regenerates them, none of them is compared again. The default `compass check` view shows the decline only as a count ("8 had nothing to check"), so the regenerate message is seen only with `--verbose`. The marker is also not a version: the next change to the page format meets the same problem, unless that change replaces the marker string.

Suggestions:

- Make the marker a format number, such as `format: 2`.
- Consider having `compass migrate` or a one-off command regenerate the pages.

`compass issue dashboard --check` (`dashboard_is_current`) still reports an old page as STALE, exit 1, while the guardrail declines. The two answers differ. The verb is honest, but say so in a comment.

### 4. issue (not blocking) - the check's governance description and the page's user doc are out of date

- `governance/guardrails.yml:41` still says `dashboard-current` declines in two cases: no README, and no generated marker. The diff adds a third case, an old format. Update the description in the same change. The diff should then go through a PR because it touches `governance/*.yml`.
- `docs/five-minutes.md:84` lists what the page "tells you" and does not mention the traceability section or the gate count.

### 5. issue (not blocking) - the PRD's acceptance column is dropped without a recorded reason

a planning spec requirement IA-3 asks for a table row with "ID, title, red, green, acceptance, evidence link". Acceptance criterion IO-A drops acceptance. The summary of `acceptance-criteria.md` records two departures from the PRD, the `render` verb and the front matter, but not this one. The effect: a scenario whose red-first proof is an acceptance record from `compass acceptance record` shows Red ○. `suite-passed` accepts that record in place of a red. Either add the column, or record the departure with its reason in the acceptance criteria.

### 6. suggestion (not blocking) - unbound records and unproven scenarios with no red are invisible on the chart

- `_records` keys an unbound `green.json` that has no `scenario` field under the empty id. This is consistent with `compass issue diagnose`, where unbound records "cannot be paired", so the table is not false. But 103 issues have such a record. For example, `bdd-adapters-and-skill-length` is landed, gates 6/6, with a full-suite green on file, and every row reads ○ ○. A line under the table naming unbound red or green records would stop a reader taking this for "nothing proven".
- Line 142 styles a scenario as open only when it has a red and no green, as IO-B says. The PRD (IA-4) and the spec say "unproven nodes styled differently". A scenario with neither record, such as CP-B, is drawn exactly like a proven one. Together with finding 1, this makes CP-B look proven.

### 7. nitpick - test discrimination gaps

Every test in `tests/test_issue_overview.py` can fail. `red-IO-A.json` shows the five scenario tests failing before the change, and `red-IO-D.json` shows the format test failing on the missing `FORMAT_NOTE`. I ran 11 mutations on a scratch copy of `cli/`. Nine were caught, and two survive:

- Styling every scenario that has no green as open, including one with no red. The test checks EX-2 and EX-1 but not EX-3.
- Dropping the filename fallback at line 98. Every fixture record carries a `scenario` field.

The IO-D test calls `dashboard_is_current`, not `compass check`, although IO-D names `compass check`. The guardrail path is covered by `test_d2` in `tests/test_issue_dashboard.py`, so this is wording only.

### 8. nitpick - duplicate edges for a scenario with several intents

`cli/compass_pkg/dashboard.py:129-149`. A scenario under two intents emits its test and evidence edges twice. Mermaid draws both, so you get double arrows (`zero-friction-install`, TRC-A3 and TRC-G1). Emit each scenario's subtree once.

## Dimensions

| Dimension | Result | Basis |
|---|---|---|
| Correctness | no-pass | Finding 1, reproduced on this issue's own page and on `clickable-paths`. The table marks are correct for bound records. Both test files pass: `tests/test_issue_overview.py` and `tests/test_issue_dashboard.py`. |
| Governance - guardrails | clear | `compass check --issue issue-overview --verbose` on this tree passes 14 checks, and 7 had nothing to check. No em dash in the diff. No agent trailer: nothing is committed yet, so read the commit message and PR body before sending. |
| Governance - strategies (judgement) | note | Cold-reader writing: `scripts/voice-tells.py` is clean on the 4 issue documents. Departures from the PRD are recorded except the acceptance column (finding 5). |
| Traceability | clear, with a note | Both changed files trace to IO-A to IO-E in `changed_files`. Every scenario has an intent and a test. Finding 5 is the one PRD-to-criteria gap. |
| Regression | clear, with a note | The full suite is green on this tree, according to `green-IO-D.json`. `dashboard-current` coverage of existing pages drops from compared to declined (finding 3). |
| Security (scaled) | clear | Rendering only. The labels are not escaped (finding 2), but the output is a local markdown page, and Mermaid sanitises HTML. |
| Clarity | note | Findings 4 and 8. |

PRD requirement IA-7 (the page must stay out of every model-facing read set): it holds. No command, skill, agent or hook reads an issue's `README.md`. I searched `commands/`, `skills/`, `agents/`, `hooks/`, `compass-contract.md` and `cli/compass_pkg/`. The only reader is the `dashboard-current` check, plus the migration that regenerates the page.

## Round 2

Verdict: PASS. Round 1's blocking finding is fixed and reproduced as fixed. What remains are nitpicks that do not block the gate.

Reviewed: `git diff --cached HEAD` on the worktree after its merge with main at d57846e. The diff covers `cli/compass_pkg/dashboard.py`, `tests/test_issue_overview.py`, `governance/guardrails.yml`, `tests/fixtures/governance-content-hashes.json` and `docs/five-minutes.md`.

### Round 1 findings, checked

1. Fixed. Test nodes are scoped per scenario (`_node("t", sid, test)`), and each evidence edge comes from the scenario's own test node.
   - I rendered every issue under `<project>/.compass/work/` and walked each chart's edges: 229 charts.
   - No scenario styled open reaches an `e_` evidence node. Round 1 counted 85 that did.
   - No node id carries two different labels.
   - This issue's own page now draws IO-A, IO-C and IO-E open, and none of them reaches evidence.
   - Putting the shared id back fails `test_a_shared_test_does_not_lead_an_open_scenario_to_evidence`. I checked this with a mutation on a scratch copy.
2. Fixed. mermaid-cli 11 parses all 229 real charts (229 ok, 0 failed). The constructed cases also parse:
   - a scenario, intent and test all named `end`;
   - a test id containing `"`, `&` and `<b>`, which renders as `test_x[say "hi" &amp; &lt;b&gt;]`;
   - `<lambda>` is no longer lost.
3. Accepted as designed. `governance/guardrails.yml:41` now names the third decline case, and its version moves to 1.25.1. The content pin in `tests/fixtures/governance-content-hashes.json` matches: `tests/test_governance_drift.py` passes. Because the change touches `governance/*.yml`, it must go through a PR.
4. Fixed. `docs/five-minutes.md` lists the traceability section.
5. Fixed. There is an Acceptance column. `acceptance-baseline.json` is excluded from it: it records the baseline run for the whole issue, not one scenario.
6. Fixed.
   - A scenario with no green and no acceptance is open, whether or not it has a red.
   - Unbound records are listed under "Not tied to a scenario".
   - When `green-X.json` and an unbound `green.json` naming X both exist, the table now links the first in sorted order, `green-X.json` (`setdefault`).
7. Partly fixed. See nitpick R2-1.
8. Fixed. Each edge line is emitted once.

`tests/test_issue_overview.py` (11 tests) and `tests/test_issue_dashboard.py` pass. The diff has no em dash.

### New findings

R2-1. nitpick (not blocking) - four behaviours have no test. On a scratch copy, each of these mutations leaves all 11 tests green:
- drawing an accepted scenario open, which the coordinator described as tested;
- counting `acceptance-baseline.json` as a record;
- letting the last record win over the first;
- reporting 0 proven in every collapsed summary node.

`test_a_shared_test_does_not_lead_an_open_scenario_to_evidence` would also pass without checking anything if EX-2's node prefix changed, because its node list would be empty. Assert that the list is not empty.

R2-2. nitpick (not blocking) - the two chart modes disagree about acceptance (`cli/compass_pkg/dashboard.py`, the collapsed branch of `_traceability`). The full chart treats an acceptance record as proof, so the scenario is not drawn open. The collapsed summary node counts only green records as "proven". An accepted scenario also draws no evidence node, and its table row shows Evidence "-". Choose one meaning of "proven", use it in both modes, and link the acceptance record when no green record exists.

R2-3. nitpick (not blocking) - `_label` does not encode `#`. A label that already contains a Mermaid entity changes when rendered: a test named `t#lt;x.py` renders as `t<x.py`. No real data does this.

R2-4. nitpick (not blocking) - a scoped test id can collide. `_node("t", sid, test)` joins its parts with `_`, so scenario `A` with test `B_x` and scenario `A_B` with test `x` both become `t_A_B_x`. This needs unusual ids and no real data has one. A separator that `\W` cannot produce, such as `__`, would remove it.

Round 1's finding 3 (old pages now decline until someone regenerates them) stays as recorded. Nothing in round 2 blocks the gate.
