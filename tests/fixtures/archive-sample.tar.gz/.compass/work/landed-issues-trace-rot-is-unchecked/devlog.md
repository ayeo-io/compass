
## 2026-08-24 - closed as already done

Fixed without this issue being closed. `tests/test_trace_rot_detection.py`
carries nine tests, and they were exercised on 2026-08-24 when the terminal
output contract re-pointed their CLI invocations - so they are known to run
rather than merely to exist.

Closed during the backlog audit of 2026-08-24.

## 2026-08-24 - status corrected to `abandoned`

Marked `landed` earlier today during the backlog audit. That was wrong,
and `compass check` said so: a landed issue must carry scenarios,
evidence and cleared gates, and this one never went through the pipeline
- the work arrived by another route.

`abandoned` means "will not resume", which is true, and it is the only
one of the five statuses that does not lie about the record. It reads as
"gave up", which is not what happened, and that gap is filed as
`no-status-for-work-done-elsewhere`.
