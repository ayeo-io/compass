# Delivery approach - loop-ceilings

**Approach:** feature · **Assessed:** 2026-10-03

| Dimension | Value | Why |
|---|---|---|
| Risk | `cross-cutting` | Changes `governance/routing-policy.yml`, the manifest schema and the `multiagent-run-recorded` check, which every multiagent issue lands through. |
| Familiarity | `brownfield-mapped` | `cli/compass_pkg/subtasks.py` and `cli/compass_pkg/multiagent_check.py` are pinned by tests. |
| Size | `standard` | Two modules, the policy, the schema and their tests. |
| Goal and role | `delivery`, engineer | a planning spec, from a private analysis (intent 3, loop budgets). |

## Policy rules fired

- RP-REQUIRE-003: architecture checked before cross-cutting or critical changes land. It adds the `verify.architecture` gate.

## Stages

assess full, define full, refine light, plan full, breakdown multiagent, implement full, verify full, ship full. No stage is skipped or collapsed.

## Gates

verify.correctness, verify.governance, verify.traceability, verify.regression, verify.clarity, verify.security, verify.architecture.

## Orchestration

One builder, solo, recorded as one subtask. The change is two modules that share one manifest key, so a second subtask would edit the same files.

## Notes

- 16 of the 49 subtasks on record exceed the proposed ceilings (for example `dispatch-protocol` and `skill-prose-pressure-tests`). The ceilings must apply only to issues created on or after the date this lands, so no landed issue turns red (ADR-006).
- The maintainer is offline. Any decision that would go to them goes to the compass:architect agent, and its ruling is recorded here.
- Touches `cli/` and `governance/*.yml`, so it goes through a PR. Stop at the first passing review.
