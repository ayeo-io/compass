Verdict: FAIL

# Review - loop-ceilings

Two defects block. Both are in how `compass issue subtask` decides that a subtask is refused. The policy rules, the check, the schemas, path confinement and the docs are sound.

What I ran:

- `tests/test_loop_ceilings.py`: 13 passed.
- The related suites: 271 passed. These cover subtask, multiagent, governance drift, house style, terminology, plain language, schema and plugin-doc drift.
- `scripts/voice-tells.py` over the issue's two documents, `docs/multiagent-protocol.md` and `agents/orchestrator.md`: clean.
- A search of the diff and the untracked test file for em dashes and agent attribution: none found.
- Shell reproductions in scratch repositories, built the same way as the test fixture. Each finding below says what it ran.

## Correctness

**issue (blocks): `subtask next` keys "refused" on the status `dispatched`, so it gets both directions wrong.** The code is at `cli/compass_pkg/subtasks.py:371-376`. `attempt_refusal` answers "would another attempt be refused?". `next` prints that answer as "this subtask is refused", but only when the status is `dispatched`. This causes two errors:

- **An attempt the ceiling allows is shown as refused.**
  - Steps: `add S1`, then `update S1 --attempt` twice. The subtask now has `attempts: 3` and `status: dispatched`, so its third attempt is under way and the ceiling permits it.
  - `next` prints `S1  refused  it has had 3 attempts, the ceiling RP-LOOP-001 sets; record a stop reason or replan`.
  - A session that resumes from `next` follows `agents/orchestrator.md` ("When to stop") and stops one attempt early. On a resumed run, this makes the attempt ceiling 2 in practice.
  - The check (`_past_ceilings`) uses "more than the limit". `next` uses "at the limit". The design says `next` lists a subtask "past a ceiling".
  - The LC-C test asserts this wrong output (`tests/test_loop_ceilings.py:202`).
- **A subtask with a repeated error is not listed as refused in the documented flow (LC-B).**
  - `docs/multiagent-protocol.md` records a builder's result with `--status reported`, and `--error` goes on the same call.
  - Steps: `update S1 --status reported --error E`, then `update S1 --error E` twice. The subtask now has `error_repeat_count: 3` and `status: reported`.
  - `next` prints `S1  reported  attempt 1 ...` as work to resume, not as refused.
  - The LC-B test passes only because its subtask never leaves `dispatched` (`tests/test_loop_ceilings.py:180`).

  Fix direction, for the builder to choose: separate "the next attempt would be refused" from "an attempt is in flight". For example, list the refusal against a subtask whose latest attempt has reported (status `reported` or later) or that is past the limit. Add a test for the third attempt in flight and a test for the reported flow.

**issue (blocks): a refused `--attempt` throws away the `--error` given in the same call, and the ceiling can then be passed.** The code is at `cli/compass_pkg/subtasks.py:263-268` and `283-289`.

- `--error` updates the count in memory. The refusal then raises before `save_manifest`, so the third report of the error is never written.
- Steps: `update S1 --error E` twice, then `update S1 --error E --attempt`.
  - The update is refused, which is correct.
  - The manifest still holds `error_repeat_count: 2`.
  - A following `update S1 --attempt` succeeds and gives `attempts: 2`, after the same error was reported three times.
- `--round`, `--stop-reason` and `--finding` given with a refused `--attempt` are lost the same way.
  - Steps for `--stop-reason`: reach 3 attempts, then run `update S1 --stop-reason r --stop-evidence docs/b/stop.md --attempt`. It is refused, `stopped_reason` is not recorded, and the refusal tells the user to record a stop reason, which they just did.

  Fix direction: save what the call recorded before refusing the attempt. Alternatively, refuse before changing anything, but then the error count must still be written.

**question (does not block): should older issues still in progress get refused attempts?**

- `update --attempt` and `replan` refuse whatever the issue's `created:` date. Only the check honours the 2026-10-03 cutoff.
- Steps: an issue with `created: '2026-09-01'` is refused a fourth attempt.
- This does not turn a landed issue red, so ADR-006 (backward compatibility) holds for the check.
- The delivery approach says the ceilings "must apply only to issues created on or after the date this lands". Either the cutoff also applies to the CLI, or the approach note should say that the cutoff covers the check only.

**suggestion (does not block): the round warning is wrong for an older issue.**

- The code is at `cli/compass_pkg/subtasks.py:303-309`.
- Steps: on an issue with `created: '2026-09-01'`, record a fourth round. The CLI prints "The run cannot land until --stop-reason and --stop-evidence record why".
- The check does not compare that issue's counts, so the run can land without a stop reason.

**suggestion (does not block): a recorded stop cannot be cleared, and it ends all further judgement of the subtask.**

- A subtask with `stopped_reason` is skipped by `next` and passes the check whatever happens after it. More rounds or a later `--status done` do not change this.
- This matches the design ("counts as finished, whether or not it is done").
- A stop recorded by mistake has no command to undo it, so it needs a hand edit of the manifest. Note this in the protocol doc, or give the stop an undo.

The rest of the change matches the acceptance criteria:

- LC-A: the rules resolve by risk, the lowest matching limit wins, and a policy without the block gives no ceiling plus drift entries for all five rule ids.
- LC-C: the update refuses a fourth attempt and names the rule.
- LC-D: the check fails past the round ceiling, passes with a stop reason, and fails when the evidence file has gone.
- LC-E: an older issue is judged as before.
- LC-F: the replan ceiling refuses a third replan.
- The issues dated 2026-10-03 in the archive stay green. I ran the check on `clickable-paths` and `issue-overview`, both at contained risk with 2 rounds: both pass.

## Security

No finding. The path and injection handling is sound:

- `--stop-evidence` is confined to the project (`_inside`, using realpath). These were each refused:
  - `../../etc/hosts`
  - `/etc/hosts`
  - a symlink inside the project that points to `/etc/hosts`
  - a directory
- The check confines the recorded path again (`multiagent_check.py`, `_stop_problem`). An absolute path or a path outside the project in a hand-edited manifest fails it.
- The error text is stored only as a SHA-256 digest, so no builder output reaches the manifest.
- The reason text is written through the YAML dumper.
- Nothing is passed to a shell or to git.

## Clarity

**suggestion (does not block): malformed counts now crash `next` with a traceback.**

- `attempt_refusal` calls `int()` on `attempts` and `error_repeat_count` (`cli/compass_pkg/subtasks.py:105`, `113`). `next` now calls it for every open subtask.
- Steps: set `error_repeat_count: lots`, or `attempts: two`. `next` exits 1 with `ValueError: invalid literal for int()`.
- Before this change, `next` printed these values without converting them. `update` already had the `int()` on `attempts`.
- Raise a `CompassError` that names the field instead.

**nitpick (does not block): the refusal puts the rule id where a reader expects the meaning.**

- The code is at `cli/compass_pkg/subtasks.py:109`, `116` and `408`.
- "it has had 3 attempts, the ceiling RP-LOOP-001 sets" does not say what the ceiling limits or where it lives.
- Better: "it has had 3 attempts, the most the builder-attempts ceiling allows (RP-LOOP-001 in governance/routing-policy.yml)".
- The check message "past the ceiling of 3 (RP-LOOP-002)" already has the right form.

**nitpick (does not block): the replan refusal ends "and ask." without saying whom.**

- The code is at `cli/compass_pkg/subtasks.py:410`.
- `docs/multiagent-protocol.md` says "the person who owns the issue". Use the same words here.

The docs are clear:

- `agents/orchestrator.md` "When to stop" and the "Ceilings" paragraph in `docs/multiagent-protocol.md` say what a reader with no context needs.
- The comments in the module headers explain why the code behaves as it does.

## Architecture

No finding. The change keeps to the project's architecture rules:

- **The policy is data.** The limits and rule ids live only in `governance/routing-policy.yml`. The code holds just the four ceiling names. A policy without the block gives no limit, and I checked this through the LC-A test.
- **Backward compatibility (ADR-006).** The check compares counts only from 2026-10-03, through the existing `_applies_from` helper with a cutoff parameter. A non-ISO `created:` is still treated as new. The CLI side is raised under Correctness.
- **The orchestrator launches nothing (ADR-025).** The CLI only records and refuses. It starts no builder or reviewer.
- The policy version moved to 2.14.0 and the guardrail description version to 1.26.0. The content-hash fixture is re-pinned. `loop_ceilings` is added to the drift rule sources.

## House rules

No finding:

- The diff and the untracked test file have no em dash.
- No agent attribution appears in any changed file.
- The prose is plain British English, and "artifact" does not appear in new text.
