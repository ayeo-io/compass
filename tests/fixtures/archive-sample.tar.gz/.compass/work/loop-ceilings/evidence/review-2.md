Verdict: FAIL

# Review - loop-ceilings, round 2

Both blocking defects from round 1 are fixed, and I reproduced each fix against the new code. One new defect blocks: two descriptions of `subtask next` still describe the round-1 behaviour.

- The `next` help text and the owning doc (`docs/multiagent-protocol.md`) say that a subtask at its attempt ceiling is listed as refused.
- The code now lists that subtask normally, with an "attempt N of N" line.
- This is a two-sentence fix.

The round-1 report is kept as `evidence/review-1.md`.

What I ran:

- `tests/test_loop_ceilings.py` with the related suites: 285 passed. The related suites cover subtask, multiagent, governance drift, house style, terminology, plain language, schema, CLI-surface and plugin-doc drift.
- The round-1 shell reproductions again, in fresh scratch repositories built the same way as the test fixture.
- A search of the added lines for em dashes and agent attribution: none found.

## Correctness

**Fixed: `subtask next` no longer gets "refused" wrong** (`cli/compass_pkg/subtasks.py`, `cmd_subtask_next`). I reproduced three cases:

- **Third attempt in flight:** `add S1`, then `update S1 --attempt` twice, then `next`. The output is `S1  dispatched  attempt 3`, followed by `attempt 3 of 3 (RP-LOOP-001): the last one; another is refused`. It is no longer listed as refused.
- **Third attempt reported:** the same steps, plus `--status reported`. The output is the same normal listing with the last-attempt line.
- **Repeated error in the documented flow (scenario LC-B):** `--status reported --error E`, then `--error E` twice, then `next`. The output is `S1  refused  its builder reported the same error 3 times, the ceiling RP-LOOP-005 sets; record a stop reason or replan`.

The tests now cover these cases: LC-B starts from `--status reported`, and LC-C checks that `next` shows "attempt 3 of 3" and not "refused".

**Fixed: a refused `--attempt` keeps the rest of the call.** I reproduced three cases:

- **The error is kept:** `--error E` twice, then `--error E --attempt`. The update is refused with exit code 2, and the manifest now holds `error_repeat_count: 3`.
- **The ceiling holds afterwards:** a following plain `--attempt` is refused too, and `attempts` stays at 1.
- **The stop reason is kept:** at 3 attempts, `--stop-reason r --stop-evidence docs/b/stop.md --attempt` is refused, `stopped_reason` is recorded, and the message says "The stop reason given is recorded."

The new test `test_lc_c_a_refused_attempt_keeps_the_rest_of_the_call` covers this.

**Fixed: the round warning on an older issue.** On an issue with `created: '2026-09-01'`, four `--round fail` calls print no ceiling warning. The check does not compare that issue's counts, so the CLI and the check now agree.

**issue (blocks): the `next` help text and the owning doc still say a subtask at its attempt ceiling is listed as refused.**

- `cli/compass_pkg/subtasks.py:545-546`, the `next` description: "A subtask past its attempt or repeated-error ceiling is listed as refused, with the reason."
- `docs/multiagent-protocol.md:182-184`: "Another attempt is refused at the attempt ceiling, or once the same error has been reported 3 times in a row; `subtask next` lists such a subtask as refused."
- To reproduce: with attempts at 3 (steps above), `next` lists `S1  dispatched  attempt 3` plus the last-attempt line. Only a repeated error gives `refused`.
- A reader who resumes a run from the help text or the protocol doc expects a refusal that `next` never shows.
- `CLAUDE.md` ("Owning docs") requires the owning doc to change with the code.
- Fix: say that `next` lists a repeated-error subtask as refused, and marks a subtask at its attempt ceiling as on its last attempt.

**nitpick (does not block): a quoted number in `attempts` resets the count.**

- `_int` treats `attempts: '3'` as no value. A following `--attempt` writes `attempts: 1` instead of refusing.
- Before this change, `int('3')` read it as 3.
- To reproduce: set `attempts: '3'` (a quoted string) in the manifest, run `update S1 --attempt`, and get exit code 0 with `attempts: 1`.
- Only a hand edit produces a quoted count, and a hand edit can change any count anyway, so this does not block.
- `pre_attempt_try` (`subtasks.py:256`) still uses `int()`, so `update` still crashes on `attempts: two`. That crash is older than this change.

**Left as they are (agreed, not blocking):**

- Older issues still in progress are refused attempts and replans. The coordinator states this is intended, and there are no such issues now.
- A recorded stop cannot be cleared without editing the manifest by hand.
- The rule-id wording in the refusal messages, and "ask" in the replan refusal, are unchanged.

## Security

No finding. The stop evidence is still confined to the project. I re-ran each of these and each was refused:

- `../../etc/hosts`
- `/etc/hosts`
- a symlink inside the project that points to `/etc/hosts`
- a directory

The error text is stored only as a digest. Saving before the refusal writes only values that have already been checked.

## Clarity

The blocking help-text and doc finding is under Correctness.

**Fixed: malformed counts no longer crash `next`.** I reproduced both values: with `error_repeat_count: lots`, and with `attempts: two`, `next` exits 0.

The refusal message now says "The rest of this update is recorded", which tells the reader why the exit code is 2 although data was saved.

## Architecture

No finding. The round-2 changes keep to the architecture rules:

- The limits still come only from `governance/routing-policy.yml`.
- The round warning reuses the check's cutoff (`LOOP_CEILINGS_FROM`, `_applies_from`) through an import inside the function, so the CLI and the check share one date. The circular import between the two modules resolves at call time, and the tests exercise both paths.
- The CLI still launches nothing (ADR-025).

## House rules

No finding:

- The added lines have no em dash.
- No agent attribution appears in any changed file.
- The prose is plain British English.
