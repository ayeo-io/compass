Verdict: PASS

# Review - loop-ceilings, round 3

No finding blocks. The `next` help text and `docs/multiagent-protocol.md` now match what `subtask next` does. The round-2 blocking finding was that they did not. A sweep of every changed file found no other text that describes the round-1 behaviour.

The earlier reports are kept as `evidence/review-1.md` and `evidence/review-2.md`.

What I ran:

- `tests/test_loop_ceilings.py` with the related suites: 285 passed in 9.21s. The related suites cover subtask, multiagent, governance drift, house style, terminology, plain language, schema, CLI-surface and plugin-doc drift.
- The shell reproductions from rounds 1 and 2 again, in fresh scratch repositories.
- A search of the added lines for em dashes and agent attribution: none found.

## Correctness

**Fixed: the wording matches the code.**

- The `next` help text (`cli/compass_pkg/subtasks.py:546-549`) says: "A subtask whose builder reported the same error up to its ceiling is listed as refused, with the reason; one at its attempt ceiling is marked as on its last attempt."
- `docs/multiagent-protocol.md:182-185` says the same.
- The code agrees. `cmd_subtask_next` prints `refused` only when `error_refusal` returns a reason. At the attempt ceiling it prints `attempt N of N (RP-LOOP-001): the last one; another is refused`.
- I reproduced both outputs again:
  - Three attempts gives `S1  dispatched  attempt 3`, followed by the last-attempt line.
  - The same error three times with `status: reported` gives `S1  refused  its builder reported the same error 3 times, ...`.

**Sweep for text that still describes the old behaviour.** I searched the changed files for every use of "refused", "listed as refused" and "last attempt":

- `cli/compass_pkg/subtasks.py`
- `cli/compass_pkg/multiagent_check.py`
- `docs/multiagent-protocol.md`
- `agents/orchestrator.md`
- `governance/routing-policy.yml`
- `governance/guardrails.yml`
- `schemas/manifest.schema.json`

Each one now describes the current behaviour:

- **The `update` help text:** "Another attempt is refused past the loop_ceilings rules", and for `--attempt`, "refused past the attempt or repeated-error ceiling". Both refer to the next attempt, which would go past the limit.
- **The module header in `subtasks.py`:** "Another attempt or replan past one is refused."
- **`agents/orchestrator.md`:** the refusal it names is the one `update` and `replan` give.
- **The manifest schema:** the descriptions of `error_repeat_count` and `replans` give the refusal points that the code uses.

**Fixed: a quoted count is read as a number.**

- `_int` reads `'3'` and `' 3 '` as 3.
- To reproduce: with `attempts: '3'` in the manifest, `update S1 --attempt` is now refused, where in round 2 it wrote `attempts: 1`.

**nitpick (does not block): `_int` still raises on a non-ASCII digit.**

- `_int` (`cli/compass_pkg/subtasks.py:106`) uses `str.isdigit()`. That is true for a character such as superscript three, which `int()` cannot read.
- To reproduce: `_int('³', 0)` raises `ValueError`.
- Only a hand edit of the manifest could produce this.
- `str.isdecimal()`, or a `try`/`except ValueError`, would close it.

**nitpick (does not block): one line of the doc paragraph is longer than the rest.**

- `docs/multiagent-protocol.md:185` ("its last attempt. A review round past the ceiling is recorded, but the run cannot") runs past the wrap width of the paragraph around it.
- This is cosmetic.

**Unchanged and agreed (not blocking):**

- Older issues still in progress are refused attempts and replans.
- A recorded stop cannot be cleared without a hand edit.
- The rule-id wording in the refusal messages, and "ask" in the replan refusal, are unchanged.

The round-1 and round-2 fixes still hold:

- `next` lists the third attempt normally while it is under way, and lists a repeated error as refused.
- A refused `--attempt` saves the rest of the call: the error count, rounds and stop reason.
- An older issue gets no review-round warning.
- Malformed counts do not crash `next`.

## Security

No finding. This round changed no path or input handling.

- In round 2, `--stop-evidence` with `../../etc/hosts`, `/etc/hosts`, a symlink pointing outside the project, or a directory was each refused.
- The `_int` change reads manifest values only, and passes nothing to a shell or to git.

## Clarity

No blocking finding. The help text and the protocol paragraph now tell a reader with no context what `next` shows in each case. The two nitpicks are under Correctness.

## Architecture

No finding:

- The limits still come only from `governance/routing-policy.yml`.
- The check keeps the 2026-10-03 cutoff for older issues (ADR-006).
- The CLI launches nothing (ADR-025).

## House rules

No finding:

- The added lines have no em dash.
- No agent attribution appears in any changed file.
- The prose is plain British English.
