# Devlog - publish-the-archive

> **Issue:** Unignore `.compass/work/` so the receipts are openable. · **Opened:** 2026-08-11 · **Abandoned:** 2026-08-11

---

## 2026-08-11 15:10 - Triage

- **Approach:** initiative. Critical risk, five floors fired, worktree capped to one, nine gates including analyze and fitness. Publishing 70 issue directories into public git history is irreversible and the archive had not been reviewed for personal data, so the weight was right.
- **Next:** the pre-flight scan, which is the whole substance of the slice.

## 2026-08-11 15:40 - note: the pre-flight scan came back clean

- **Sensitivity: nothing found.** No credentials, no third-party personal data, no confidential material, no binaries, no secrets of any pattern. One username across 1,629 absolute paths, the maintainer's own.
- **Three operational blockers found**, none of them about sensitivity: the flip would turn CI red on 15 check groups, `*.log` is unanchored so 382 files would have stayed hidden anyway (one of them cited as typed evidence), and 186 citations point into directories that stay private.
- **Two decisions taken to the maintainer** rather than settled quietly, per their instruction that a finding is worth reporting rather than excluding: whether an outside project cited as a brief was a client's, and how five seeding participants should be recorded once the archive is public. Answered: the project is the maintainer's own, and participant names stay out of the archive.

## 2026-08-11 16:00 - Abandoned

- **Event:** the maintainer decided to keep `.compass/` fully private, and to work on curated documentation later.
- **What changed the decision:** the planning documents stay private. The archive cites them 186 times, so publishing it alone would have handed a reader an archive full of dead references - the same problem one layer down, bought with a one-way door.
- **Nothing was published.** `.gitignore:19` is untouched and the working tree is clean. This is a decision recorded, not a change reverted.
- **The scan is the salvage.** If this is revisited, the sensitivity work does not need repeating from scratch - only updating for what has been added since.
- **Also worth keeping:** the seeding-names question is now answered ahead of the moment it would have mattered. Participants are recorded by initial or pseudonym; any real-name mapping stays in a file that is not published.
