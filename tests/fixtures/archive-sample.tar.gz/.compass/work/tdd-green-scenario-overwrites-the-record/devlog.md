# Devlog - tdd-green-scenario-overwrites-the-record

## 2026-08-13 - filed

`compass tdd-green --scenario X` writes evidence/green.json, the same path the
unbound form writes. So recording a scenario-bound green destroys the generic
full-suite record that other gates may be citing.

Found during the 2.1.0 cycle when a fix meant to repair one evidence record
destroyed another, and `compass check` reported PASS throughout because it counts
records and requires them green without asking whether a record is the run it is
cited as. Related to the evidence-identity work heading the next cycle, but
narrower and fixable on its own: the bound form should write its own path.

Filed separately per standing practice: a found defect gets its own issue
named by slug, never a follow_ups entry.

## 2026-08-24 - closed as already done

Fixed without this issue being closed. `cli/compass_pkg/tdd.py:618` builds the
record name from the binding - `name = "green-" + scenario.replace("/", "_")` -
so a scenario-bound green writes `evidence/green-<scenario>.json` and the
unbound form keeps `evidence/green.json`. `CLAUDE.md` documents it as "the
binding decides the filename".

Closed on inspection during the backlog audit of 2026-08-24, not on a fresh
test run - the behaviour is in the code and in the operating instructions.

## 2026-08-24 - status corrected to `abandoned`

Marked `landed` earlier today during the backlog audit. That was wrong,
and `compass check` said so: a landed issue must carry scenarios,
evidence and cleared gates, and this one never went through the pipeline
- the work arrived by another route.

`abandoned` means "will not resume", which is true, and it is the only
one of the five statuses that does not lie about the record. It reads as
"gave up", which is not what happened, and that gap is filed as
`no-status-for-work-done-elsewhere`.
