# Devlog - the-human-review-pack

## 2026-08-23 - triaged, split into three, kept as the tracking record

Its own bug report predicted this: "it will almost certainly split again when it
is triaged properly." It did.

**The split was not invented here.** The companion proposal defines three slices
and eleven numbered changes, so triage honoured that shape rather than deriving
a different one. The three issues map one-to-one onto the proposal's slices.

| Issue | Proposal items | Approach |
|---|---|---|
| `the-human-front-door` | 1-4: artifact registry, per-issue README, terminal output contract, stop pasting raw output | initiative |
| `adaptive-artifact-composition` | 5-8: split design.md, policy-triggered templates, rename Brief by depth, work-plan.md | initiative |
| `revision-bound-approvals` | 9-11: revision-bound approvals, gating on them, tests for omission and re-review | feature |

**Dependency order is real, not preference.** `the-human-front-door` goes first
because the artifact registry is what the other two read: composition declares a
document's kind and reason *in the registry*, and an approval binds to an
artifact the registry names.

**One finding that changes the third slice's size.** `tdd-green-unbound-record`
landed earlier today and stamps every evidence record with a `record_id` and a
`content_digest`, with the registry entry storing both and a check comparing
them. "An approval binds to an exact revision or hash" and "a material edit
invalidates the approval" are that mechanism pointed at an artifact rather than
a test record. So the third slice is assessed `standard` rather than the size
the proposal implies - and its bug report says plainly that triage should
confirm that when it is picked up rather than inherit it.

## Why this issue is parked rather than abandoned

It is the only thing tracing the three back to one source proposal, and this
project has no mechanism for that - a multi-issue source has nowhere to live
except an issue that stays. Abandoning it would break the trail; landing it
would claim gates it never cleared.

Parked, with the split recorded above. Nothing in it left to build.

## 2026-08-24 - closed as already done

All three children landed. This was the tracking record for the whole
human-reviewable-artifacts proposal, split on 2026-08-23 into:

  the-human-front-door            landed - PR #76
  the-terminal-output-contract    landed - PRs #78, #79, #80, #81, #82
  adaptive-artifact-composition   landed - PR #84

It was `parked`, which means stopped and resumable. Nothing is stopped: the
work finished. Marked landed during the backlog audit of 2026-08-24.

What is left of the proposal is one rename, `prd.md` -> `intent.md`, tracked
in `artifact-filenames-rename-slice`. Items 5 and 8 were dropped with reasons
recorded there.

## 2026-08-24 - status corrected to `abandoned`

Marked `landed` earlier today during the backlog audit. That was wrong,
and `compass check` said so: a landed issue must carry scenarios,
evidence and cleared gates, and this one never went through the pipeline
- the work arrived by another route.

`abandoned` means "will not resume", which is true, and it is the only
one of the five statuses that does not lie about the record. It reads as
"gave up", which is not what happened, and that gap is filed as
`no-status-for-work-done-elsewhere`.
