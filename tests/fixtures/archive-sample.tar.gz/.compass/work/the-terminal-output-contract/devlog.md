# Devlog - the-terminal-output-contract

## 2026-08-23 - triage

- **Event:** Assessed and routed. Cross-cutting risk, brownfield-mapped, large,
  delivery. The evaluator computed **initiative**: every stage full weight,
  eight gates, `verify.fitness` added by `RP-REQUIRE-003`.
- **Measured rather than quoted:** the bug report's "24 verbs and 247 print
  sites" is from before three issues landed. At HEAD it is **253 print calls,
  208 of them inside a verb body, across 34 verbs** - and five verbs hold 116 of
  the 208. The shape of the work is a handful of heavy reports plus a long tail,
  not 208 even edits.
- **Artifact:** `delivery-approach.md`, `task.yml`, `architecture-loaded.yml`,
  `README.md`.
- **Evidence:** none yet - the define stage produces the first.
- **Three questions recorded for the requirements review rather than left to the
  implementation:** whether the twelve-line rule applies to diagnostics that
  exist to give detail; how an identifier survives compression without breaching
  ADR-017; and what `--quiet` does in the common case where nothing is being
  handed off.
- **Next:** define acceptance criteria.

## 2026-08-23 - acceptance criteria

- **Event:** 16 scenarios in five groups, traced to five intents. All three
  triage questions are answered *in the criteria* rather than left to the
  implementation.
- **The answer to "does twelve lines apply to a diagnostic?" is no, and the
  spec says so:** two output kinds, not one rule. A **hand-off** (ends a stage
  or renders a verdict) fits twelve lines. A **report** (`calibration`,
  `terminology`, `flow` - run deliberately to get detail) keeps all its detail
  but must open with a summary of five lines or fewer. Cutting a report to
  twelve lines would remove the reason to run it.
- **Artifact:** `acceptance-criteria.md`, `task.yml` scenarios block.
- **Evidence:** none yet - `suite-passed` is the one open check, which is
  correct before any code exists.
- **Measured before writing the thresholds:** `check` is 45 lines with 14 PASS
  lines, `flow` is 156, `approach evaluate` prints a raw Python dict. Quoted in
  the spec so no scenario states a number nobody took.
- **Next:** requirements review.

## 2026-08-23 - requirements review

- **Event:** Seven findings, all resolved. Two were contradictions inside the
  spec, one was a gap that changes how the work must be sequenced, four were
  decisions. Five scenarios added: 16 -> 21.
- **The gap is the important one.** 37 test files assert a literal string in
  stdout - 130 assertions. The spec said nothing about them, and the fastest way
  to land this change is to run the suite, see 130 failures and edit each
  expected string to match. That proves nothing. Two binding rules now: verbs
  move one at a time, and an expected string is only updated when the test's
  intent still holds.
- **`compass check` cannot fit twelve lines and keep what makes it good.** Its
  what/why/fix failure format is four lines each; three failures is thirteen
  before the verdict. Resolved: `what` and `fix` stay in the default, `why`
  moves to `--verbose`. Rejected reclassifying it as a report - it is the gate
  verdict, and exempting it would mean the contract does not apply where it
  matters most.
- **A line budget alone is a check that clears by reformatting.** `check`'s
  longest line is 252 characters, so 45 lines joined into 12 would pass. A
  100-character bound was added alongside.
- **Artifact:** `requirements-review.md`, updated `acceptance-criteria.md`,
  updated `task.yml`.
- **Definition of Ready:** all seven boxes checked, none deferred.
- **Next:** design.

## 2026-08-23 - design

- **Event:** Seven design decisions, each with what was rejected and why. The
  governance check passed with no guardrail crossed and one recorded strategy
  departure. Four work units, four PRs.
- **The shape:** a new `terminal.py` owns every line a person reads. Verbs pass
  it the *pieces* of what they want to say rather than formatted text, so it can
  re-order, cap at three, move a line to `--verbose`, or emit JSON - none of
  which is possible for a filter that wraps stdout after the fact.
- **Five flags reach 47 registrations by walking the parser tree once**, not by
  47 edits that the 48th verb will not get. The tree has 13 nested subparser
  groups, so a walk that fails to recurse silently misses everything nested -
  which is how TRC-C1 can genuinely fail rather than passing by construction.
- **One strategy departure, recorded:** S14 says correct every place at once,
  and this deliberately does not. The requirements review ruled the all-at-once
  path out because it would rewrite 130 assertions in one motion and prove
  nothing. A ratchet - `print()` becomes an error in a converted module -
  replaces what S14 would have guaranteed.
- **Artifact:** `design.md`, `distribution-map.md`.
- **Evidence:** `compass design lint` PASS, `compass policy lint` PASS.
- **Next:** implementation, U1 first.

## 2026-08-23 - implementation, U1

- **Event:** `cli/compass_pkg/terminal.py` lands with the two contracts, the
  five flags, and three guards. 16 scenarios green; suite 1283 -> 1299.
- **Three defects found while building it, all in my own work:**
  1. **TRC-C6 could not fail.** The output kind was DERIVED from a list of
     report verbs, so every verb got one and a verb that forgot to declare was
     impossible. That is the exact failure the requirements review wrote the
     scenario to prevent, reintroduced by the convenient implementation of it.
     Now declared at each of the 34 registrations.
  2. **The evidence path was being shortened** to fit the 100-character bound,
     which makes the link unopenable - worse than a wide line, because it fails
     at the thing the line exists for. Paths print whole; the width guard
     exempts a line whose overflow is one unbreakable token.
  3. **A long rule line lost its trailing identifier when shortened**, which is
     the deletion ADR-017 forbids. TRC-D1 only used short lines, which keep
     their ids for free, so it never reached the case it exists for.
- **Two of my own test assertions were wrong**, both caught by running them:
  `approach evaluate --json` was asserted to have keys `final_route` and
  `phases` that have never existed - a compatibility check against invented
  names checks nothing - and the leaf-verb floor was guessed at 40 when the
  tree has 34.
- **Evidence:** EV-MUT-U1 - ten mutations, all caught.
- **Recorded rather than nudged:** the entry-point line cap was raised for the
  third time in a week, and the previous raise had left three lines of
  headroom. Filed as `entry-point-cap-measures-the-wrong-thing`.
- **Next:** U2 - `compass check` moves to the contract.

## 2026-08-24 - implementation, U2

- **Event:** `compass check` moves onto the contract. **45 lines to 9.** The
  checks themselves are untouched; only what reaches the terminal changed.
- **The verb now COLLECTS its results and renders at the end**, because a
  decision about what to show cannot be made by code that has already printed.
  `--verbose` renders exactly what the command printed before, line for line.
- **AMB-6 landed as predicted: 49 tests broke.** Every one asserted a check's
  per-check detail - its name, its PASS/FAIL, the reason it gave - which is
  precisely what moved to `--verbose`. Their intent still holds, so they were
  re-pointed rather than rewritten, with a note in each file saying so. No
  expected string was edited to match new output.
- **The one-line fixes are written, not derived.** Cutting the full `fix` text
  at its first sentence would ship a sentence nobody read, and it would change
  silently whenever the long text was edited. Thirteen `do:` lines, each under
  90 characters, and a missing one fails.
- **Found by reading the output:** `scenario-has-id-and-intent` runs under two
  guardrails, so it appeared in the top three AND in "... and 2 more". That
  reads as the tool being confused about its own findings. The display list is
  deduplicated by name; the verdict count still counts check runs.
- **Also fixed while here:** the verdict read "PASS - PASS - 14 check(s)..." -
  I built it by re-parsing `summarise_counts`, which already begins "compass
  check: PASS - ". Built from the counts now.
- **Evidence:** EV-MUT-U2 - ten mutations, all caught. Suite 1299 -> 1306.
- **Next:** U3 - the four heavy reports.

## 2026-08-24 - implementation, U3

- **Event:** The four reports move onto the contract. Every finding is still
  printed - that is what a report is - and each now opens with a summary a
  reader can stop at, with `--quiet`, `--json` and `--evidence-out` working.
- **A naming error in my own design, corrected:** it listed `calibration` as
  one of the four verbs. There is no such verb - `cmd_calibration` is what
  `compass retro` runs. The design and the distribution map now say so.
- **`retro` opens with the signal, not the census.** Whether triage is over- or
  under-sizing was eighteen lines down; it is now the first line, because that
  is the one thing a reader runs the command for.
- **The guards are written over every verb that DECLARES itself a report**,
  not over a list of four names, so a fifth report is covered the day it is
  declared. TRC-C6 asserts the list is not empty - four tests iterating an
  empty list would all pass without checking anything.
- **A real defect in one of my own guards, found by mutation.** TRC-B1 read the
  first five lines of the whole report, so the section header "IN PROGRESS (1)"
  supplied the digit it was looking for and the summary was never checked. A
  mutation that stripped every number from flow's summary still passed. It now
  reads only the lines before the first blank one, and asserts the summary fits
  its own budget.
- **The path-shortening defect from U1 recurred**, in the report summary this
  time: `analyze`'s evidence path was truncated to fit 100 characters, which
  makes the link unopenable. The exemption is now applied in both renderers
  rather than only the hand-off.
- **One test re-pointed, and strengthened.** `test_analyze_summary_agrees_with_
  the_findings_it_listed` guards a real past bug where analyze listed findings
  then reported zero. Its intent holds; the output shape moved. It now asserts
  the two counts are the same number rather than only that the verdict does not
  say zero.
- **Evidence:** EV-MUT-U3. Suite 1306 -> 1311.
- **Next:** U4 - the long tail of 29 verbs.

## 2026-08-24 - implementation, U4

- **Event:** The long tail is on the contract. 13 verbs converted; every
  hand-off verb now fits the budget, honours `--quiet` and emits real JSON.
- **The guard that was missing until now:** a test that RUNS every hand-off
  verb in a fixture and measures what actually reached the terminal. Everything
  before this tested the emitter or one verb at a time. A verb in the parser
  that is neither measured nor exempt-with-a-reason fails, so the next verb
  added has to be measured rather than quietly missed.
- **Measured first, as the numbers decided the work.** Only four genuine
  breaches existed: `adr new` (a 129-character caveat), `acceptance start` (a
  path followed by prose on one line), and `approach evaluate` (16 lines and a
  raw assessment dict at 151 characters). Most of the tail already fitted; what
  it did not do was honour the flags.
- **The path-shortening defect recurred a THIRD time**, in `say()`. Fixed at
  the class this time: the exemption moved inside `_fit`, so no caller can get
  it wrong. It had been fixed at three separate call sites on three separate
  days, which is the definition of the wrong fix.
- **A next step is not a reply.** `approach evaluate` said "nothing recorded -
  re-run with --write" as a `reply`, and a reply means a person is being asked
  to decide - which is exactly what stops `--quiet` being silent. They are now
  separate fields.
- **Policy drift did NOT move to `--verbose`.** The plain "which policy file
  did I read" line is provenance and did; drift is a concern, because a project
  running a policy missing rules the framework ships gets a lighter approach
  than it should and a reader cannot tell that from a genuinely light one.
- **Seven tests re-pointed**, all reading evaluator detail that moved. One doc
  updated: `docs/five-minutes.md` now shows the default view a reader will
  actually see, then the `--verbose` block for the working.
- **A trap worth knowing:** `compass tdd-red -- false --json` puts `--json`
  inside the command being run. The tests place mode flags before any `--`,
  and say why.
- **Evidence:** EV-MUT-U4. Suite 1311 -> 1315.
- **Next:** verify and ship. This closes the issue.

## 2026-08-24 - verify

- **Event:** All eight gates GREEN with resolving evidence. 21 criteria pass,
  36 tests, suite 1315 in the working tree and 1309 in a clean clone.
- **Found at verification, which is what it is for:** the spine's `tests:` list
  was still the placeholder names generated when the criteria were written -
  `test_trc_a1` rather than the real function name. Most did not resolve.
  `compass check` had not caught it because `declared-tests-resolve` reports
  "declared tests are still a plan, not a claim" until correctness is claimed,
  which is now. All 21 corrected and run.
- **TRC-D4 is marked narrative.** It is a rule about how a change is made, and
  no test can observe whether an author checked the intent still held before
  editing an expected string. What can be shown is that it was followed: 56
  re-pointed assertions, each file carrying a note.
- **S9 was NOT run, and the report says so in its first paragraph.** A sweep is
  meant to be verified by a fresh reader who has not seen the change. This one
  touched 34 verbs and 56 assertions, so S9 plainly applies, and no independent
  reader has read it. Every dimension is author-assessed.
- **Evidence:** EV-CHK-1, EV-CLEAN-1, EV-REVIEW-1, four mutation rounds.
- **Next:** ship.

## 2026-08-24 - S9 fresh eyes, and what it changed

- **Event:** Three readers who had not seen the change reviewed it - the
  production code, the guards, and a cold newcomer running the CLI. Each was
  told not to trust the commit messages. They raised 40+ findings; twelve were
  defects this change caused. All fixed in PR #82.
- **The verification report's earlier verdict was wrong.** It said PASS on
  every dimension with no independent reader, and the caveat at the top was the
  only thing separating it from a false record. That revision is left in the
  history rather than replaced: "the author signed off and the author was
  wrong" is the entire argument for S9, and this issue is now the worked
  example.
- **The worst finding was mine twice over:** `compass check` could state a
  failure count and list fewer, with no marker at all. TRC-A4 asserted that a
  truncation marker EXISTS rather than that the arithmetic holds - so the guard
  written to prevent exactly this passed while a failure vanished.
- **A guard I defeated with my own comment.** The identifier test's filter
  matched the verdict headline. Its two siblings already carry the exclusion,
  with a comment explaining the trap. I wrote that comment and did not apply it
  three functions later.
- **Three of my fixes initially had no guard.** After correcting the banner,
  the absent-guardrail notice and `next_step`, a mutation round showed all
  three could regress silently. Mutating AFTER fixing is what caught it.
- **`pyproject.toml` was committed by accident** in part 2 - `git add -A` swept
  up a file no commit message mentions. Nothing in the suite caught it.
- **Four pre-existing defects filed**, none of them this change's fault.
- **Evidence:** EV-S9-1, eight mutations, all caught. Suite 1316; clean clone
  1310.
- **Next:** ship.
