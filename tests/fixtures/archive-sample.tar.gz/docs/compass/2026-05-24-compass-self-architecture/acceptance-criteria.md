# Spec - compass-self-architecture

> **Phase:** Specify · **Last updated:** 2026-05-24 · **Owning agent:** spec-author (driven directly in-session)
> **Terrain:** brownfield-mapped - the prior task's `architecture-notes.md` enumerates the principles to be codified; the templates shipped by the prior task fix the form. No blueprint-distillation needed.

## How each role reads this file

- **Product owner / manager** - n/a (no `brief.md`; engineer-framed task driven by the prior task's plan.md §5 follow-on #2).
- **Product marketer** - n/a (no `positioning.md`, no public claims; Compass's `architecture/` is internal documentation of the framework's own design).
- **Engineer** - reads for *tests*: scenarios are the acceptance suite for the documentation artifacts and the mechanism integration that follows from them.
- **QA** - reads for *coverage*: regression scenarios (Group E) protect the previously-shipped mechanism from drift caused by the new artifacts.
- **Designer** - n/a (no UI surface).

---

## Intent links

| Intent id | Source | Statement |
|---|---|---|
| **INT-1** | Previous task's plan.md §5 item #2 (Q15 follow-on); the Compass framework should adopt its own `architecture/` using the mechanism it just shipped - dogfooding. |
| **INT-2** | Previous task's `architecture-notes.md` §2; the 8 invariants (Inv-1..Inv-8 protecting P1..P8) must be encoded as ADRs in Compass's own `architecture/decisions/` so future framework-touching tasks have a documented contract to consult. |
| **INT-3** | Proposal §3 of the previous task; Compass's `architecture/` doubles as a worked example for adopters - what shape an `architecture/` tree should take, what an ADR looks like in practice, how much narrative is enough. |
| **INT-4** | Previous task's TRC-A1, TRC-A5; the new artifacts integrate cleanly with the previously-shipped Frame-load mechanism - `architecture-loaded.yml` populated with real content, SHA-256 recorded per artifact, ADRs parsed into the record. |
| **INT-5** | Previous task's TRC-A2, TRC-A5b, TRC-F* (regression); existing tests pass, projects without `architecture/` continue to no-op cleanly, no new lint debt versus baseline. |
| **INT-6** | Route.md §"Notes for downstream phases" item 6 (the in-scope CLAUDE.md amendment); CLAUDE.md's `architecture/` paragraph is updated *atomically* with the new artifacts so there's no transient window where the doc claims "when adopted" while Compass has adopted. |

---

## Scenario group A - Narrative artifacts ship with required structure

**Independence note:** Three sibling files at `architecture/{system-context.md, relations.md, ownership.md}`. Disjoint content; can be authored independently if Plan splits them, but they cross-reference each other (system-context defines the components; relations describes how they interact; ownership says what each must / must not own). Probably authored in a single sequence.

### Scenario: system-context.md exists with the canonical sections
<!-- traceability id: TRC-A1 · serves: INT-1, INT-3 -->

```gherkin
Scenario: Compass ships system-context.md at the repo root
  Given the Compass repository on the post-task main branch
  When I read <project>/architecture/system-context.md
  Then the file exists and is non-empty
  And it has the sections expected by templates/architecture/system-context.md
       (at minimum: Purpose, Components, External dependencies, Boundary
        conditions, Open questions)
  And each Component section names which Compass logical surface it represents
       (pipeline, router, guardrails, strategies, role pipeline)
  And the file's STATUS: header reads ACCEPTED (not DRAFT, not PROVISIONAL)
```

### Scenario: relations.md documents the call graph between framework components
<!-- traceability id: TRC-A2 · serves: INT-1, INT-3 -->

```gherkin
Scenario: relations.md states who reads/writes whom
  Given the Compass repository on the post-task main branch
  When I read <project>/architecture/relations.md
  Then the file exists and is non-empty
  And it lists, for each pair of components named in system-context.md,
       either an explicit relation (caller -> callee, with the transport)
       or an explicit "no relation" line
  And the file enumerates at least the following relations:
       - cli/compass reads governance/, architecture/, .compass/work/
       - hooks/pre-tool.sh reads .compass/work/<task>/.red
       - hooks/stop.sh reads governance/signals.yml and .compass/work/<task>/devlog.md
       - the architect-lens reads architecture/ but never architecture-draft/
```

### Scenario: ownership.md documents what each component must and must not do
<!-- traceability id: TRC-A3 · serves: INT-1, INT-2, INT-3 -->

```gherkin
Scenario: ownership.md encodes the boundary rules
  Given the Compass repository on the post-task main branch
  When I read <project>/architecture/ownership.md
  Then the file exists and is non-empty
  And it has a "Must own" section for each component named in system-context.md
  And it has a "Must not do" section that cites the boundary risks from the
       prior task's architecture-notes.md (e.g. "calibration must not mutate
       task.yml"; "rework-scan must not exit non-zero on detection";
       "architect-lens must not emit Gherkin scenarios")
```

---

## Scenario group B - ADRs encode P1..P8

**Independence note:** Each ADR is a self-contained file. They cross-reference where superseding/supersession applies, but for v1 there are no supersessions (these are the founding ADRs).

### Scenario: An ADR exists for each principle (clustered into six)
<!-- traceability id: TRC-B1 · serves: INT-2 -->

```gherkin
Scenario: architecture/decisions/ contains exactly six founding ADRs
  Given the Compass repository on the post-task main branch
  When I list <project>/architecture/decisions/ADR-*.md
  Then there are exactly six ADR files:
       ADR-001 covers Inv-1 (readings is judgement-only) + Inv-7 (deterministic mechanism)
       ADR-002 covers Inv-2 (five guardrails) + Inv-3 (adaptive routing untouched)
       ADR-003 covers Inv-4 (Flow advises, never gates)
       ADR-004 covers Inv-5 (one spec, many lenses)
       ADR-005 covers Inv-6 (persistence over conversation)
       ADR-006 covers Inv-8 (backward compat non-negotiable)
  And no two ADRs share a number
  And every ADR's filename matches the pattern ADR-NNN-<slug>.md where NNN is
       a zero-padded sequential integer starting at 001
  And every principle P1..P8 is referenced by exactly one ADR
       (via the architecture-notes.md "Inv-N" → ADR-NNN mapping)
```

### Scenario: Each ADR has the required structure
<!-- traceability id: TRC-B2 · serves: INT-2, INT-3 -->

```gherkin
Scenario: ADRs follow the template structure
  Given the Compass repository on the post-task main branch
  When I read each file under <project>/architecture/decisions/ADR-*.md
  Then every ADR has frontmatter with: id, title, status, date, supersedes,
       superseded_by
  And every ADR has these sections in order: Context, Decision, Alternatives
       considered, Consequences, References
  And every ADR's status is either "accepted" (the standard case for these
       founding decisions) or "proposed" (for any deliberate not-yet-ratified case)
  And no ADR has status: "draft" - that prefix is reserved for distilled
       drafts that have not yet been reviewed (per the architecture-distillation
       proposal; not used in this task)
```

### Scenario: README.md indexes the ADRs and explains the numbering
<!-- traceability id: TRC-B3 · serves: INT-2, INT-3 -->

```gherkin
Scenario: architecture/decisions/README.md is a usable index
  Given the Compass repository on the post-task main branch
  When I read <project>/architecture/decisions/README.md
  Then the file lists every ADR by number and title, in order
  And it explains the numbering convention (sequential per-tree, never
       reused, supersession via "superseded_by" not by renumbering)
  And it cross-references which ADR codifies which principle (P1..P8)
```

### Scenario: At least one ADR demonstrates the alternatives-considered shape with substance
<!-- traceability id: TRC-B4 · serves: INT-3 -->

```gherkin
Scenario: Worked-example quality of ADR rationale
  Given the Compass repository on the post-task main branch
  When I read every ADR under architecture/decisions/
  Then at least one ADR's "Alternatives considered" section enumerates two
       or more alternatives the framework genuinely could have chosen
  And at least one ADR's "Consequences" section names a *negative*
       consequence the decision commits Compass to
       (the test is that the ADR sounds like a real decision, not a
        retro-justification)
```

---

## Scenario group C - Mechanism integration

**Independence note:** Tests the previously-shipped mechanism against this task's new content. No new code; just confirming the mechanism behaves correctly on real input.

### Scenario: frame_load_architecture returns the new artifacts
<!-- traceability id: TRC-C1 · serves: INT-4 -->

```gherkin
Scenario: Frame loads Compass's own architecture/ into the task spine
  Given the Compass repository on the post-task main branch
  And a throwaway task with a task_dir under .compass/work/
  When I invoke frame_load_architecture(project_root=<compass repo>,
                                         task_dir=<throwaway task dir>)
  Then the returned dict has artifacts:
       - one entry per file in architecture/ (system-context.md, relations.md,
         ownership.md)
       - each with path, sha256, and type: narrative
  And the returned dict has adrs:
       - one entry per file in architecture/decisions/ADR-*.md
       - each with id, path, title, status
  And the architecture-loaded.yml on disk matches the returned dict
```

### Scenario: SHA-256 is recorded per artifact (deterministic mechanism, Inv-7)
<!-- traceability id: TRC-C2 · serves: INT-4 -->

```gherkin
Scenario: The load record carries SHA-256 hashes
  Given an invocation of frame_load_architecture as above
  When I inspect the produced architecture-loaded.yml
  Then every artifacts[] entry has a sha256 field whose value matches
       hashlib.sha256(<file contents>).hexdigest()
  And the same invocation produces the same output (deterministic)
```

### Scenario: Architect-lens has substance to consult on a framework task fixture
<!-- traceability id: TRC-C3 · serves: INT-2, INT-4 -->

```gherkin
Scenario: Lens consultation references Compass's own ADRs
  Given a fixture at tests/fixtures/self-architecture/hypothetical-framework-task/
       containing a minimum-viable route.md + task.yml with readings.touches=[public-api]
  And the architect-lens is invoked against the fixture (reading the live
       <project>/architecture/ directory)
  When the lens produces architecture-notes.md inside the fixture's task spine
  Then architecture-notes.md cites at least one of Compass's six founding ADRs
       by id (ADR-001 .. ADR-006)
  And the cited ADR's content is relevant to the fixture task's surface
       (the test is that the lens is reading real content, not echoing a
        canned response)
```

---

## Scenario group D - CLAUDE.md amendment in lockstep

**Independence note:** Single file edit; coupled to the artifacts (the doc must not assert the artifacts exist before the artifacts are committed).

### Scenario: CLAUDE.md notes Compass itself ships an architecture/
<!-- traceability id: TRC-D1 · serves: INT-6 -->

```gherkin
Scenario: The architecture/ paragraph is amended
  Given the Compass repository on the post-task main branch
  When I read <project>/CLAUDE.md
  Then the section titled "Where state lives" contains a paragraph that
       mentions Compass ships its own architecture/ as a worked example
  And the paragraph references that it doubles as documentation for
       adopters to study
  And the amendment lands in the same commit as the architecture/ files
       (no transient window where CLAUDE.md asserts content that doesn't yet
        exist on disk)
```

### Scenario: CLAUDE.md does not claim features that don't exist
<!-- traceability id: TRC-D2 · serves: INT-6 -->

```gherkin
Scenario: The amendment respects "no unbuilt-feature docs"
  Given the Compass repository on the post-task main branch
  When I read <project>/CLAUDE.md
  Then it does NOT mention /compass:architecture-review
  And it does NOT mention architecture-draft/
  And it does NOT mention "PROVISIONAL decay"
       (these are concepts from the architecture-distillation proposal that
        is NOT in scope here; CLAUDE.md must not advertise them until built)
```

---

## Scenario group E - Backward compatibility + regression

**Independence note:** Pure regression - confirms that adding Compass's own `architecture/` doesn't break the previously-shipped mechanism or break tasks that don't have an architecture/.

### Scenario: Existing test suite still passes
<!-- traceability id: TRC-E1 · serves: INT-5 -->

```gherkin
Scenario: pytest 161/161 holds after this task lands
  Given the Compass repository on the post-task main branch
  When I run `pytest tests/`
  Then the suite passes with the same count as the prior task's baseline
       (161 tests minimum; this task may add new tests but must not break any)
```

### Scenario: Projects without architecture/ still no-op cleanly
<!-- traceability id: TRC-E2 · serves: INT-5 -->

```gherkin
Scenario: frame_load_architecture against a project with no architecture/ returns empty
  Given a temporary project directory with no architecture/ subdir
  And a task_dir inside that temporary project
  When I invoke frame_load_architecture(project_root=<temp dir>, task_dir=<temp task dir>)
  Then the returned dict has artifacts: [] and adrs: []
  And no error is raised
  And the architecture-loaded.yml on disk reflects the empty state
  # This is the TRC-A2/A5b backward-compat case from the prior task,
  # re-verified now that Compass itself has an architecture/.
```

### Scenario: compass check still passes 10/10
<!-- traceability id: TRC-E3 · serves: INT-5 -->

```gherkin
Scenario: Mechanical gates still clear
  Given the Compass repository on the post-task main branch
  And the active task is compass-self-architecture with all phases complete
  When I run `python3 cli/compass check --task compass-self-architecture`
  Then the result is "PASS - all 10 check(s) passed"
```

### Scenario: Lint count does not regress
<!-- traceability id: TRC-E4 · serves: INT-5 -->

```gherkin
Scenario: ruff finds no more errors than baseline
  Given the Compass repository on the post-task main branch
  And the prior task's lint baseline of 11 errors
  When I run `ruff check tests/ cli/compass`
  Then the error count is at most 11
       (this task adds narrative documents, no Python code, so a fresh
        lint regression would be a signal that something else changed)
```

---

## Failure-mode scenarios

### Scenario: A malformed ADR's frontmatter fails Frame loudly
<!-- traceability id: TRC-X1 · serves: INT-4 -->

```gherkin
Scenario: Frame refuses to silently swallow a malformed ADR
  Given an ADR file at architecture/decisions/ADR-099-malformed.md with
       broken YAML frontmatter or a missing required field
  When frame_load_architecture is invoked
  Then it fails with a non-zero exit code (or raises an exception, if invoked
       as a Python helper)
  And the failure message names the file path and the parse error
  # This is the TRC-X1 failure mode from the prior task, re-verified for
  # ADR files specifically.
```

### Scenario: ADRs with status "proposed" are loaded but flagged (fixture-based)
<!-- traceability id: TRC-X2 · serves: INT-4 -->

```gherkin
Scenario: A proposed (not yet accepted) ADR appears in the load record with its status
  Given a fixture at tests/fixtures/self-architecture/proposed-adr/architecture/
       containing the synthetic file decisions/ADR-099-proposed-example.md with
       frontmatter status: proposed
  When frame_load_architecture runs against that fixture as project_root
  Then the ADR appears in the produced architecture-loaded.yml's adrs list
  And its status field reads "proposed" (not "accepted")
  # This task ships only ACCEPTED ADRs (the six founding decisions); proposed
  # is for future decisions in flight. The fixture covers the mechanism's
  # behaviour on proposed-status without committing fake content into
  # Compass's own architecture/.
```

---

## Coverage ledger

| Traceability id | Serves intent | Has a failing test (Build) | Passes as acceptance (Verify) |
|---|---|---|---|
| TRC-A1 | INT-1, INT-3 | [ ] | [ ] |
| TRC-A2 | INT-1, INT-3 | [ ] | [ ] |
| TRC-A3 | INT-1, INT-2, INT-3 | [ ] | [ ] |
| TRC-B1 | INT-2 | [ ] | [ ] |
| TRC-B2 | INT-2, INT-3 | [ ] | [ ] |
| TRC-B3 | INT-2, INT-3 | [ ] | [ ] |
| TRC-B4 | INT-3 | [ ] | [ ] |
| TRC-C1 | INT-4 | [ ] | [ ] |
| TRC-C2 | INT-4 | [ ] | [ ] |
| TRC-C3 | INT-2, INT-4 | [ ] | [ ] |
| TRC-D1 | INT-6 | [ ] | [ ] |
| TRC-D2 | INT-6 | [ ] | [ ] |
| TRC-E1 | INT-5 | [ ] | [ ] |
| TRC-E2 | INT-5 | [ ] | [ ] |
| TRC-E3 | INT-5 | [ ] | [ ] |
| TRC-E4 | INT-5 | [ ] | [ ] |
| TRC-X1 | INT-4 | [ ] | [ ] |
| TRC-X2 | INT-4 | [ ] | [ ] |
