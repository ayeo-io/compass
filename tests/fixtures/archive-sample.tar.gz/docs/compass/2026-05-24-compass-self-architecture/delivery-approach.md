# Route - compass-self-architecture

> **Task:** Populate Compass's own `architecture/` directory at the framework repo root, using the mechanism the previous task shipped (cross-task-architectural-integrity). The Q15 meta-bootstrap: the framework adopts what it just preached.
> **Framed:** 2026-05-24 by jed72 (via /compass:frame) · **Revision:** 1
> **Reference route:** Standard

---

## 1. The four dimension readings

| Dimension | Reading | One-line justification |
|---|---|---|
| **Blast radius** | contained | New narrative content under `architecture/` - additive only, no behaviour change. The architect-lens reads this from now on but it doesn't gate any task; failure mode is "lens degrades" (already tested in TRC-B4), not "task breaks". |
| **Terrain** | brownfield-mapped | The templates shipped by the previous task tell us the exact shape. P1–P8 invariants and the boundary risks are already enumerated in `.compass/work/cross-task-architectural-integrity/architecture-notes.md` - the seed content is on disk. |
| **Magnitude** | standard | Three narrative documents (`system-context.md`, `relations.md`, `ownership.md`), 5–8 ADRs for the principles + the decisions index, plus per-decision rationale. Not atomic; real design choices on phrasing, combining, and numbering. Estimating up: not small. |
| **Intent & role** | engineer · delivery | Documentation-driven feature. We know what we're building (the prior task laid out the content); not exploration. |

**Domain tags (`touches:`):** none.

No public-API change (no CLI / command / agent / schema additions in this task - it consumes the previously-shipped mechanism). No floor in `RG-FLOOR-*` triggers.

---

## 2. The composed candidate route

Candidate route: **Standard**, with these deviations from its reference shape:

- none.

Composition came from `RS-SHAPE-005` (`magnitude: standard` → lean `standard`). The other shapes did not match: RS-SHAPE-003 requires atomic/small magnitude on mapped ground with trivial/contained blast radius (magnitude here is *standard*, not small); RS-SHAPE-004 requires large/product magnitude.

Candidate review dimensions: `correctness, governance, traceability, regression, clarity, security` (Standard's gate set per `route_shapes.standard.gates` in `routing-policy.yml`).

---

## 3. Routing guardrails that fired

| Rule type | Rule | What it changed | Rationale (quoted from the policy) |
|---|---|---|---|
| - | - | - | - |

**No routing guardrail fired.** Candidate route stands.

Floors not triggered: `RG-FLOOR-001` (blast_radius is contained, not critical); `RG-FLOOR-002` (terrain is brownfield-mapped, not -unmapped); `RG-FLOOR-003` (touches is empty). Caps not triggered: `RG-CAP-001` (not critical). Immovable gates `RG-GATE-001..003` are stapled onto every delivery route - already part of Standard's gate set.

---

## 4. The final route

### 4a. Per-phase weight

| Phase | Weight | Notes |
|---|---|---|
| Frame | Full | This document is the output. Pre-flight: `frame_load_architecture` invoked, returned empty (Compass has no `architecture/` yet - TRC-A2 / A5b backward-compat case confirmed live). |
| Specify | Full | Multiple deliverables (narrative files + ADRs) need scenarios. The architect-lens (now existing) is consulted at Specify - it has nothing to read (Compass's architecture is what *this task* creates), so it writes "no architectural risk identified" and proceeds. A meta-bootstrap echo of TRC-X5 from the previous task. |
| Clarify | Light | A light pass - the content seed is already on disk in the previous task's architecture-notes; main ambiguities to resolve are *editorial* (how granular are the ADRs? P1–P8 as one ADR each, or one ADR per cluster?) and *numbering* (do we keep the previous task's five worked-example ADR slugs in `templates/architecture/decisions/`, or do those stay as examples and we number Compass's own from ADR-001 in `architecture/decisions/`?). |
| Plan | Full | Need a real plan.md - ordering of authoring, dependency between system-context.md and the relations/ownership content, how ADRs cluster (P1–P8 might collapse to ~5 ADRs since some pairs are tightly coupled, e.g. P2 + P4). |
| Distribute | Solo (within solo-or-pair) | Pure prose authoring on a single body of related content. Splitting into streams would invent coordination cost where none is needed. |
| Build | Full | Author the artifacts. TDD discipline: write a structural test first ("system-context.md exists with required sections"), then write the content. New tests live under `tests/` like any other Compass test. |
| Verify | Full | All six Standard gates. Of note: `verify.regression` runs the existing test suite to confirm Compass's *own* architecture/ artifacts being present don't break Frame for tasks that worked before. The new `frame_load_architecture` will now load real content instead of returning empty - a behavioural change. |
| Land | Full | Coordinated single commit (solo route). Update CLAUDE.md if any consumer-facing detail changes (the §"architecture/ also lives at project root, when adopted" paragraph might want a "and Compass itself ships one" amendment). Push to a feature branch + PR per the repo protection rules. |

### 4b. Gate set

- Number of gates: **6** (Standard's full set).
- Review dimensions applied: `correctness, governance, traceability, regression, clarity, security`.
- Immovable gates stapled on (from `routing-policy.yml`): `verify.correctness, verify.governance, verify.traceability`.
- Note: `verify.claims` is NOT in Standard's gate set (it's Expedition-only). No marketer in play; no claims to back.

### 4c. Swarm topology

- Topology: **solo** (within `solo-or-pair`)
- Stream count: **1** - work happens on a single branch
- Worktree root: n/a (solo route - no worktree)
- Cap in effect: **none**
- Orchestrator agent: **no** - solo routes have no orchestrator

---

## 5. The de-scope ledger

| Phase / check | Action | Safe to skip / collapse because… |
|---|---|---|
| Clarify (light, not full) | light pass | Standard's reference shape; not a de-scope. The content seed is already on disk (architecture-notes.md from the previous task) so a heavy Clarify would be cargo-cult. |
| Distribute (solo, not pair/swarm) | solo within `solo-or-pair` | Pure prose authoring of related content; no disjoint code surfaces to parallelise. Inventing streams would add merge cost without parallel speedup. |

Note: Standard's `solo-or-pair` topology means "no swarm" - pair is allowed when a clear two-stream split exists. None does here. This is a topology selection within the route, not a de-scope.

---

## 6. Owed backfills

- [x] **None owed.** No ceremony borrowed from upstream; not a Hotfix; no phases skipped; no claims.

---

## 7. Human overrides

| What was overridden | From → To | Who | Why |
|---|---|---|---|
| - | - | - | - |

**No human overrides yet.** Route presented in chat; awaiting confirmation before Specify.

---

## 8. Confirmation

- [ ] Route presented to the invoker and confirmed (or overridden - see §7).
- [x] Every dimension in §1 has a justification.
- [x] §5 records the topology selection within Standard.
- [x] No `.spike` marker (not a Spike route).
- [ ] `devlog.md` opened with the Frame entry.

Next phase: **Specify** (`/compass:specify`).

---

## Notes for downstream phases

1. **The Q15 meta-bootstrap shape.** This task creates Compass's own `architecture/` for the first time. Until this task lands, `frame_load_architecture` returns an empty record on every Compass-framework task (verified above). After this task lands, it'll return real content - and the architect-lens consultation will fire for the first time with substance to consult. That's a behavioural change to verify at Verify.

2. **Seed content already enumerated.** `.compass/work/cross-task-architectural-integrity/architecture-notes.md` already enumerates:
   - The 5 logical surfaces of Compass (pipeline, router, guardrails, strategies, role pipeline) - seed for `system-context.md`
   - 8 invariants (Inv-1..Inv-8 protecting P1..P8) - seed for ADRs
   - 6 boundary risks (B-Risk 1..6) - seed for `ownership.md`'s "what each component must not do" section
   The work is curation + reformatting, not invention.

3. **Architect-lens consultation at Specify.** This task SHOULD invoke `/compass:roundtable architect-lens` even though there's no `architecture/` yet - it's a meta-test that the lens degrades gracefully on a project that's about to acquire architecture/. The lens will write "no architectural risk identified - architecture/ artifacts about to be authored" or similar.

4. **ADR clustering decision** is the main Clarify question. P1–P8 → 8 ADRs is faithful but verbose; clustering (e.g. P2+P4 about guardrail/strategy structure into one ADR; P3+P6 about evidence and persistence into one) yields ~5 ADRs which is closer to the size-shape of the worked-example ADRs in `templates/`.

5. **Don't touch the templates.** The five worked-example ADRs in `templates/architecture/decisions/ADR-001-..ADR-005-..md` stay as templates. Compass's own ADRs go in `architecture/decisions/` and re-number from 001 (decision-record numbering is per-tree, per Q7 of the previous task's clarifications).

6. **Living-doc update at Land.** CLAUDE.md's paragraph about `architecture/` (`§"Where state lives"`) currently reads "architecture/ also lives at the project root, sibling to governance/, when adopted." After this task, Compass itself ships an architecture/. The paragraph might want a small amendment ("...and Compass itself ships one - read it for the framework's own invariants and ownership rules").
