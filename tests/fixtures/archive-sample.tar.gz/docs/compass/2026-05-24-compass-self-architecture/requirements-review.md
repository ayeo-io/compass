# Clarifications - compass-self-architecture

> **Phase:** Clarify · **Date:** 2026-05-24 · **Owning agent:** spec-author (driven in-session)
> **Clarify weight (from route.md):** light pass

---

## Self-QA of the spec

Spec is internally consistent in shape - every scenario has Given/When/Then with observable Thens; no contradictions found. Three real ambiguities to resolve:

- **F-SQA-1.** TRC-B1 specifies "between 5 and 8 inclusive" ADRs; the exact number must be locked before Build authors them. → Q1.
- **F-SQA-2.** TRC-X2 reads from `architecture/decisions/ADR-007-proposed-example.md` - implying Compass would *ship* a proposed-status ADR in its own architecture. That's wrong: this task ships accepted founding ADRs, not proposed ones. The mechanism for proposed-status loading should be tested via a fixture, not via real content. → Q3.
- **F-SQA-3.** TRC-C3 invokes the architect-lens against a "hypothetical task with route.md indicating touches: [public-api]" - needs a concrete fixture path, not a hypothetical. → Q4.

## Governance QA of the spec

- **G1, G2, G3:** every scenario has a test path, traceability id, and intent link. ✓
- **G4 (evidence, not assertion):** every scenario asserts observable file-state or command-output outcomes. ✓
- **G5 (irreversible):** does establishing Compass's own architecture/ qualify? It's *lightly* irreversible - once shipped, future framework tasks read it; removing it would be a breaking change. But it does not cross the G5 line (no data loss / money / auth / personal data / migrations). **No G5 trigger.** → Q5 records this.
- **S1 (BDD), S2 (TDD), S3 (simplest thing), S4 (persistence):** honoured throughout.
- **Routing:** Standard still fits - nothing in the spec surfaces magnitude that would push to Expedition.

---

## Ambiguity ledger

### Q1 - ADR clustering: how many ADRs encode P1..P8?

- **Question:** P1..P8 (8 invariants from the prior task) → how many ADRs in `architecture/decisions/`? TRC-B1 allows 5–8 inclusive; need to pick.
- **Resolution:** **6 ADRs.** Cluster tightly-coupled invariants into single ADRs; keep distinct concerns separate:
  - **ADR-001 - Judgement vs mechanism are separated** (covers Inv-1 *readings is judgement-only* + Inv-7 *mechanism is deterministic*). They're the two halves of the same split: judgement lives in one named place; everything else is computed from it deterministically.
  - **ADR-002 - The framework grows by adding artifacts and lenses, not by adding guardrails or routing dimensions** (covers Inv-2 *five guardrails* + Inv-3 *adaptive routing untouched*). Both about not bloating the framework's rule set.
  - **ADR-003 - Flow advises but never gates** (covers Inv-4). Standalone - cross-task signals are advisory by design, never authoritative.
  - **ADR-004 - One spec, many lenses; the lens annotates, never forks** (covers Inv-5). Standalone - lens design constraint.
  - **ADR-005 - State lives on disk; conversation reconstructs from artifacts** (covers Inv-6 *persistence over conversation*). Standalone - the rule that makes audit possible.
  - **ADR-006 - Backward compat is non-negotiable: every new mechanism no-ops cleanly on projects that haven't adopted it** (covers Inv-8). Standalone - the adoption-friendliness rule.
- **Decided by:** jed72.
- **Governance reference:** S3 (simplest thing) - 6 is enough to do the work without padding; 8 would split tightly-coupled concerns artificially.
- **Spec change:** TRC-B1 amended - "the count is exactly 6" instead of "between 5 and 8 inclusive".
- **Status:** resolved.

### Q2 - TRC-D2's forbid-list: strict, or with a planned-feature mention?

- **Question:** CLAUDE.md must not advertise unbuilt features. Three are explicitly forbidden in TRC-D2: `architecture-draft/`, `/compass:architecture-review`, "PROVISIONAL decay". Should we keep strict, or add a light "a distillation capability is planned" mention?
- **Resolution:** **Strict forbid.** The architecture-distillation proposal lives at `a private planning document` which is *gitignored* - adopters cannot see it. Mentioning a capability they can't access is confusing; advertising unbuilt features is the failure mode the framework was designed to prevent. The three explicit forbids stay.
- **Decided by:** jed72 (the proposal author also chose to keep it local).
- **Governance reference:** S4 (persistence over conversation) - if it's not on disk *in a place adopters read*, it's not real to them. Plus the "no doc for unbuilt features" principle implicit in the prior task's proposal.
- **Spec change:** none - TRC-D2 already encodes the strict version.
- **Status:** resolved.

### Q3 - TRC-X2 (proposed-status ADRs): in scope or defer? Fixture-based or real?

- **Question:** The mechanism for loading "proposed" status ADRs is part of the prior task's `frame_load_architecture` but may not be tested. Should this task test it?
- **Resolution:** **In scope, fixture-based.** TRC-X2 stays as a coverage scenario - it tests the previously-shipped mechanism against a genuine code path that may otherwise be untested. But the test uses a **fixture** under `tests/fixtures/self-architecture/proposed-adr/` rather than a real proposed ADR in Compass's own `architecture/`. This task ships only *accepted* ADRs (the six founding decisions); proposed-status is for future decisions in flight, not for this delivery.
- **Decided by:** jed72.
- **Governance reference:** G3 (traceability - code paths in the framework need scenario coverage) + S3 (simplest thing - fixture is lighter than authoring a fake "open decision").
- **Spec change:** TRC-X2 reworded - Given changes from `architecture/decisions/ADR-007-proposed-example.md` to `tests/fixtures/self-architecture/proposed-adr/ADR-099-proposed-example.md` (use number 099 to avoid future-conflict with sequentially-allocated real ADRs).
- **Status:** resolved.

### Q4 - TRC-C3 (lens consultation): what's the "hypothetical task" fixture?

- **Question:** TRC-C3 invokes the architect-lens against "a hypothetical task with route.md indicating touches: [public-api]". The lens needs a concrete task directory to read from.
- **Resolution:** Use a fixture under `tests/fixtures/self-architecture/hypothetical-framework-task/` containing a minimum-viable `route.md` + `task.yml` with the touches=[public-api] marker. The lens reads `architecture/` (Compass's real one, the one this task creates) and the hypothetical task's spine; produces `architecture-notes.md` referencing real ADR ids.
- **Decided by:** jed72.
- **Governance reference:** P3 (evidence, not assertion) - the test is meaningful only if the lens produces real output against real `architecture/`.
- **Spec change:** TRC-C3 reworded to name the fixture path explicitly.
- **Status:** resolved.

### Q5 - G5 trigger for this task?

- **Question:** Does establishing Compass's own `architecture/` constitute irreversible work that needs G5 human approval?
- **Resolution:** **No G5 trigger.** The kind of irreversibility G5 names (data loss / money / auth / personal data / migrations) does not apply. The architectural-baseline irreversibility - once Compass has an `architecture/`, removing or substantially restructuring it would be a breaking change for any consumer that has come to rely on it - is real but minor. The risk is fully addressed by: (a) the Verify phase's reviewer dimensions; (b) the architect-lens reading this content from now on (any future framework task that touches an ADR gets visibility through the lens); (c) ADR supersession is the canonical change mechanism, not deletion.
- **Decided by:** jed72.
- **Governance reference:** G5 - non-trigger explicitly recorded.
- **Spec change:** none.
- **Status:** resolved.

---

## Spec changes summary (to be applied to `spec.feature.md`)

| Scenario | Change |
|---|---|
| TRC-B1 | Change "between 5 and 8 inclusive" → "exactly 6"; cite the cluster decisions (ADR-001 covers Inv-1+Inv-7, etc.). |
| TRC-X2 | Reword Given to use `tests/fixtures/self-architecture/proposed-adr/ADR-099-proposed-example.md` (fixture path) instead of a real ADR in architecture/decisions/. |
| TRC-C3 | Reword Given to use `tests/fixtures/self-architecture/hypothetical-framework-task/` (fixture-based hypothetical task) instead of an abstract "hypothetical task". |

---

## Gate

- [x] No ambiguity left `open` - every entry is `resolved`.
- [x] `spec.feature.md` updated to reflect every resolution. *(Pending - applied immediately after this file is written.)*
- [x] Non-engineering roles in play have reviewed (Standard: review only if a role is in play). *(No non-engineering role in play; engineer is the sole role.)*

### Definition of Ready

- [x] **Problem traces up** - every TRC links to one of INT-1..INT-6; each intent links to the prior task's plan.md §5 item #2 (Q15 follow-on) or to the prior task's architecture-notes.md.
- [x] **Behaviour is Given/When/Then** - every scenario in `spec.feature.md` has an observable Then. No wishful scenarios.
- [x] **Traceability ids assigned** - TRC-A1..A3, TRC-B1..B4, TRC-C1..C3, TRC-D1..D2, TRC-E1..E4, TRC-X1..X2 (18 total).
- [x] **Affected surface named** - `route.md` identifies the surfaces; this clarifications.md adds: `architecture/{system-context.md,relations.md,ownership.md}` (new); `architecture/decisions/README.md` (new); `architecture/decisions/ADR-001..ADR-006.md` (new, six files); `CLAUDE.md` (small amendment); `tests/test_self_architecture.py` (new); `tests/fixtures/self-architecture/{proposed-adr,hypothetical-framework-task}/` (new fixture dirs).
- [x] **No open questions** - Q1..Q5 all resolved.
- [x] **Route still fits** - Standard is correct. The 5 clarifications confirmed magnitude=standard; nothing surfaced suggests the route was under- or over-sized.

Next phase: **Plan** (`/compass:plan`).
