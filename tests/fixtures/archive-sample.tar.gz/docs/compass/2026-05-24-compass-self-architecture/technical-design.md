# Plan - compass-self-architecture

> **Phase:** Plan · **Date:** 2026-05-24 · **Owning agent:** planner (driven in-session)
> **Plan weight (from route.md):** plan.md only (Standard, solo)

---

## 1. Approach

Author Compass's own `architecture/` tree using the mechanism the prior task shipped. The work is documentation authoring with structural-assertion tests - no new framework code, no new mechanisms. Seven authoring deliverables, one tiny living-doc amendment, one test file with two small fixtures.

**Authoring order** (dependency-driven):

1. **Anchor the system first.** Author `architecture/system-context.md`. The five logical surfaces (pipeline, router, guardrails, strategies, role pipeline) are named; each gets a Purpose paragraph and a one-liner per component. The other narrative files reference this one.
2. **Then describe how the pieces relate.** Author `architecture/relations.md` from the cross-references found in the codebase (the CLI reading `governance/`; hooks reading `task.yml`; the architect-lens reading `architecture/` but never `architecture-draft/`). This is the call-graph and read-graph between framework components.
3. **Then state the boundaries.** Author `architecture/ownership.md`. The "Must own" sections come from the components in (1); the "Must not do" sections come directly from the prior task's B-Risks 1–6 (those were already the boundary risks the framework's invariants protect - they're literally what `ownership.md` is for).
4. **Then codify the principles.** Author the six ADRs per the Clarify mapping (Q1):
   - **ADR-001 - Judgement and mechanism are separated.** Inv-1 + Inv-7.
   - **ADR-002 - The framework grows by adding artifacts and lenses, not rules.** Inv-2 + Inv-3.
   - **ADR-003 - Flow advises but never gates.** Inv-4.
   - **ADR-004 - One spec, many lenses; the lens annotates, never forks.** Inv-5.
   - **ADR-005 - State lives on disk; conversation reconstructs from artifacts.** Inv-6.
   - **ADR-006 - Backward compat is non-negotiable.** Inv-8.
5. **Then write the index.** Author `architecture/decisions/README.md` listing the six ADRs, explaining the numbering convention (sequential per-tree, never reused, supersession via `superseded_by`), and cross-referencing which ADR codifies which principle.
6. **Then update the doc that references the artifact.** Amend the `architecture/` paragraph in `CLAUDE.md` - three sentences across one paragraph, recording that Compass itself ships one. **Critical:** this amendment lands in the same commit as the artifacts (TRC-D1 - no transient window).
7. **Then write the tests.** Author `tests/test_self_architecture.py` with the 18 scenarios as test functions. Create the two fixture directories under `tests/fixtures/self-architecture/`. TDD discipline applies: each test goes red first, then the artifact change makes it green.

**Authoring order is dependency-driven, not parallel-streamable.** Step 2 references step 1; step 4 (ADRs) references step 3 (ownership); step 5 (index) references step 4; step 6 (CLAUDE.md) is small and trailing. Step 7 (tests) wraps around the whole thing per TDD.

**Bootstrap echo:** the architect-lens exists now (shipped by the prior task) but is not auto-triggered for this task (`touches: []`). The lens would have nothing to consult yet anyway - Compass's `architecture/` is what *this* task creates. I am acting as the human architect for this task (same shape as the prior task's Q12 bootstrap, lighter weight): the architectural decisions live in this `plan.md` and an optional `architecture-notes.md` may be added at Build if a non-trivial boundary surfaces. For now, no architectural risk requiring escalation.

---

## 2. Design decisions (ADR-style)

### DD-1 - Six founding ADRs, clustered as locked at Clarify

- **Context:** P1..P8 (the eight principles in the prior task's `architecture-notes.md`) need to be codified as Compass's own ADRs. 8 separate files is faithful but verbose; cluster-mapping into 6 keeps the same coverage with cleaner boundaries.
- **Decision:** Six ADRs with the cluster mapping in §1 step 4 above. ADR-001 and ADR-002 each cover two invariants; ADR-003 through ADR-006 each cover one.
- **Alternatives considered:**
  - **Eight separate ADRs (1:1 with invariants)** - rejected. Inv-1 + Inv-7 are two halves of the judgement/mechanism split; splitting them produces two ADRs whose Context sections recapitulate each other. Same for Inv-2 + Inv-3 (both about "the framework grows narrowly").
  - **Five ADRs (more aggressive clustering, e.g. fold Inv-5 + Inv-6 into one "spec-as-source-of-truth" ADR)** - rejected. Inv-5 (lens annotates) and Inv-6 (persistence over conversation) are conceptually related but the rules they generate are distinct enough that combining them buries one.
- **Consequences:**
  - Six ADRs match the size-shape of the worked-example ADRs in `templates/architecture/decisions/`.
  - Future framework decisions will extend at ADR-007.
  - Cross-reference table in `decisions/README.md` makes the invariant → ADR mapping explicit (per TRC-B3).
- **Governance tie:** S3 (simplest thing) - clustering is simpler than 8 separate files, while keeping the principle coverage intact.

### DD-2 - STATUS: ACCEPTED for all six founding ADRs

- **Context:** ADRs can be DRAFT, PROPOSED, ACCEPTED, SUPERSEDED. The founding ADRs encode decisions Compass has already taken (the prior task tested them as invariants and verified the regression suite).
- **Decision:** All six founding ADRs ship with `status: accepted`. DRAFT is reserved for distilled drafts pending review (per the local architecture-distillation proposal, not in scope here). PROPOSED is reserved for future decisions in flight.
- **Alternatives considered:**
  - **PROPOSED for all six initially, with a deliberate promotion task to mark them ACCEPTED** - rejected. The decisions are already in effect; the test suite (Group F of the prior task) already proves they hold. Marking them PROPOSED would be theatre.
- **Consequences:** Compass's architecture/ comes online as a fully-accepted baseline. Any future amendment is a new ADR that supersedes the relevant ACCEPTED one (per the supersession protocol explained in `decisions/README.md`).
- **Governance tie:** P3 (evidence not assertion) - the prior task's tests are the evidence the decisions hold; ACCEPTED is the honest status.

### DD-3 - Authoring is solo; no pair split

- **Context:** Standard's reference topology is `solo-or-pair`. Could we split into "Stream A - narrative + ADRs" and "Stream B - tests + fixtures"?
- **Decision:** Solo. Single sequence, single branch.
- **Alternatives considered:**
  - **Two-stream pair** - rejected. The work has a strong dependency chain (system-context → relations → ownership → ADRs → README → tests). Tests can't be authored meaningfully until the ADRs exist; the ADRs reference the ownership file; ownership references system-context. Splitting would invent merge cost where no parallel speedup exists.
- **Consequences:** No worktree, no orchestrator. Work on the current branch off post-merge `main` (`9db36e5`).
- **Governance tie:** Routing strategy "prefer the lightest route that still clears every routing guardrail and the applicable gates" - solo is lighter than pair on this shape.

### DD-4 - CLAUDE.md amendment lands in the same commit as the artifacts (TRC-D1)

- **Context:** TRC-D1 requires the CLAUDE.md amendment to land *atomically* with the architecture/ files, no transient window where the doc claims content that doesn't exist on disk.
- **Decision:** A single final commit at end of Build adds all of `architecture/`, the test file, the fixtures, AND the CLAUDE.md edit. Earlier commits during Build (one per scenario red → green) are local progress; the final commit is the "task ships" commit and amends CLAUDE.md as part of it.
- **Alternatives considered:**
  - **Separate commits, one for CLAUDE.md** - rejected by TRC-D1's "same commit" requirement.
- **Consequences:** The PR's diff shows both halves at once - reviewer sees the artifact and the doc-pointer-to-artifact together.
- **Governance tie:** TRC-D1 directly.

### DD-5 - Fixture directories nest under `tests/fixtures/self-architecture/`

- **Context:** Two fixtures are needed (Q3, Q4): a proposed-status ADR fixture and a hypothetical-framework-task fixture.
- **Decision:** Both fixtures live under `tests/fixtures/self-architecture/`:
  - `tests/fixtures/self-architecture/proposed-adr/architecture/decisions/ADR-099-proposed-example.md`
  - `tests/fixtures/self-architecture/hypothetical-framework-task/{route.md, task.yml}`
- **Alternatives considered:**
  - **Inline tmp_path fixtures in the tests** - rejected for these two. They're each small but have meaningful content (a properly-structured proposed ADR; a minimal but coherent task spine); having them as checked-in files makes the tests easier to read and the fixtures inspectable when something fails.
- **Consequences:** Two new directories shipped under `tests/fixtures/`. They join the prior task's `tests/fixtures/rework-scan/add-then-delete-pair/` and `tests/fixtures/route-baseline.yml` as canonical regression inputs.
- **Governance tie:** P3 (evidence not assertion) - fixtures *are* the evidence.

---

## 3. Governance check

| Area | Result | Evidence / note |
|---|---|---|
| **Guardrails (G1–G5)** | **pass** | G1: 18 scenarios with tests in `task.yml.scenarios`. G2: all scenarios Given/When/Then, defined *before* any artifact is authored. G3: every scenario has an intent link (INT-1..INT-6). G4: all scenarios assert observable file-state or command-output outcomes. G5: no trigger per Q5 of clarifications. |
| **Method strategies (S1–S4)** | **followed** | S1 (BDD): scenarios in G/W/T. S2 (TDD): each scenario goes red then green in Build. S3 (simplest thing): drove DD-1 (six clusters not eight separate), DD-3 (solo not pair). S4 (persistence over conversation): every artifact named is a file on disk. |
| **Product strategies** | n/a | No `brief.md`; no product-owner role in play. |
| **Voice & positioning strategies** | n/a | No marketer; no claims. |
| **Routing policy** | **pass** | Route is Standard, no routing guardrails fired (re-confirmed: blast_radius=contained not critical, terrain=brownfield-mapped not unmapped, touches=[] not in any floor's list). Plan does not skip any phase route.md kept; Standard's collapsed `clarify=light` is route-default, not a de-scope. |

`compass policy lint` already PASS on the post-prior-task main (`9db36e5`). No governance YAML changes in this task.

---

## 4. Work units

| Unit | Scenario group(s) it satisfies | Code surface it touches | Independent of |
|---|---|---|---|
| **U1 - narrative authoring** | Group A (TRC-A1, A2, A3) | `architecture/system-context.md`, `relations.md`, `ownership.md` (new) | sequenced before U2; no parallel split |
| **U2 - ADRs + index** | Group B (TRC-B1, B2, B3, B4) | `architecture/decisions/ADR-001..ADR-006.md` + `README.md` (new) | sequenced after U1; before U3 |
| **U3 - CLAUDE.md amendment** | Group D (TRC-D1, D2) | `CLAUDE.md` (edit, ~3 sentences in one paragraph) | sequenced at end with U2; lands in same final commit per DD-4 |
| **U4 - tests + fixtures** | Groups C, E, plus failure modes X1+X2 (TRC-C1, C2, C3, E1, E2, E3, E4, X1, X2) | `tests/test_self_architecture.py` (new), `tests/fixtures/self-architecture/{proposed-adr/, hypothetical-framework-task/}/` (new) | TDD-paired with each authoring step - each test goes red first, then the matching artifact change makes it green |

**Parallelism assessment:** all units share surface (sequenced authoring chain) → **solo**. No distribution-map needed (Standard, no parallel split).

---

## Gate

- [x] Every scenario in `spec.feature.md` is covered by a work unit (18 scenarios → 4 units; mapping in §4).
- [x] Governance check passes - every guardrail clears; no strategy deviation; routing policy honoured.
- [x] If parallel work is possible - n/a, single-stream by DD-3.

Next phase: **Build** (`/compass:build`). Distribute is skipped on solo Standard.
