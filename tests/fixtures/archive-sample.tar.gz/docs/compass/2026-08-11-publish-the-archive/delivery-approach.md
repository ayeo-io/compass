# Delivery approach - publish-the-archive

> **Issue:** Unignore `.compass/work/` so a reader can open the receipts the case study points at.
> **Triaged:** 2026-08-11 · **Revision:** 1
> **Reference shape:** initiative (critical risk, five floors, worktree cap, nine gates)
> **Status: ABANDONED, 2026-08-11, by maintainer decision. Nothing was published. `.gitignore:19` is untouched.**

---

## Why this was abandoned, recorded so nobody re-opens it by accident

The pre-flight scan ran in full before anything was flipped, and it is the
part worth keeping. **The archive is clean**: no credentials, no third-party
personal data, no confidential material, nothing damaging about any named
person or project. 72 issue directories, 1,427 files, 4.7 MiB, no binaries,
and the only username in 1,629 absolute paths is the maintainer's own. If
this is ever revisited, that scan does not need repeating from scratch - only
updating for what has been added since.

What changed the decision was not the scan. It was that **the planning
documents stay private**. `a private planning document` and `a private planning document` remain
gitignored until the framework is where the maintainer wants it. The archive
cites those two directories **186 times across 76 files**. So publishing the
archive alone would have traded "you cannot open the receipts" for "the
receipts are full of things you cannot open" - the same problem one layer
down, bought with a one-way door.

Three further costs, all real and all avoided by not doing it:

- **It would have turned continuous integration red.** `compass ci` passes
  today partly by finding no issues to sweep; with 70 spines tracked it fails
  15 check groups, mostly on issues that are framed but not yet defined.
- **It would have made publishing five real people's names the default.**
  `seeding-trials` records "maintainer writes the five names down" as its next
  action. In a public archive that publishes five participants' names
  alongside their candid reactions to an unreleased tool, with no further
  decision point in the way.
- **`*.log` at `.gitignore:23` is unanchored**, so 382 log files would have
  stayed hidden anyway - and one of them is cited as typed evidence
  (`comparison-requirements/task.yml:241`), which would have given a fresh
  clone a gate failure that does not reproduce locally.

## What replaces it

Curated documentation, later, when the framework is in the shape the
maintainer wants. The idea considered and deferred rather than rejected: a
small extract of one or two exemplar issue directories, chosen because their
citations are self-contained, would give a reader something real to open
without a one-way commitment on the whole archive.

## What this leaves standing elsewhere

- **`archive-quote-verification`** keeps its premise: the archive is not in a
  clone, so the check that would verify a quoted passage still cannot fail
  there. That issue's scope is unchanged by this decision and it is still
  queued.
- **`sweep-respects-queued`** was framed as a blocker for this slice. It is no
  longer blocking, and is queued rather than active. The defect is real - a
  framed-but-undefined issue fails the sweep - it is simply local-only again.
- **The case study must not claim the receipts are openable.** Its disclosure
  paragraph was written for exactly this state and now has to survive the
  third verification pass saying so.

## The assessment, kept for the record

| Dimension | Value | One-line justification |
|---|---|---|
| **Risk** | critical | Publishing to a public repository's history is a one-way door, and the archive was unreviewed for personal data at the time of triage. |
| **Familiarity** | brownfield-mapped | The ignore rules and the archive's shape are both readable. |
| **Size** | small | One line in `.gitignore`, plus the consequences of flipping it. |
| **Goal & role** | engineer, delivery | A reader can open what the case study points at. |

**Labels:** [public-api, personal-data]

Policy rules that fired: RG-FLOOR-001, 004, 005, 006, 007 and the RG-CAP-001
worktree cap. G5 - a human signs off on the irreversible - was pending and was
never cleared, which is the correct end state for an irreversible change that
did not happen.
