# Acceptance criteria - ci-lints-every-issue

> **Issue:** `compass ci` skips schema linting for not-yet-started issues and then claims every issue lints clean.
> **Intents:** INT-1 - a malformed spine is caught whatever stage its issue is at. INT-2 - the sweep's summary states what the sweep did.

---

## Summary

**Goal.** Skipping the gate checks for work that has not started must not also skip the structural lint, and the summary must not claim coverage the run did not perform.

**Approach.** Lint every issue; gate only `cmd_check` on the lifecycle; make the summary carry counts.

**Why now.** It is a false PASS in the cross-issue gate an adopter's build runs, introduced by an earlier fix in this same release.

---

## Group A - the lint is not optional

### TRC-1 - a malformed spine fails the sweep whatever its status

```gherkin
Scenario: an issue that has not started carries an unparseable spine
  Given an issue whose status is queued, parked or abandoned
  And whose task.yml declares a schema version this CLI does not handle
  When the cross-issue sweep runs
  Then it fails
```

*Serves INT-1. Test: `tests/test_ci_lints_every_issue.py::test_trc_1_a_malformed_spine_fails_the_sweep_at_any_status`.*

Tested across all three not-in-flight states, because `status: parked` was a one-word way to leave the sweep entirely.

### TRC-2 - a well-formed not-yet-started issue still does not fail

```gherkin
Scenario: an issue is triaged but not yet defined
  Given an issue whose status is queued and whose spine is well formed
  When the cross-issue sweep runs
  Then it does not fail
```

*Serves INT-1. Test: `tests/test_ci_lints_every_issue.py::test_trc_2_a_well_formed_queued_issue_still_passes`.*

The control. Without it, TRC-1 would pass against a sweep that simply failed everything, undoing the fix this one is correcting.

---

## Group B - the summary tells the truth

### TRC-3 - the summary does not claim lint coverage it did not perform

```gherkin
Scenario: the sweep skips the gate checks for work that has not started
  Given at least one issue the sweep did not fully check
  When the run finishes
  Then the summary says how many issues were checked and how many were skipped
  And it does not assert that every issue checks green
```

*Serves INT-2. Test: `tests/test_ci_lints_every_issue.py::test_trc_3_the_summary_reports_what_was_and_was_not_checked`.*

The line a CI reader actually reads is the last one. A blanket claim there is worse than a skip line further up, because the skip line is the part nobody scrolls back for.

---

## Coverage ledger

| Traceability id | Serves intent | Has a failing test (implement) | Passes as acceptance (verify) |
|---|---|---|---|
| TRC-1 | INT-1 | [x] | [ ] |
| TRC-2 | INT-1 | [x] | [ ] |
| TRC-3 | INT-2 | [x] | [ ] |
