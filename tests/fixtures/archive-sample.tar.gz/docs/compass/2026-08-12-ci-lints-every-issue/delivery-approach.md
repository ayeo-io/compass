# Delivery approach - ci-lints-every-issue

> **Issue:** `compass ci` skips schema linting for any issue that has not started, then prints "every issue lints clean and checks green" - a claim it did not check.
> **Triaged:** 2026-08-12 · **Revision:** 1
> **Reference shape:** feature
> **Status:** active. Found by the PR #43 review; blocks PR #43.

---

## The defect

The `continue` added by `sweep-respects-queued` sits above both `cmd_task_lint`
and `cmd_check`. Skipping the gate checks for a queued issue is right - it has
no acceptance criteria yet, correctly. Skipping the **lint** is not: the lint
validates the spine's own structure, which is checkable whatever stage the
issue is at.

Reproduced against a spine carrying `schema_version: "9.9"` and
`risk: nonsense-value`:

```
[issue] queued-issue
  skipped - status is 'queued', so the acceptance criteria and evidence a
  check looks for do not exist yet.
compass ci: PASS - governance valid; every issue lints clean and checks green.
```

The same spine, linted directly, is rejected outright:

```
compass: .../task.yml: schema_version is '9.9', but this CLI handles '2.0' ...
```

Two things are wrong, and the second is worse. An unparseable spine can sit in
a repository indefinitely without CI noticing. And the summary line - the one
line a CI reader actually reads - asserts something the sweep did not do.

**It is also a one-word bypass.** Setting `status: parked` removes an issue
from the sweep entirely, and the summary still says everything is clean.

## The class

This is the release's own theme: a check reporting success while checking
nothing. It was introduced by the fix for another member of that class, which
is exactly the pattern the next cycle is being framed around.

## The fix

Lint every issue regardless of status; gate only `cmd_check` on the lifecycle.
And make the summary carry counts rather than a blanket claim, so a reader can
see what was checked and what was not.

---

## 1. The assessment

| Dimension | Value | One-line justification |
|---|---|---|
| **Risk** | cross-cutting | This is the cross-issue gate an adopter's build runs; a false PASS here is a false PASS for everything under it. |
| **Familiarity** | brownfield-mapped | The defect is reproduced and the code is eleven lines added by this release. |
| **Size** | small | Move one branch, reword one summary, and cover the case the existing test does not. |
| **Goal & role** | engineer, delivery | The sweep's summary says what the sweep did. |

**Labels:** [ci]

---

## 2. The composed candidate

Candidate: **feature**, solo. RG-FLOOR-006 adds the fitness gate on cross-cutting risk.

---

## 3. Policy rules that fired

RG-FLOOR-006 (cross-cutting risk) added `verify.fitness`: "Architectural fitness checked before cross-cutting or critical changes land."

---

## 4. The final delivery approach

Stages: triage full, define full, requirements review light, design full, breakdown skipped (solo), implement full, test and review full, ship full. Seven gates. Topology solo.

---

## 5. The de-scope ledger

| Stage / check | Action | Safe to skip / collapse because... |
|---|---|---|
| Break down the work | skipped | One function and its test. |

---

## 6. Owed follow-ups

- [ ] none owed

---

## 7. Human overrides

No human overrides.

---

## 8. Confirmation

- [x] Approach presented to the invoker and confirmed.
- [x] Every dimension in §1 has a justification.
- [x] Every skipped stage in §5 has a "safe to skip because..." line.
- [x] Not a spike - no `.spike` marker.
- [x] `devlog.md` opened with the triage entry.

Next stage: define acceptance criteria.
