# Verification report - ci-lints-every-issue

> **Issue:** The sweep skipped schema linting for not-yet-started issues and claimed every issue lints clean.
> **Approach:** feature - seven gates. **Verified:** 2026-08-12

---

## 1. What changed, and what it now says

The lint runs for every issue at every stage; only the gate checks are skipped for work that has not started. The summary carries counts instead of a blanket claim.

On this repository:

```
before: compass ci: PASS - governance valid; every issue lints clean and checks green.
after:  compass ci: PASS - governance valid; every spine lints clean;
                     70 issue(s) fully checked, 9 lint-only (not in flight).
```

The first sentence was untrue whenever anything was skipped, and this repository skips nine.

## 2. Three scenarios, and why the middle one exists

TRC-1 proves a malformed spine now fails at every not-in-flight status - tested across queued, parked and abandoned, because `status: parked` had become a one-word way to leave the sweep. TRC-3 proves the summary reports counts.

TRC-2 is the control, and it is doing real work here: without it, TRC-1 would pass against a sweep that simply failed everything, which would undo `sweep-respects-queued` and put back the defect where framing work early turns the build red. The fix had to hold both properties at once.

## 3. A note on the TRC-3 assertion

The first version asserted the word "skipped" appeared in the summary. The implementation chose clearer wording - "lint-only (not in flight)" - and the test failed on the phrasing rather than on the property. The assertion now looks for the counts the scenario actually asks for. Recorded because adjusting a test to match an implementation deserves saying out loud: the scenario was not changed, only the proxy the test used for it.

## 4. Gates

| Gate | Status | Evidence |
|---|---|---|
| verify.correctness | pass | `EV-T-TRC-1` (genuine red across all three statuses), `EV-T` (whole suite) |
| verify.regression | pass | `EV-T` |
| verify.governance / traceability / security / fitness | pass | `EV-VC` - `compass check`, 15 of 15 |
| verify.clarity | pass | this report |

## 5. Definition of Done

- [x] Three scenarios pass as acceptance checks, with a recorded red.
- [x] Full suite green, run on record.
- [x] `compass check` passes; the real sweep passes and now reports what it did.
- [x] Traceability holds - two changed files, each traced.
- [x] No owed follow-up.
- [x] Living docs match reality - the skip line now says the spine was still linted.
- [x] Nothing new became blocking.
