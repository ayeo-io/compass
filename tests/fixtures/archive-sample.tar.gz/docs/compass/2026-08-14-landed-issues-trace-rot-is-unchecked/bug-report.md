# A rename breaks landed issues' traceability chains and nothing reports it

Found 2026-08-14 while re-deriving the living spec during `plain-language-3-2-0`.

## Observed

`identifiers-and-vocabulary-in-printed-output` (landed 2026-08-13) declared:

```
tests/test_check_summary_counts.py::test_trc_d1_vacuous_counted_apart
```

That test no longer exists. A later sweep renamed it to
`test_trc_d1_empty_counted_apart`. The spine was not updated, so the scenario
pointed at nothing.

`compass check` on that issue reports **PASS**, with:

```
PASS declared-tests-resolve: issue is landed - declared test ids are a historical record
```

## The tension, stated fairly

The exemption is defensible and probably right as a default. A landed record
says what the test was called when the work landed, and failing a build because
someone later renamed a test would make every landed issue a liability.

But `G3` is traceability, and traceability is a chain you can walk. After a
rename the chain is broken in exactly the direction that matters - from the
record forward to the code - and **nothing anywhere reports it**. The issue
reports PASS. The living spec derived from that spine still renders the
scenario. A reader following the reference lands nowhere.

## Why it is invisible

The two states are indistinguishable from outside:

- a landed issue whose test ids still resolve, and
- a landed issue whose test ids resolve to nothing

both report `PASS ... declared test ids are a historical record`. The check does
not look, so it cannot say which it is.

## Scope

Not "make it fail". A landed issue failing on a later rename is the wrong cure.
What is missing is **reporting**: something that walks landed spines, resolves
their declared test ids, and says how many no longer resolve. Advisory, like the
plain-language count - a number that can move, with a baseline.

Then the question of what to do about a broken chain is a decision someone makes
with the number in front of them, rather than one nobody knows they have.

## Related

- `path-prefix-exemptions-hide-their-contents` - same family: the fix is
  enumeration, not strictness.
- The instance above was caused by a sweep that renamed a test, a prose heading
  and a spine title inconsistently - two of the three were missed. That is what
  strategy `S14` (correct every place at once) now forbids, found in the sweep
  that motivated writing it.
