# The evaluator still prints the code before its meaning

Found 2026-08-16, while checking whether a caveat in the launch article was
still needed. It was.

## Observed

`compass approach evaluate` prints:

```
    [RP-FLOOR-002] floor: You cannot safely change behaviour you have not first written down.
        - stage 'define' forced full-weight
```

Code first, meaning second. That is the defect `plain-language-3-2-0` was built
to remove, on a screen that release did not touch.

## Why it was missed

That release fixed the same construction in `compass issue receipt` - its policy
lines now read `Architectural fitness checked before ... (RP-REQUIRE-003)` - and
stopped there. Both screens print the same fired-rule data through different
renderers, and only one was corrected.

`S14` says a correction applies to every place the thing appears, and this is
that rule broken by the release that wrote it. It also happened at the very edge
of the work, after verify, which is where a partial correction is most likely.

## Why this screen matters more than the receipt

- It is the **first** Compass output a new user sees, immediately after triage.
- It is the screen the demo recording holds longest - the second shot is built
  entirely on it, and on one sentence in it: *"A one-line auth change is not
  small."*
- It is quoted in the launch article, which currently carries a sentence saying
  the codes have been relabelled for reading. That caveat is honest, and it
  would be unnecessary if the output already read this way.

## Scope

Apply the same change the receipt got: state what the rule did, then the code in
brackets. Roughly:

```
    You cannot safely change behaviour you have not first written down (RP-FLOOR-002)
        - stage 'define' forced full-weight
```

Also worth deciding in the same pass: `floor`, `requirement` and `role_rule`
appear as bare labels and mean nothing to a first-time reader.

**This changes the demo's second shot.** The re-capture list in the demo script
already flags that shot for other reasons; add this to it rather than
discovering it during recording.

Prove it can fail before counting it done, and check the printed-output guard
covers this command - it is one of the two it already reaches.
