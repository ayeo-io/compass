# Spec - adaptive-artifact-composition

> **Phase:** define · **Last updated:** 2026-08-24 · **Owning agent:** spec-author
> **Familiarity:** existing templates read as models; the new content borrowed
> from published sources rather than invented

## Summary

**Goal:** An issue that earns a threat model or a rollback plan has something
to start from, and what it starts from produces work rather than prose.

**Approach:** Two templates, both borrowed rather than invented. `threat-model`
takes the Threat Modeling Manifesto's four questions verbatim, and its third
question lands as scenarios in `acceptance-criteria.md` - so a threat with no
scenario is visibly unfinished rather than quietly admired. `rollback-plan` is
a rehearsal record, not a plan: SWEBOK requires the rollback be *rehearsed*
before a deploy, and Dave Farley's answer to rollback is a mechanism rather
than a document, so what the file records is when the mechanism was last
proved. The `rollback-plan` evidence type's description is amended to demand
that. `design.md` gains a sixth optional section for cross-cutting concerns,
which is where *Design Docs at Google* puts security and observability.

**Why now / what changes:** `governance/routing-policy.yml` already promises
both documents - `RP-REQUIRE-005` on auth, payments or personal data, and
`RP-REQUIRE-006` on migrations - and neither has a template. An issue touching
auth is told it earns a threat model and given nothing to start from. After
this, it gets four questions that produce scenarios. What a reader will notice
is that a threat model here ends in the acceptance criteria rather than in a
folder nobody reopens.

---

## How each role reads this file

- **Product owner / manager** - reads for *intent fidelity*: do these scenarios deliver the outcome in `prd.md`?
- **Product marketer** - reads for *claims*: every line of launch copy must point at a scenario id here.
- **Engineer** - reads for *tests*: scenarios are the acceptance suite and seed the TDD red→green cycle.
- **QA** - reads for *coverage*: which scenarios are exercised, which edges are not.
- **Designer** - UI behaviour authored in `ui-contract.md` flows in here as scenarios.

---

## Intent links

| Intent id | Source | Statement |
|---|---|---|
| INT-1 | `RP-REQUIRE-005` and `RP-REQUIRE-006` in the shipped policy | A document the routing policy names has something to start from. |
| INT-2 | Threat Modeling Manifesto, and its anti-pattern "Admiration for the Problem" | A threat model produces work, not a list of threats. |
| INT-3 | SWEBOK v4 §6.3.3, and Dave Farley on continuous delivery | A rollback is rehearsed, and the record says when. |
| INT-4 | *Design Docs at Google*; Robert C. Martin's First Law of Documentation | Cross-cutting concerns are a section of the design, and no document exists whose need is not immediate and significant. |

---

## Where each borrowed shape comes from

Quoted so a reviewer can check the borrowing rather than my taste.

| Shape | Source | What was taken |
|---|---|---|
| The four questions | threatmodelingmanifesto.org | "What are we working on? / What can go wrong? / What are we going to do about it? / Did we do a good enough job?" - verbatim |
| Threats become scenarios | ThoughtWorks Technology Radar, threat modelling, **Adopt** since Nov 2015 | Its named output form is "evil user stories" |
| Rehearsed, not planned | SWEBOK v4 §6.3.3 | "a planned and **rehearsed** rollback is done before a new version of the software is deployed in production" |
| Cross-cutting concerns | *Design Docs at Google* | Its fifth section; names security, privacy and observability |
| Keep it short | MADR short form; Martin's First Law | Four headings; "produce no document unless its need is immediate and significant" |

---

## Scenario group A - the threat model produces work

**Independence note:** Separable. Touches `templates/threat-model.md` and the
guard that reads it; shares nothing with group B or C.

### Scenario: the template asks the four questions and no others
<!-- traceability id: TRC-A1 · serves: INT-2 -->

Verbatim matters here. A paraphrase is a fork of a standard with none of its
authority, and the whole reason to borrow is that fifteen practitioners already
argued this out.

```gherkin
Scenario: the template asks the four questions and no others
  Given the threat model template
  When its headings are read
  Then they are the Manifesto's four questions, word for word
  And no fifth question has been added
```

### Scenario: a threat with no scenario is visibly unfinished
<!-- traceability id: TRC-A2 · serves: INT-2 -->

The Manifesto's anti-pattern is "Admiration for the Problem" - a document that
lists threats and mitigates none. The template answers it structurally: the
third question's answer is a scenario id, so a threat with no id is an empty
cell rather than a matter of judgement.

**Resolved at the requirements review:** this is a CHECK on a filled-in
document, not a template that merely asks - asking is what every unfilled form
does. It shares one check with TRC-B3 rather than adding a second.

```gherkin
Scenario: a threat with no scenario is visibly unfinished
  Given an issue whose threat model lists a threat
  When the issue is checked
  And that threat names neither a scenario id nor an explicit "risk accepted"
  Then the check reports it, naming the threat
  And a threat that names a scenario id is not reported
  And a threat that says "risk accepted" with a reason is not reported
```

### Scenario: the fourth question is answered by evidence, not by assertion
<!-- traceability id: TRC-A3 · serves: INT-2 -->

"Did we do a good enough job?" is already a Compass gate. The template points at
it rather than asking the author to grade their own work.

```gherkin
Scenario: the fourth question is answered by evidence, not by assertion
  Given the threat model template's fourth section
  When it is read for what to write there
  Then it asks for the scenarios that now cover the threats, and their evidence
  And it does not ask the author to state that the job was good enough
```

---

## Scenario group B - the rollback plan records a rehearsal

**Independence note:** Separable. Touches `templates/rollback-plan.md` and one
description in `guardrails.yml`.

### Scenario: the template records when the rollback was last rehearsed
<!-- traceability id: TRC-B1 · serves: INT-3 -->

```gherkin
Scenario: the template records when the rollback was last rehearsed
  Given the rollback plan template
  When it is read for what it asks the author to record
  Then it asks when the rollback was last rehearsed, and against what
  And it asks what the rehearsal actually did, not that one was planned
```

### Scenario: the evidence type stops accepting a plan as a rollback
<!-- traceability id: TRC-B2 · serves: INT-3 -->

`guardrails.yml` describes the `rollback-plan` evidence type as "a recorded
plan for reverting a change safely if it goes wrong" - which is exactly the
assertion this issue's sources say is not enough.

```gherkin
Scenario: the evidence type stops accepting a plan as a rollback
  Given the `rollback-plan` entry in the evidence type catalogue
  When its description is read
  Then it says the record must show the rollback was rehearsed
  And the evidence type list itself is unchanged - no type is added or removed
```

### Scenario: a rollback plan with no rehearsal date is caught
<!-- traceability id: TRC-B3 · serves: INT-3 -->

The template can ask; nothing yet makes an unanswered ask fail. This is the one
scenario in the issue that adds a check rather than prose, and it is written so
the check can be shown to fail.

**Resolved at the requirements review:** detected by reading the document,
whose shape the template owns. There is precedent - `dod-evidence-typed`
already reads inline `(evidence: EV-id)` tags out of `verification-report.md`.
The same check serves TRC-A2.

```gherkin
Scenario: a rollback plan with no rehearsal date is caught
  Given an issue whose rollback plan states no rehearsal
  When the issue is checked
  Then the omission is reported, naming the file and what is missing
  And a rollback plan that records a rehearsal is not reported
  And an issue with neither document reports nothing to check, not a pass
```

---

## Scenario group C - cross-cutting concerns are a design section

**Independence note:** Separable. Touches `templates/design.md` and the
`plan-authoring` skill.

### Scenario: the design template offers a cross-cutting concerns section
<!-- traceability id: TRC-C1 · serves: INT-4 -->

```gherkin
Scenario: the design template offers a cross-cutting concerns section
  Given the design template
  When its optional sections are read
  Then one covers cross-cutting concerns - security, privacy, observability
  And it carries its own rule for when it earns a place, like the others
  And it says to delete it when unused
```

### Scenario: the skill that governs the optional sections knows about it
<!-- traceability id: TRC-C2 · serves: INT-4 -->

The template and the skill disagreeing is how an optional section becomes
decoration. `plan-authoring` names five sections today and would name five
while the template offered six.

```gherkin
Scenario: the skill that governs the optional sections knows about it
  Given the plan-authoring skill and the design template
  When the optional sections each names are compared
  Then the set read from each is not empty
  And it holds the six sections the template offers
  And the two sets are the same
  And neither claims a count the other contradicts
```

---

## Scenario group D - the promise the policy already makes

**Independence note:** Not separable - this is the check on the other three.

### Scenario: every document kind the policy names has a template
<!-- traceability id: TRC-D1 · serves: INT-1 -->

This is the defect that opened the issue, stated as a criterion so it cannot
return. The policy gained `threat-model` and `rollback-plan` before either
existed; a rule naming a kind nothing can produce is a promise the framework
cannot keep.

**Resolved at the requirements review, after writing the scan wrong.** The
first version read a hard-coded path that does not exist in the policy and
reported zero missing templates while two were missing. A scan that finds
nothing must fail, not pass.

```gherkin
Scenario: every document kind the policy names has a template
  Given the routing policy read in full, wherever an artifact kind appears
  When the kinds found are looked for in the templates directory
  Then the scan has found at least every kind the shapes themselves declare
  And a scan that finds no kinds at all fails rather than passing
  And each kind found has a template
  And a kind with no template fails, naming the kind and where it was named
```

### Scenario: no document was added that nothing asks for
<!-- traceability id: TRC-D2 · serves: INT-4 -->
<!-- verifiable: narrative -->

Martin's First Law read as an acceptance criterion, and the reason it is
narrative: no test can observe whether a document's need was immediate and
significant. What can be recorded is the decision, and this issue dropped three
of the five it started with - `test-strategy`, `test-plan` and `release-plan` -
because no rule triggers them and no concise published form exists to borrow.

```gherkin
Scenario: no document was added that nothing asks for
  Given the templates this issue adds
  When each is checked against the routing policy
  Then a rule or a shape names every one of them
  And the documents dropped are recorded with the reason they were dropped
```


### Scenario: both templates stay shorter than the framework's own PRD
<!-- traceability id: TRC-D3 · serves: INT-4 -->

**Added at the requirements review, and it is the gap that would have
embarrassed the issue.** Every source this spec cites argues for concision -
MADR's four-heading short form, Martin's First Law, *Design Docs at Google* on
1-3 page mini docs, the one-page test plan's "brevity forces prioritisation" -
and nothing held either new template to any length.

The cap is measured rather than felt. `templates/prd.md` is 106 lines and
`templates/design.md`, the largest and the one carrying six optional sections,
is 223. **120 lines**, comments included: above the PRD, far below the design,
so it permits a worked example and refuses a form.

```gherkin
Scenario: both templates stay shorter than the framework's own PRD
  Given the threat model and rollback plan templates
  When each is measured
  Then neither exceeds 120 lines
  And the guard names the file and its line count when one does
```
