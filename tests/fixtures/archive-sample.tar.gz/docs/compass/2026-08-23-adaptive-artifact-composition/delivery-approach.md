# Delivery approach - adaptive-artifact-composition

> **Issue:** Write the document kinds the routing policy already names and the
> framework cannot produce.
> **Triaged:** 2026-08-23 · **Re-assessed:** 2026-08-24 by jed72
> **Revision:** 3 (three documents became one template plus a mechanism)
> **Reference shape:** feature

---

## 1. Revision 2 - what changed, and the measurement behind it

**Recorded as a re-assessment, not a quiet edit:** `compass approach evaluate
--write --reason ...` recomputed the approach from **initiative** to
**feature** and logged the change in the spine's `reassessments:` list. That
log is what `compass retro` reads to tell whether triage is systematically
over-sizing, and a re-assessment with no recorded reason is a signal thrown
away.

**What moved out.** Items 5, 7 and 8 of the source proposal - splitting
`design.md`, renaming Brief by depth, and making `work-plan.md` the human plan
- are all renames of artifact kinds the routing policy now names. Measured on
2026-08-24 rather than estimated:

| Filename | Files referencing it | Occurrences | Documents in the archive |
|---|---|---|---|
| `design.md` | 64 | 168 | 34 |
| `prd.md` | 52 | 111 | 7 |
| `distribution-map.md` | 27 | 54 | 11 |
| **total** | **100+** | **333** | **52** |

They are now `artifact-filenames-rename-slice`. `CLAUDE.md` already says the
artifact filenames "rename in their own slice"; this is that slice, and it was
never this issue's.

**What remains is item 6, and it closes a promise the framework already
makes.** `governance/routing-policy.yml` has two rules that add documents:

```yaml
RP-REQUIRE-005  labels_any: [auth, payments, personal-data]  ->  threat-model
RP-REQUIRE-006  labels_any: [migrations]                     ->  rollback-plan
```

**Neither kind has a template.** So an issue touching auth is told it earns a
threat model, its review page lists one as "not written yet", and there is
nothing to start from. The routing half shipped ahead of the writing half -
which is the same error `the-human-front-door` corrected in its own revision 3,
appearing one layer down.

---

## 1a. Revision 3 - what the research changed

**The scope was set by asking what the field already does, before writing
anything.** Six sources, and they converge:

| Source | What it says |
|---|---|
| Robert C. Martin | "Produce no document unless its need is immediate and significant." Tests are the living documentation. |
| ThoughtWorks Technology Radar | Threat modelling: **Adopt since Nov 2015**. Its practical output form is **"evil user stories"**. Repeat periodically; avoid the "security sandwich". |
| Threat Modeling Manifesto | Four questions. "Doing threat modeling over talking about it." Anti-pattern: **"Admiration for the Problem"** - listing threats and mitigating none. |
| Dave Farley, *Continuous Delivery* | Rollback is a **mechanism** - blue/green, canary, versioned migration scripts - not a document. Acceptance tests are executable specifications. |
| *Design Docs at Google* | Security, privacy and observability are **cross-cutting sections** of the design, not separate documents. 1-3 pages for incremental work. |
| SWEBOK v4 §6.3.3 | "a planned and **rehearsed** rollback is done before a new version of the software is deployed in production." |

Nobody modern is asking for more documents. They are asking for fewer that
**produce something executable**. So each of the three planned documents was
re-read as "what does this actually need to produce?":

**A threat model produces scenarios.** Radar's "evil user stories" are Compass
scenarios. The Manifesto's third question - what are we going to do about it -
lands in `acceptance-criteria.md`, where G1 already forces a test and G3 a
trace. Its fourth question, "did we do a good enough job?", is the evidence
gate. This also defeats "Admiration for the Problem" structurally: a threat
with no scenario is visibly unfinished.

**A rollback plan produces a rehearsal record.** Farley says have the
mechanism; SWEBOK says rehearse it before deploying. So the artifact is typed
evidence, not a document. A plan nobody rehearsed is exactly the assertion G4
exists to reject.

**A test strategy is mostly already in `task.yml`** - the scenarios, their
tests and the green records are the strategy. The one-page fields not already
captured are environments, tools, out-of-scope and risks: four lines, which is
a design section.

### What this issue now delivers

| | |
|---|---|
| `templates/threat-model.md` | Four questions, verbatim from the Manifesto. Its output is scenarios. |
| `templates/rollback-plan.md` | A **rehearsal record**, not a plan: what breaks, how we go back, and when that was last proved. |
| `rollback-plan` evidence type, description amended | It reads "a recorded plan for reverting a change safely" - which is precisely the assertion Farley and SWEBOK say is not enough. It must demand the rehearsal. |
| A cross-cutting-concerns section | Added to `design.md`'s optional five, governed by `plan-authoring`. |

**A correction to this revision as first drafted.** It proposed a new
`rollback-rehearsed` evidence type. That is more mechanism than the job needs
and the freeze test is right to resist it: `guardrails.yml` already has a
`rollback-plan` evidence type, and `tests/test_stream_c_no_new_checks_or_gates.py`
freezes `evidence_types` and gate names against main. A ninth near-synonym
beside an existing type is vocabulary sprawl. **Amending what the existing type
demands is the same change with none of the mechanism**, and its description is
free text the freeze does not cover.

`RP-REQUIRE-005` and `RP-REQUIRE-006` therefore stay exactly as they are. They
already name the right kinds; what was missing was the templates.

**So the research changed the CONTENT of two documents and the existence of
three.** It did not reduce the file count for the two that survive, and saying
otherwise would overstate what it did.

**Dropped: `test-plan` and `release-plan`.** Neither has a concise form worth
borrowing, and writing one would be inventing a form - which Martin's First Law
answers directly.

### The objection, recorded rather than left implicit

An earlier draft of this record worried that moving work out of documents costs
the review page its signal - a reviewer can see "threat-model: not written yet"
but cannot see a missing design section. **That worry was wrong**, and it is
written down because it nearly changed the design. The review page already
renders a scenario list and an evidence list. Threat work appears as scenarios;
rollback appears as a rehearsal record. The signal moves to parts of the page
that already exist, rather than being lost.

### The approach did not change

`compass approach evaluate --write --reason ...` was re-run and reported "no
route change detected - the --reason was NOT recorded". Correct: the work got
smaller, but contained risk and standard size still read the same way. A
template that has to be worth opening, a new evidence type with a schema
change, a policy rule, and a design section is a feature's worth of work, not a
quick fix.

---

## 2. The assessment

| Dimension | Value | Justification |
|---|---|---|
| **Risk** | contained | Five new template files, and policy rules naming three of them. Purely additive: no existing template changes, no code path changes, nothing on disk is rewritten. The worst failure is a document nobody finds useful, which is visible immediately and reverts by deletion. Was `cross-cutting` when this issue also carried a 333-occurrence rename. |
| **Familiarity** | brownfield-mapped | Fourteen templates exist as working models, and the two the policy already names have their purpose stated in the rule that adds them. |
| **Size** | standard | Five documents, each of which has to be worth opening. Not `small`: a template nobody can fill in is worse than no template, so each one needs real content and a worked shape, not headings. |
| **Goal & role** | delivery · engineer | |

**Labels:** `docs`. Dropped `cli` and `public-api`, which belonged to the
rename half - this issue adds no verb, changes no flag, and touches no CLI
surface.

**Urgency:** none.

---

## 3. Policy rules that fired

- Policy file: `governance/routing-policy.yml`, version 2.3.0.

| Kind | Triggered by | Effect | Rationale, quoted |
|---|---|---|---|
| shape | standard + contained | **feature** | "The default working shape" (`RP-SHAPE-005`) |

No floor, no requirement, no cap. The previous assessment pulled in
`RP-REQUIRE-003` (`verify.fitness` on cross-cutting risk); with the rename half
gone, cross-cutting is no longer the honest reading and that gate goes with it.

---

## 4. The delivery approach

**feature.** Six gates: correctness, governance, traceability, regression,
clarity, security.

### 4a. Per-stage weight

| Stage | Weight | Why |
|---|---|---|
| Define acceptance criteria | full | The whole deliverable is prose. If "what makes this template worth opening" is not stated as checkable criteria, the review is taste. |
| Requirements review | **light** | Collapsed to a light pass by the approach. Honoured: 4c names one question, and one question does not need a full ambiguity ledger. |
| Design | full | 4c. What a template must contain to be fillable is a real decision, and getting it wrong is discovered by every future issue rather than by this one. |
| Break down the work | solo-or-pair | Five documents, genuinely independent of each other. |
| Implement | full | |
| Test and review | full - 6 gates | 4b. |
| Ship | full | |

### 4b. Gate set

Six. `verify.claims` and `verify.fitness` are **not** in this set, which is
what dropping to a feature means. Recorded so the verification report does not
list gates the approach never had.

`verify.security` is in the set and one of the five documents is a threat
model. That is a coincidence of naming: the gate assesses this change's own
security surface, which is five markdown files, and it will say so.

### 4c. The question this issue has to answer

**What makes a template fillable rather than a form?** This project has
fourteen, and the good ones share a shape: they say what the section is for
before asking for it, they carry a worked example rather than a placeholder,
and they state what a reader should conclude if a section is empty. The bad
outcome here is five documents that look complete and teach nobody what to
write - and this issue's own review page will be the first place that shows.

The requirements review argues this once, and it applies to all five.

### 4d. Topology

Policy permits up to 2 streams. The five documents share no content. This
repository runs solo by standing decision, so the map records the parallelism
as available and unused.

---

## 5. The de-scope ledger

| Stage | Weight | Safe to collapse because |
|---|---|---|
| Requirements review | light | One question is named at 4c and it is the same question for all five documents. A full ambiguity ledger would be one entry. If the define stage surfaces a second question, this is wrong and the approach gets re-assessed rather than stretched. |

Nothing is skipped.

---

## 6. Owed follow-ups

None owed by the approach.

**`artifact-filenames-rename-slice` does not depend on this one**, and this one
does not depend on it. They touch disjoint files: this adds new templates, that
renames existing ones.

---

## 7. Recorded decisions

| What was decided | Choice | Who | Why |
|---|---|---|---|
| The rename half | Split into its own issue | jed72 | 333 occurrences across 100+ files and 52 documents on disk, measured. Folding them together would hold five shippable templates behind a rename slice. |
| Risk | contained, was cross-cutting | jed72 | With the rename gone, this is five new files that nothing reads yet. |
| Size | standard, was large | jed72 | Five documents that each have to be worth opening. |

No override of a computed value.

---

## 8. Confirmation

- [x] Every dimension carries a justification.
- [x] Every collapsed stage has a written reason.
- [x] Approach presented to the invoker and confirmed, 2026-08-24.
- [x] Revision 3's reframe presented and confirmed, 2026-08-24.
