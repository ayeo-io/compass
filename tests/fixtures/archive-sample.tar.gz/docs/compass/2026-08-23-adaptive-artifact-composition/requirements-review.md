# Requirements review - adaptive-artifact-composition

> **Phase:** refine · **Weight:** light, as the approach set · **Reviewed:** 2026-08-24
> **Reviewer:** jed72 (author) · **Spec:** 10 scenarios in four groups.

The define stage ran its own four scans - placeholders, orphan intents,
untestable Thens, ambiguous quantifiers - and nothing was outstanding. What
follows is what the author could not settle alone: one gap, four decisions.

---

## The ambiguity ledger

### AMB-1 - TRC-D1's guard can find nothing and pass

**Found by writing it wrong first**, which is the only reason it is here.

The first scan for "every kind the policy names" read a hard-coded path -
`rules.floors_and_requirements` - and reported **zero missing templates**. The
policy has no top-level `rules` key at all; the artifact-adding rules live
under `routing_guardrails.floors`. A scan that finds nothing reports a clean
result, and this one would have shipped saying the promise was kept while
`threat-model` and `rollback-plan` were still missing.

A recursive walk over the whole document finds **nine** kinds and both gaps:

```
acceptance-criteria, design, distribution-map, launch-readiness, prd,
requirements-review, rollback-plan, threat-model, verification-report
                                   ^^^^^^^^^^^^^^^^^^^^^^ no template
```

**Resolved:** the guard walks the policy recursively for `add_artifact` and
`require_artifact` wherever they appear, plus every shape's `artifacts` map,
and **asserts it found at least the shapes' own kinds before judging any of
them**. A scan that returns an empty set fails rather than passes. TRC-D1 is
updated to say so.

**Decided by:** jed72. **Changes what gets built:** yes - it is the
difference between a guard and a guard-shaped thing.

---

### AMB-2 - How is "states no rehearsal" detected?

**What was unclear.** TRC-B3 says a rollback plan stating no rehearsal is
reported. Nothing says how that is known.

**Two candidates.** Parse the document for the rehearsal line, or require a
typed `rollback-plan` evidence record carrying a structured field.

**Resolved: parse the document, and the template owns the shape being parsed.**
There is precedent - `dod-evidence-typed` already reads inline `(evidence:
EV-id)` tags out of `verification-report.md`, so the framework reading
structure out of its own templates is established rather than novel. The
evidence route was rejected because it splits one thing into two: the document
a reviewer opens and a separate record asserting something about it, with
nothing keeping them honest with each other.

**Decided by:** jed72. **Changes what gets built:** it settles the
mechanism, not the scope.

---

### AMB-3 - Is TRC-A2 about the template's shape or about a filled-in document?

**What was unclear, and it matters.** "A threat with no scenario is visibly
unfinished" can mean the template *asks* for a scenario id per threat, or that
something *checks* a filled-in threat model for empty answers. The first is
prose; the second is a guard. The scenario reads like the second and the spine
lists it as mechanical.

**Resolved: the second, and it shares one check with TRC-B3.** A threat model
that lists threats and mitigates none is the Manifesto's named anti-pattern, so
a template that merely asks is not enough - asking is what every unfilled form
does.

But **two checks would be more mechanism than the job needs**. One check,
registered under G4, reads whichever of the two documents exist and reports
what is unanswered: a threat row with no scenario id and no explicit "risk
accepted", or a rollback plan with no rehearsal. Two documents, one guard.

Adding a check name means declaring it in `test_stream_c_no_new_checks_or_gates.py`'s
baseline with the change that introduces it - the path ADR-002 sets, and the
one `dashboard-current` already took.

**Decided by:** jed72. **Changes what gets built:** yes, and it makes
the issue smaller than two checks would have.

---

### AMB-4 - TRC-C2 compares two lists and could pass on an empty one

**What was unclear.** "The optional sections each names are the same set" is
true of two empty sets.

**Resolved:** the scenario asserts the set is non-empty and has the expected
size before comparing, the way the report-list guard in the last issue does.
Stated in the criteria rather than left to the test author.

**Decided by:** jed72. **Changes what gets built:** no - it hardens a
scenario that was already there.

---

### AMB-5 - The gap: nothing holds the templates to being short

**This is a gap, not an ambiguity, and it is the one that would have embarrassed
the issue.** Every source this spec cites argues for concision - MADR's
four-heading short form, Martin's First Law, *Design Docs at Google* on 1-3
page mini docs, the one-page test plan's "brevity forces prioritisation". The
research thread that produced this scope was **entirely about not writing long
documents**. And no criterion holds either new template to any length.

**Resolved:** a scenario is added. `threat-model.md` and `rollback-plan.md` are
each capped, and the cap is stated as a number rather than as "short". The
existing templates give the yardstick: `prd.md` is 106 lines and
`design.md` - the largest, and the one that carries six optional sections - is
223. A borrowed four-heading document that runs longer than the framework's
own PRD template has not borrowed its concision.

**Cap: 120 lines each, including the instructional comments.** Chosen because
it is above `prd.md` and far below `design.md`, so it permits a worked example
and refuses a form.

**Decided by:** jed72. **Changes what gets built:** yes - one scenario,
**TRC-D3**, and it constrains both templates.

---

## Governance QA

| Guardrail | Held? | How |
|---|---|---|
| G1 - tested before it lands | yes | Nine mechanical scenarios have tests; TRC-D2 is `verifiable: narrative` and carries a real When/Then, which is what clears it. |
| G2 - acceptance before code | yes | Written before any template exists. |
| G3 - traceability | yes | Every scenario traces to one of four intents, and each intent names its published source. |
| G4 - evidence, not assertion | yes, and it is the subject | The rollback plan's whole point is that a rehearsal is evidence and a plan is an assertion. The new check registers under G4. |
| G5 - human signs off on the irreversible | not applicable | Two markdown templates and one check. |

**Strategies.** S10 - a guard is accepted on a failure: AMB-1 is a worked
instance, found by writing the guard wrong and watching it pass. S11 - measure
before arguing: AMB-5's cap comes from counting the existing templates rather
than from taste. **No departure recorded.**

**ADR-002** governs the new check: it registers under an existing guardrail and
is declared in the freeze baseline. **The evidence type list does not change** -
`rollback-plan` already exists and only its description is amended, which the
freeze test does not cover.

---

## Does the delivery approach still fit?

**The prediction was wrong and the approach is right, and those are separate
statements.**

`delivery-approach.md` §4c predicted this review would find **one** question. It
found five, and I wrote the trigger myself: "if the define stage surfaces a
second question, this is wrong and the approach gets re-assessed rather than
stretched."

Reading my own trigger honestly: it was about the review needing more weight
than a light pass. It does not. All five were resolvable in this pass by the
author, none needed a decision that had to go elsewhere, and the work got
**smaller** - one shared check instead of two. Re-assessing to a heavier
approach because the review did its job would be process for its own sake.

**No re-assessment.** The mis-prediction is recorded here because a triage that
guesses one question and meets five is exactly the signal `compass retro`
exists to aggregate, and burying it would waste it.

---

## Scenarios added or changed by this review

| Id | Change |
|---|---|
| TRC-D1 | Now says the scan walks the policy recursively and fails on an empty result |
| TRC-A2 | Now names the shared check, and what counts as an answered threat |
| TRC-B3 | Now names the same shared check |
| TRC-C2 | Now asserts the set is non-empty before comparing |
| **TRC-D3** | **New** - both templates are capped at 120 lines |

---

### Definition of Ready

- [x] **Summary is filled** - Goal, Approach and Why now are written prose.
- [x] **Problem traces up** - no `prd.md`; every scenario traces to one of four
      intents, each naming its published source.
- [x] **Behaviour is Given/When/Then** - every scenario has an observable Then.
- [x] **Traceability ids assigned** - 11 scenarios, TRC-A1 to TRC-D3.
- [x] **Affected surface named** - two new templates, one new check, one
      evidence-type description, one design-template section, one skill.
- [x] **No open questions** - five findings, all resolved above with a decider.
- [x] **Route still fits** - feature, unchanged, with the mis-prediction
      recorded rather than hidden.

Next stage: **design** (`/compass:design`).
