# Plan - adaptive-artifact-composition

> **Phase:** design · **Date:** 2026-08-24 · **Owning agent:** planner
> **Plan weight (from delivery-approach.md):** a real design.md, no distribution map

---

## 0. Summary

Two templates whose shapes are borrowed rather than invented, one check that
reads them, one description corrected, and one new optional section in the
design template. The whole change is markdown plus a single `CHECK_FN`.

The two templates are the point: `threat-model.md` asks the Threat Modeling
Manifesto's four questions and its third answer is a **scenario id**, so a
threat that has been noticed but not acted on is an empty cell. `rollback-plan.md`
records a **rehearsal**, not a plan, because a plan nobody has run is the
assertion guardrail G4 exists to reject.

---

## 1. Approach

`governance/routing-policy.yml` already names both kinds - `RP-REQUIRE-005` on
auth, payments or personal data, `RP-REQUIRE-006` on migrations. Nothing in this
change alters routing. What changes is that the kinds it names now exist, and
that one check reads them for the thing each is for.

| Step | File | What |
|---|---|---|
| 1 | `templates/threat-model.md` | New. Four questions, verbatim. Third answer is a scenario id. |
| 2 | `templates/rollback-plan.md` | New. A rehearsal record. |
| 3 | `governance/guardrails.yml` | The `rollback-plan` evidence type's description says the record must show a rehearsal. Version bump and hash re-pin. |
| 4 | `cli/compass_pkg/checks.py` | One check, `borrowed-documents-answered`, under G4. |
| 5 | `templates/design.md` + `skills/plan-authoring/SKILL.md` | A sixth optional section: cross-cutting concerns. |
| 6 | `tests/test_borrowed_document_shapes.py` | New. Ten mechanical scenarios. |

---

## 6. Design decisions (ADR-style)

### D1 - The third question's answer is a scenario id, not prose

**Chosen.** The "what are we going to do about it" column holds a `TRC-` id, or
the literal phrase `risk accepted` with a reason.

**Why.** The ThoughtWorks Radar has threat modelling in Adopt since Nov 2015 and
names its practical output form as "evil user stories" - which in Compass are
scenarios. Making the column hold an id means the framework's existing
machinery takes over: G1 forces a test on every scenario, G3 forces a trace,
and the evidence gate answers the Manifesto's fourth question. The threat model
stops being a document and becomes an input to the acceptance criteria.

**Rejected: free prose in that column.** It reads fine and checks nothing. The
Manifesto names the failure - "Admiration for the Problem" - and prose is how
you get it.

**Rejected: a threat model with no link to scenarios at all.** Then the fourth
question, "did we do a good enough job?", has no answer but the author's
opinion.

**Cost, stated plainly:** a threat found during design cannot be recorded until
a scenario exists for it. That is the intended friction, and `risk accepted` is
the escape hatch for a threat deliberately not acted on - which must carry a
reason, so it is a decision rather than a shrug.

---

### D2 - One check reads both documents, not one check each

**Chosen.** `borrowed-documents-answered`, registered under **G4**, reads
whichever of the two files exist in the issue directory and reports what is
unanswered.

**Why.** Both documents fail the same way: a section that was written and not
answered. Two checks would mean two names in `CHECK_FNS`, two entries in
`CHECK_GUIDANCE`, two declarations in the freeze baseline and two places for
the message style to drift.

**Rejected: two checks.** More mechanism for the same guarantee.

**Rejected: no check, template only.** Asking is what every unfilled form does.

**It returns `NOTHING_TO_CHECK` when neither file exists** - not a pass. Most
issues earn neither document, and a guard that reports a clean result for work
it never looked at is the failure mode this repository has found repeatedly.

---

### D3 - The check reads the document; the template owns the shape

**Chosen.** The check parses the markdown for the shape the template writes.

**Why.** There is precedent rather than novelty: `dod-evidence-typed` already
reads inline `(evidence: EV-id)` tags out of `verification-report.md`. The
template and the check ship together, so the shape being parsed is the shape
the framework wrote.

**Rejected: a structured evidence record instead.** It splits one thing in two
- the document a reviewer opens and a separate record asserting something about
it - with nothing keeping them honest with each other.

**Rejected: YAML front matter in the templates.** Machine-clean, and it makes a
document a person is meant to read open with a block of keys. These two
documents are read by people first.

---

### D4 - The evidence type's description is amended; no type is added

**Chosen.** `rollback-plan`'s description in `guardrails.yml` becomes: a record
showing the rollback was **rehearsed** - what was run, when, and against what.

**Why.** The type already exists and reads "a recorded plan for reverting a
change safely if it goes wrong", which is precisely the assertion Farley and
SWEBOK say is insufficient. `tests/test_stream_c_no_new_checks_or_gates.py`
freezes `evidence_types` and gate names against main; descriptions are free
text it does not cover. Amending what an existing type demands is the same
change with none of the mechanism.

**Rejected: a new `rollback-rehearsed` type.** A ninth near-synonym beside an
existing one, and the freeze test would be right to resist it.

---

### D5 - Cross-cutting concerns joins the optional five, and the skill moves with it

**Chosen.** A sixth optional section in `templates/design.md`, with its own
"when this earns a place" rule, and `skills/plan-authoring/SKILL.md` updated in
the same change.

**Why.** *Design Docs at Google* names security, privacy and observability as
cross-cutting concerns of the design - not separate documents. Compass already
has the mechanism: five optional sections, a skill that governs which earn a
place, and a lint that catches one kept but unfilled. What it lacked was this
section.

**Rejected: leaving the skill for later.** The template offering six while the
skill governs five is how an optional section becomes decoration, and TRC-C2
exists because that is easy to do and invisible afterwards.

---

### D6 - The templates are capped at 120 lines, and the cap is in a test

**Chosen.** TRC-D3. Both files, comments included.

**Why.** Every source behind this change argues for concision, and an argument
that is not in a test is a preference. Measured: `prd.md` is 106 lines,
`design.md` is 223. 120 sits above the PRD and far below the design - room for
a worked example, not for a form.

**Rejected: no cap.** The research thread that produced this scope was entirely
about not writing long documents, and shipping two uncapped templates out of it
would be the issue contradicting itself.

**Rejected: a tighter cap, 60.** It would refuse the worked example, and a
template without one teaches nobody what to write.

---

## 7. Governance check

```
compass policy lint: PASS - routing-policy.yml and guardrails.yml are
structurally valid.
```

| Guardrail | Verdict | How the design holds it |
|---|---|---|
| G1 tested before it lands | holds | Ten mechanical scenarios; TRC-D2 is narrative and cleared by its written When/Then. |
| G2 acceptance before code | holds | The spec was written and hardened before this design. |
| G3 traceability | holds | Each work unit names the scenarios it satisfies. |
| G4 evidence, not assertion | holds, and is the subject | D1 and D4 both turn an assertion into something checkable: a threat into a scenario, a plan into a rehearsal. The new check registers here. |
| G5 human signs off on the irreversible | not applicable | Two templates, one check, one description. |

**No guardrail is crossed, so no revision was needed.**

**Strategies.** S10 - a guard is accepted on a failure: the check has three
outcomes and the mutation round must break each. S11 - measure before arguing:
D6's cap and TRC-D1's nine kinds are counts from the tree. S14 - correct every
place at once: D5 moves the template and the skill together. **No departure
recorded.**

**ADR-002** governs the new check: it registers under G4 rather than becoming a
sixth guardrail, and is declared in the freeze baseline with the change that
introduces it - the path `dashboard-current` took. **ADR-006:** no evidence
type is added or removed, so no spine on disk changes meaning.

**No new ADR is proposed.** D1 to D6 are decisions inside this issue's surface.

---

## 8. Work units

| Unit | Scenario group(s) it satisfies | Code surface it touches | Independent of |
|---|---|---|---|
| U1 | A - TRC-A1, A2, A3 | `templates/threat-model.md` | U2, U3 |
| U2 | B - TRC-B1, B2 | `templates/rollback-plan.md`, `governance/guardrails.yml` | U1, U3 |
| U3 | C - TRC-C1, C2 | `templates/design.md`, `skills/plan-authoring/SKILL.md` | U1, U2 |
| U4 | A2 + B3 - the shared check | `cli/compass_pkg/checks.py`, `check_cmd.py`, `guardrails.yml`, the freeze baseline | depends on U1 and U2 |
| U5 | D - TRC-D1, D3 | `tests/test_borrowed_document_shapes.py` | depends on U1 and U2 |

**Parallelism assessment:** U1, U2 and U3 are genuinely independent - three
disjoint files, three disjoint scenario groups. U4 and U5 read what U1 and U2
write, so they follow. This repository runs solo by standing decision, so the
order is U1-U3 in any order, then U4 and U5.

**One shared surface, named rather than discovered:** U2 and U4 both edit
`governance/guardrails.yml` - U2 the evidence-type description, U4 the check
registration. Both need the version bumped and the hash re-pinned, and doing it
twice means two bumps for one change. **The bump happens once, in U4.**

---

## Gate

- [x] `design.md` exists.
- [x] The governance check passed - result above.
- [x] No PRD, so no intent-fidelity gate.
- [x] Work units named, with the one shared surface called out.
