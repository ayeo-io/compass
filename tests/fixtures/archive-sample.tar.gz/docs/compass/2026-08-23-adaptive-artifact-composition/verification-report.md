# Verification report - adaptive-artifact-composition

> **Issue:** Write the document kinds the routing policy already names and the
> framework cannot produce.
> **Delivery approach:** feature - six gates, requirements review at light weight.
> **Verified:** 2026-08-24. **Assessed by:** author (jed72).

**No independent reader.** The last issue's fresh-eyes pass found twelve
defects after the author had passed all eight gates, so the value of one is not
in doubt. S9's trigger is a sweep, and this is not one: two new templates, one
new module, one description, one section. Recorded so the absence is a stated
judgement rather than an oversight - if a reader is available, the two
templates are the part worth a cold read, because their whole claim is that
someone can fill them in.

---

## 1. Scenario acceptance results

Eleven criteria. Ten mechanical, all passing; one narrative.

| Group | Criteria | Result |
|---|---|---|
| A - the threat model produces work | TRC-A1, A2, A3 | PASS |
| B - the rollback plan records a rehearsal | TRC-B1, B2, B3 | PASS |
| C - cross-cutting concerns are a design section | TRC-C1, C2 | PASS |
| D - the promise the policy makes | TRC-D1, D3 | PASS |
| D - no document nothing asks for | TRC-D2 | narrative |

**TRC-D2 is narrative and earns it.** No test can observe whether a document's
need was "immediate and significant". What is recorded instead is the decision:
five planned documents became two. `test-strategy`, `test-plan` and
`release-plan` were dropped because no rule triggers them and no concise
published form exists to borrow - and TRC-D1 now makes the first half of that
mechanical, since a kind with no template fails.

## 2. Evidence

| Record | What it covers | Result |
|---|---|---|
| `evidence/full-suite.txt` | the whole suite | 1326 passed, 7 skipped (was 1316) |
| `evidence/compass-check.txt` (EV-CHK-1) | the mechanical gate | PASS - 12 passed, 4 nothing to check |
| `evidence/mutation-round.txt` (EV-MUT-1) | every guard broken deliberately | 13 of 13 caught |

**Coverage:** this repository declares no coverage floor, so there is nothing
to meet. Saying "coverage passes" would be a pass that measured nothing.

### What the mutation round found

Thirteen mutations. **Four were missed on the first pass, and three shared one
cause worth naming as a class:**

**The guard read the instructional comment rather than what the section asks
for.** Both templates open with a comment block quoting their sources, so those
blocks contain "rehearsal", "scenario" and "evidence" whatever the headings
say. TRC-A3 and TRC-B1 both passed with their headings renamed away; TRC-B2
passed with its opening clause reverted, because the SWEBOK quote after it
still said "rehearsed". All three now strip comments before asserting, and
TRC-B1 requires a *heading* rather than the word anywhere in the file.

**The fourth is the other familiar shape.** The templates are 81 and 79 lines
against a cap of 120, so raising the cap to 10,000 changed nothing observable.
The cap is now bounded against `design.md`'s own length, so a raise that puts
it out of reach fails here.

### And one found before the mutation round, by writing a guard wrong

TRC-D1's scan for "every kind the policy names" was first written against a
hard-coded path - `rules.floors_and_requirements` - which does not exist in the
policy. It reported **zero missing templates while two were missing.** A
recursive walk finds nine kinds and both gaps. The guard now fails when it
finds nothing rather than passing, and the requirements review records it.

## 3. Review dimensions

| Dimension | Applies? | Result | Assessed by | Evidence |
|---|---|---|---|---|
| correctness | always | PASS | author | 10 mechanical criteria; suite 1326 |
| governance | always | PASS | author | EV-CHK-1. The check joined G4 rather than becoming a sixth guardrail (ADR-002) and is declared in the freeze baseline. No evidence type added or removed. `guardrails.yml` 1.11.0 -> 1.12.0, re-pinned. |
| traceability | always | PASS | author | 11 changed files traced; the check passes |
| regression | yes | PASS | author | 1326 up from 1316, nothing previously passing fails |
| clarity | yes | PASS, and it is the weakest | author | The deliverable is two documents whose only job is to be fillable, and the author is the person who would find his own headings clear. No independent reader - see the note at the top. |
| security | scaled | PASS | author | Two markdown templates and one module that reads two files inside the issue directory. One of the templates is a threat model, which is a coincidence of naming: this change has no trust-boundary surface of its own. |

`verify.claims` and `verify.fitness` are **not** in this approach's gate set -
that is what dropping from initiative to feature means, and it is recorded here
so the report does not appear to skip gates it never had.

## 4. Gate decision

| Gate | Status | Evidence |
|---|---|---|
| verify.correctness | GREEN | EV-T-TRC-A1 |
| verify.governance | GREEN | EV-CHK-1 |
| verify.traceability | GREEN | EV-CHK-1 |
| verify.regression | GREEN | EV-T-TRC-A1 |
| verify.clarity | GREEN | EV-REVIEW-1 (this report) |
| verify.security | GREEN | EV-CHK-1 |

**Overall:** PASS - advance to ship.

---

## What this issue did not do

`artifact-filenames-rename-slice` holds items 5, 7 and 8 of the source
proposal - splitting `design.md`, renaming Brief by depth, and `work-plan.md`.
Measured at 333 occurrences across 100+ files and 52 documents in the archive,
which is why it is its own slice.

## Gate

- [x] Every required review dimension passed with evidence attached.
- [x] Every gate is GREEN with a resolving evidence pointer.
- [x] This report is complete - no empty evidence blocks.

### Definition of Done

- [x] **Every scenario passes** - §1; ten mechanical, one narrative.
- [x] **TDD suite green** - 1326 passed, 7 skipped.
- [ ] (evidence: EV-CHK-1) **Coverage meets the tested-before-ship guardrail's
      floor** - no floor is declared, so there is nothing to meet. Deliberately
      not ticked: a tick would claim a measurement nobody took.
- [x] **No lint / format / type errors** - the suite includes the house-style,
      terminology and vocabulary guards, and the terminology guard caught a
      bare guardrail code in one of the new templates.
- [ ] (evidence: EV-CHK-1) **Traceability intact** - 11 changed files traced.
- [x] *(carried to ship)* Living docs updated - the templates are the docs; the
      living spec is re-derived after landing.
- [x] **Every owed follow-up settled** - none owed. The rename half is its own
      issue, not a follow-up.

Next stage: **ship**.
