# Spec - the-human-front-door

## Summary

**Goal.** Let a reviewer see, from one page, what an issue is deciding, which
documents exist, which were deliberately left out and why - without reading the
routing algorithm or the directory listing.

**Approach.** Two mechanisms and a sweep. An **artifact registry** in `task.yml`
where each document declares its kind, path, status and the reason it exists -
or the reason it was omitted. A **resolver** that reads the registered path
first and the current flat filename second, so the 88 landed issues keep
working. A generated **`README.md` dashboard** that renders the registry and
carries no raw evidence. And the instruction sweep that stops stages pasting
raw output into documents a person reads.

**Why now / what changes.** The output is shaped for the agent that produced it
rather than the person approving it - the structural version of the complaint
3.2.0 fixed in prose. Afterwards a reviewer opens one file and sees the
decision, the pack and the omissions; the evidence is linked rather than pasted.

---

## How each role reads this file

- **Engineer** - group B is the risk. The registry is easy; not breaking 88
  landed issues is the work.
- **QA** - `TRC-B3` and `TRC-D1` are the ones to read first. Both concern what
  is reported when something is *missing* or *stale*, and this project has
  found repeatedly that the absent case is where a check quietly reports green.
- **Product owner** - the dashboard is the deliverable a person actually sees.
  If it does not answer "what am I approving" in the first three lines, the
  issue has not landed its intent.
- **Architect** - the resolver has a real decision in it: two lookup orders that
  must not diverge, and a compatibility path that has to be honest about the
  case where neither route resolves.

---

## Intent links

| Id | Intent | Source |
|---|---|---|
| INT-1 | Every document an issue produces declares why it exists, or why it does not | Proposal, the artifact registry |
| INT-2 | Issues written before the registry keep working | Proposal, the compatibility strategy |
| INT-3 | A reviewer learns the decision, the pack and the omissions from one page | Proposal, "`README.md`: the human front door" |
| INT-4 | A generated page that no longer matches its source says so | Found at triage - this project already has a derived artifact whose staleness is a recurring failure |
| INT-5 | Raw evidence is linked from human documents, never pasted into them | Proposal, item 4 |

---

## What was measured before writing this

- **88 issues have landed with no registry.** Whatever the resolver does for
  them is the compatibility contract, not an edge case.
- **`docs/system-spec.md` is the worked precedent for a generated artifact**, and
  its currency guard has fired twice today. A generated dashboard without the
  same guard will drift and be trusted anyway - which is why INT-4 exists and is
  not in the proposal.
- **Item 3 is not in this issue.** The terminal contract reaches 24 verbs and
  247 print sites and was split out before this spec was written.

---

## Scenario group A - the registry records what exists and why

### Scenario: a registered artifact declares its kind, path, status and reason
<!-- traceability id: TRC-A1 - serves: INT-1 -->

```gherkin
Scenario: a registered artifact declares its kind, path, status and reason
  Given an issue that produced a design document
  When its artifact registry is read
  Then the entry names the document's kind, its path, its status, and the
       reason it exists
```

### Scenario: an omitted artifact records why it was omitted
<!-- traceability id: TRC-A2 - serves: INT-1 -->

**This is the half that makes omission visible**, and it is the point of the
registry. A document that is absent because nobody thought of it and one that is
absent for a stated reason look identical in a directory listing.

```gherkin
Scenario: an omitted artifact records why it was omitted
  Given an issue where a candidate document was deliberately not written
  When its artifact registry is read
  Then the entry records the kind, a status of omitted, and the reason
```

### Scenario: the schema refuses an entry that explains nothing
<!-- traceability id: TRC-A3 - serves: INT-1 -->

An entry with no reason is a filename in a list. The registry's whole value is
the reason, so the schema is where that is enforced rather than left to habit.

```gherkin
Scenario: the schema refuses an entry that explains nothing
  Given a registry entry with no reason recorded
  When the issue spine is linted
  Then the lint fails and names the entry
```

---

## Scenario group B - issues written before the registry

**This group is the risk in this issue.** The registry is straightforward; not
breaking what already landed is the work.

### Scenario: a registered path resolves ahead of the flat filename
<!-- traceability id: TRC-B1 - serves: INT-2 -->

```gherkin
Scenario: a registered path resolves ahead of the flat filename
  Given an issue whose registry records a document at a nested path
  And a file of the same kind at the old flat filename
  When the CLI resolves that document
  Then it reads the registered path
```

### Scenario: an issue with no registry still resolves its artifacts
<!-- traceability id: TRC-B2 - serves: INT-2 -->

```gherkin
Scenario: an issue with no registry still resolves its artifacts
  Given an issue whose spine has no artifact registry
  When the CLI resolves one of its documents
  Then it reads the flat filename
  And nothing reports the missing registry as a fault
```

### Scenario: an artifact that resolves by neither route is reported, not silently absent
<!-- traceability id: TRC-B3 - serves: INT-2 -->

**The scenario QA should read first.** A resolver that returns nothing for a
missing document, and a caller that treats nothing as "not applicable", is how a
document silently stops being read. The interesting case in a compatibility rule
is what it does when neither route works.

```gherkin
Scenario: an artifact that resolves by neither route is reported, not silently absent
  Given a registry entry naming a path that does not exist
  And no file at the old flat filename either
  When the CLI resolves that document
  Then it reports that the document could not be found, naming the entry and
       both paths it tried
  And it does not report the document as deliberately omitted
```

### Scenario: every landed issue still resolves after the change
<!-- traceability id: TRC-B4 - serves: INT-2 -->

The compatibility claim, checked against the real archive rather than a fixture.

```gherkin
Scenario: every landed issue still resolves after the change
  Given every issue already recorded in this repository
  When each of its documents is resolved
  Then every document that could be found before can still be found
```

---

## Scenario group C - the dashboard

### Scenario: the dashboard names the decision required and where to start
<!-- traceability id: TRC-C1 - serves: INT-3 -->

```gherkin
Scenario: the dashboard names the decision required and where to start
  Given an issue awaiting a review
  When its dashboard is read
  Then the first screen states what is being asked of the reviewer
  And it names the one document to read
```

### Scenario: it lists every registered artifact with its status and why it exists
<!-- traceability id: TRC-C2 - serves: INT-3 -->

```gherkin
Scenario: it lists every registered artifact with its status and why it exists
  Given an issue whose registry records several documents
  When its dashboard is read
  Then each document appears with its status and the reason it exists
```

### Scenario: it lists what was deliberately omitted, with reasons
<!-- traceability id: TRC-C3 - serves: INT-3 -->

The proposal's own phrase for why this matters: it "makes omission visible
without making the reviewer read the routing algorithm".

```gherkin
Scenario: it lists what was deliberately omitted, with reasons
  Given an issue where candidate documents were deliberately not written
  When its dashboard is read
  Then each omission appears with the reason it was omitted
```

### Scenario: it carries no raw evidence
<!-- traceability id: TRC-C4 - serves: INT-3, INT-5 -->

```gherkin
Scenario: it carries no raw evidence
  Given an issue with recorded test runs and command output
  When its dashboard is read
  Then the evidence is linked rather than reproduced
  And no captured command output appears in the page
```

---

## Scenario group D - a generated page that has drifted

### Scenario: a dashboard that no longer matches the spine is reported as stale
<!-- traceability id: TRC-D1 - serves: INT-4 -->

**Not in the proposal, and the reason it is here is a measurement.** This
repository already generates `docs/system-spec.md` from issue records, and its
currency guard fired twice in one day. A generated page with no such guard
drifts and is trusted anyway, which is worse than no page.

```gherkin
Scenario: a dashboard that no longer matches the spine is reported as stale
  Given a dashboard generated from an issue's spine
  And the spine has changed since
  When the issue is checked
  Then the check reports the dashboard as stale and names the command that
       regenerates it
```

### Scenario: a drifted dashboard fails the check rather than warning
<!-- traceability id: TRC-D2 - serves: INT-4 -->

**Added during implementation, and it is TRC-D1 read literally.** TRC-D1 says
"when the issue is checked", and what got built first was a function nobody has
to call. A reviewer trusts the page in front of them, so the guard belongs where
their approval is gated - `compass check`, under the evidence-not-assertion
guardrail, because a drifted page is an assertion the record contradicts.

The two declining outcomes are stated as criteria, not left to the
implementation, because they are how this check would quietly become one that
cannot fail: an issue with no page, and a page a person wrote by hand, must both
decline to check rather than report a pass.

```gherkin
Scenario: a drifted dashboard fails the check rather than warning
  Given an issue whose dashboard was generated and whose spine has since changed
  When the issue is checked
  Then the check fails and names the command that regenerates the page
  And an issue with no dashboard reports nothing to check, not a pass
  And a hand-written README reports nothing to check, not a pass
```

### Scenario: the currency check is wired into a guardrail
<!-- traceability id: TRC-D3 - serves: INT-4 -->

A check function no guardrail lists never runs. Compass grows by adding checks
under the five existing guardrails and never a sixth letter (ADR-002), so this
one joins G4 - evidence, not assertion.

```gherkin
Scenario: the currency check is wired into a guardrail
  Given the shipped guardrail definitions
  When the check registry is read
  Then the currency check is registered, described, and listed by a guardrail
  And it carries the guidance that says why it matters and how to fix it
```

### Scenario: the pack separates a document that exists from one still owed
<!-- traceability id: TRC-C6 - serves: INT-1 -->

**Added during implementation, from reading this issue's own generated page.**
It listed seven documents as `draft` when three had never been written and four
were finished. `draft` is the status routing seeds, and nothing moves it. A
reviewer reading that page goes looking for files that are not there - which is
worse than no page, because it is a page that is confidently wrong.

The resolver already knows the difference between a document that resolves and
one that does not. The page simply was not asking it.

```gherkin
Scenario: the pack separates a document that exists from one still owed
  Given an issue whose earned pack includes a document nobody has written yet
  When the review page is rendered
  Then the document that exists is shown as written
  And the document that does not exist is shown as still owed
```

### Scenario: a document's status can be moved, and an omission recorded
<!-- traceability id: TRC-C7 - serves: INT-1 -->

**Added during implementation, from reading this issue's own page.** Routing
seeds every earned document as `draft` and nothing could move it, so `omitted`,
`awaiting-approval` and `approved` were all unreachable - which left the page's
two headline sections, "Decision required" and "Deliberately omitted",
permanently empty. TRC-A2 and TRC-C3 were testing behaviour the framework had no
way to produce.

An omission must carry a reason. Without one, a document deliberately dropped
and a document nobody got to look identical, and telling those apart is the
reason the registry exists.

```gherkin
Scenario: a document's status can be moved, and an omission recorded
  Given an issue whose review pack was computed by the evaluator
  When a document is omitted with a reason, and another is put up for approval
  Then the spine records both, and the review page shows the decision and the
       omission with its reason
  And omitting a document without a reason is refused
  And setting a status on a document the issue never earned is refused
```

---

## Scenario group E - evidence is linked, not pasted

### Scenario: the instructions tell a stage to link evidence rather than paste it
<!-- traceability id: TRC-E1 - serves: INT-5 -->

```gherkin
Scenario: the instructions tell a stage to link evidence rather than paste it
  Given the instructions a stage follows when recording a result
  When they are read for what to do with captured output
  Then they say to write the evidence file and link it
  And no instruction asks for raw output to be pasted into a document a person
      reads
```

---

## Coverage ledger

| Scenario | Intent | Test written | Passing |
|---|---|---|---|
| TRC-A1 | INT-1 | [ ] | [ ] |
| TRC-A2 | INT-1 | [ ] | [ ] |
| TRC-A3 | INT-1 | [ ] | [ ] |
| TRC-B1 | INT-2 | [ ] | [ ] |
| TRC-B2 | INT-2 | [ ] | [ ] |
| TRC-B3 | INT-2 | [ ] | [ ] |
| TRC-B4 | INT-2 | [ ] | [ ] |
| TRC-C1 | INT-3 | [ ] | [ ] |
| TRC-C2 | INT-3 | [ ] | [ ] |
| TRC-C3 | INT-3 | [ ] | [ ] |
| TRC-C4 | INT-3, INT-5 | [ ] | [ ] |
| TRC-D1 | INT-4 | [ ] | [ ] |
| TRC-E1 | INT-5 | [ ] | [ ] |

Every intent is served: INT-1 has three, INT-2 has four, INT-3 has four,
INT-4 has one, INT-5 has two.

---

## What this cannot do

**A registry records a reason; it cannot check the reason is true.** "Threat
model omitted - no trust-boundary change" is checkable by a person and not by
this. The registry makes the claim visible, which is the whole of what it
offers, and a reviewer is still what catches a wrong one.

**The dashboard is only as good as what the stages record.** If a stage writes
a document and does not register it, the page will not show it - and `TRC-B3`
catches an entry pointing at nothing, not a file pointing at no entry. That gap
is real and belongs to `adaptive-artifact-composition`, which decides what an
issue earns in the first place.

**Nothing here changes the terminal.** A reviewer told about the dashboard in
twelve readable lines is `the-terminal-output-contract`.

---

## Grouping by independence, for the distribution map

| Group | Touches | Depends on |
|---|---|---|
| A | `schemas/task.schema.json`, the spine | nothing |
| B | the CLI's artifact resolver | A - it resolves what A records |
| C | a new dashboard generator | A - it renders what A records |
| D | the dashboard generator plus a check | C |
| E | `commands/`, `skills/`, `templates/` prose | nothing |

**B and C are genuinely independent of each other** - different code, disjoint
scenarios, both reading A. E shares nothing with any of them. So the honest
decomposition is three streams after A lands: the resolver, the dashboard, and
the prose sweep.
