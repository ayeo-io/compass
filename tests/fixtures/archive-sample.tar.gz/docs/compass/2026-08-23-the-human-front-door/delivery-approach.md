# Delivery approach - the-human-front-door

> **Issue:** A reviewer gets a directory of artifacts and a scrollback. Give them
> a registry that records which documents exist and why, and one page that reads
> it.
> **Triaged:** 2026-08-23 by jed72 · **Revision:** 3 (the artifact set is a routing output)
> **Reference shape:** initiative

---

## 1. The assessment

The proposal's diagnosis, and it is the structural version of what 3.2.0 fixed
in prose: **the output is shaped for the agent that produced it rather than the
person who has to approve it.** A reviewer should learn in under a minute what
is changing, which documents exist, which were deliberately left out and why,
and exactly what they are being asked to approve.

| Dimension | Value | Justification |
|---|---|---|
| **Risk** | cross-cutting | It changes the spine schema, adds a generated artifact to every issue, and changes how the CLI resolves an artifact path. Every stage records into it. Not `critical` - no data loss, no auth, no money, and a clean revert. |
| **Familiarity** | brownfield-mapped | The spine, its schema and the artifact paths were all read closely in this cycle. `receipt.py` is a worked precedent for rendering a one-screen view from the spine. |
| **Size** | large | A schema change, a resolver with a compatibility path for 88 landed issues, a dashboard generator, and a prose sweep over the commands that paste raw output. Real architecture in the resolver. |
| **Goal & role** | delivery · engineer | |

**Labels:** `cli`, `public-api`, `docs`

**Urgency:** none.

---

## 2. Revision 3 - the split was wrong, and why

**The registry was separated from the thing that computes it, so it shipped
inert.** Built and verified: nothing populates it. A brand-new issue filed the
same day renders "No documents registered yet", and every sibling record type -
scenarios, evidence, changed files - has a verb that writes it while artifacts
had none.

The fix is not a writer verb. **It is that the artifact set is a routing output,
computed from the assessment, exactly like the stages, the gates and the
topology.** `compass approach evaluate` already writes four such outputs from
one judgement; this is the fifth. Each shape in `routing-policy.yml` already
declares `stages`, `gates` and `topology` in one block - `artifacts` sits beside
them, and a policy rule adds one on a trigger the way `RP-REQUIRE-003` adds a
gate.

**This answers the objection that raised it.** A variable rename does not need a
review pack, and nothing special-cases that: a trivial, atomic, mapped
assessment computes a tiny artifact set for the same reason it already computes
`clarify: collapsed` and `distribute: skipped`. Nobody records an omission by
hand, and there is no vocabulary to invent - the reason an artifact is or is not
earned is the rule that fired.

**What this absorbs.** The routing half of `adaptive-artifact-composition` folds
back in: deciding what an issue earns is this mechanism. What stays there is the
template work - the new document kinds themselves, and splitting `design.md`.

**The dimensions did not change**, so `compass approach evaluate --write
--reason ...` declined to log a re-assessment and said so: "no route change
detected - the --reason was NOT recorded." That is correct. This is a scope
change, recorded as a revision, not a re-route.

**Decided by:** jed72, 2026-08-23, on the framework's own terms: an
objective assessment of the work, and the process and documentation that
assessment earns.

## 3. Revision 2 - what changed and why

**Item 3, the terminal output contract, was split out** into
`the-terminal-output-contract` on 2026-08-23, before any spec was written.

Measured rather than judged: it reaches **24 CLI verbs and 247 print sites**,
and it shares no code with the registry. Keeping them together would have meant
the registry could not ship until that sweep was finished. The proposal grouped
them under one heading because they serve one theme, and a theme is not a
dependency.

The size stays `large`. What changed is the reach: two mechanisms and a prose
sweep, rather than the whole terminal surface.

**Decided by:** jed72.

---

## 4. Policy rules that fired

- Policy file: `governance/routing-policy.yml`, version 2.1.2.

| Kind | Triggered by | Effect | Rationale, quoted |
|---|---|---|---|
| shape | large + cross-cutting | candidate **initiative** | "Large work - full weight, plausibly parallel" (`RP-SHAPE-004`) |
| requirement | risk = cross-cutting | gate `verify.fitness` added | "Architectural fitness checked before cross-cutting or critical changes land" (`RP-REQUIRE-003`) |

**Advisory strategy:** `regression-baseline` (`RP-ADV-001`). Capture the suite
green before the schema changes, re-run after.

---

## 5. The delivery approach

**initiative.** Eight gates: correctness, governance, traceability, regression,
security, clarity, claims, **fitness**.

### 4a. Per-stage weight

Every stage full weight - an initiative.

| Stage | Weight | Why |
|---|---|---|
| Define acceptance criteria | full | The compatibility rule is the whole risk: 88 landed issues have no registry and must keep working. Scenarios have to pin that, not just the happy path. |
| Requirements review | full | 4c names two questions that need a decision rather than a correction. |
| Design | full | The resolver has a real architectural choice in it - see 4c. |
| Break down the work | full, streams unbounded by policy | The registry and the dashboard are separable; the map records whether they genuinely are. |
| Implement | full | Test surface scaled to cross-cutting risk. |
| Test and review | full - 8 gates | 4b. |
| Ship | full | |

### 4b. Gate set

Eight. `verify.fitness` was added by policy and **will clear on a check that
runs nothing**, because this repository declares no project guardrails. Recorded
now so the verification report states it rather than a reader assuming the gate
exercised something.

`verify.claims` is in the set and there is no marketer: it will record an empty
claim set, which is different from a claim review that passed.

### 4c. The questions this issue has to answer

Named at triage so the requirements review argues them rather than the
implementation discovering them.

1. **What happens to the 88 landed issues with no registry?** The proposal says
   the CLI resolves the registered path first and the flat filename second. That
   is a compatibility rule, and this project has just learned - twice - that the
   interesting half of such a rule is what it reports when neither resolves, and
   whether "no registry" is reported as absent or as passing.

2. **Is the dashboard generated or authored?** The proposal says "regenerated
   after every stage", which makes it derived - and this project already has a
   derived artifact whose staleness is a recurring failure. If it is generated,
   it needs the same currency guard `docs/system-spec.md` has, or it will drift
   and be trusted anyway.

### 4d. Topology

Policy sets no ceiling. The registry and the dashboard are candidates for two
streams; the distribution map decides. This repository does not use worktrees by
standing decision, so it runs solo whatever the map says - recorded there as
cap-free rather than as a de-scope.

---

## 6. The de-scope ledger

**Empty.** An initiative de-scopes nothing.

The terminal contract is **not** a de-scope: it moved to its own issue with its
own approach, which is a split rather than a reduction, and §2 records it.

---

## 7. Owed follow-ups

None owed by the approach.

**Sequencing, recorded rather than assumed:** `adaptive-artifact-composition`
and `revision-bound-approvals` both read the registry this issue builds, and
`the-terminal-output-contract` points its "Start:" line at the dashboard. All
three wait on this one. That is a dependency, not a queue preference.

---

## 8. Recorded decisions

| What was decided | Choice | Who | Why |
|---|---|---|---|
| Item 3's home | Its own issue | jed72 | 24 verbs and 247 print sites, sharing no code with the registry. Measured before deciding. |
| Risk | cross-cutting, not critical | jed72 | It changes what every stage records, but loses no data, touches no auth or money, and reverts cleanly. |

No override of a computed value.

---

## 9. Confirmation

- [x] Approach presented to the invoker and confirmed.
- [x] Every dimension carries a justification.
- [x] De-scope ledger empty, as an initiative requires.
