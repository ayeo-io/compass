# Clarifications - the-human-front-door

> **Phase:** refine · **Date:** 2026-08-23 · **Owning agent:** spec-author
> **Requirements review weight (from delivery-approach.md):** full pass

---

## Self-QA of the spec

**No contradiction between scenarios, and one gap the spec names rather than
closes.** `TRC-B3` catches a registry entry pointing at no file. Nothing here
catches the reverse - a document written and never registered - and the spec
says so in its closing section, assigning it to
`adaptive-artifact-composition`. That is the right home: this issue builds the
record, the other decides what goes in it.

**The four define-stage scans ran clean.** One thing worth recording because it
nearly became a finding: the orphan-intent scan first reported all five intents
orphaned. That was the scan's own regex capturing the `-->` comment terminator
into the intent id, not a defect in the spec. Re-run against the real marker
format, every intent is served. A scan that reports everything broken is usually
broken itself, and checking which before acting is the difference between a
finding and a wasted rewrite.

## Governance QA of the spec

**No guardrail is crossed.**

**`verify.fitness` is in this issue's gate set and will clear on a check that
runs nothing**, because this repository declares no project guardrails of its
own. Recorded at triage, repeated here, and owed again in the verification
report - on an issue about making omission visible, a gate that silently
exercised nothing would be a poor thing to leave unstated.

**`verify.claims` is in the set with no marketer in play.** It records an empty
claim set, which is not the same as a claim review that passed.

**S10 - mutation proof.** The presence-shaped scenarios here are `TRC-C1` to
`TRC-C4` and `TRC-E1`, all of which assert that generated or written text says
something. `TRC-C4` is the awkward one: it asserts an **absence** - no raw
evidence in the page - and this session has now found three empty checks that
were whole-file searches. A mutation must plant evidence into the page rather
than delete a marker.

**S6 - regression baseline** fired advisory (`RP-ADV-001`). The schema and the
resolver are shared surface; capture the suite green before touching them.

**S9 - fresh eyes** does not apply: this is new mechanism, not a sweep.

---

## Ambiguity ledger

### Q1 - what the resolver reports when neither route works

- **Question:** Banked at triage. The proposal gives the lookup order - registered path first, flat filename second - and says nothing about the case where neither resolves. That case is the compatibility contract, not an edge.
- **Resolution:** **Three outcomes, and the third is the point.** *Found* - the resolver returns the path and says which route found it. *Deliberately omitted* - the registry says so, with a reason, and the caller is told that rather than "missing". *Unresolvable* - a registry entry names a path that does not exist and no flat filename does either; the resolver reports it, naming the entry and both paths it tried, and **must not report it as omitted.** Conflating unresolvable with omitted is precisely how a document stops being read while the page says everything is accounted for.
- **Decided by:** spec-author, at the requirements review
- **Governance reference:** G4; `TRC-B3`
- **Spec change:** none - `TRC-B3` already requires both halves, including "it does not report the document as deliberately omitted".
- **Status:** resolved

### Q2 - is the dashboard generated or authored

- **Question:** Banked at triage. "Regenerated after every stage" makes it derived, and a derived artifact that drifts is a failure this repository already has.
- **Resolution:** **Generated, with a currency guard, and never hand-edited.** The worked precedent is `docs/system-spec.md`: derived from the issue records, committed, and guarded by `test_system_spec_currency.py`, which fired twice on 2026-08-23. The dashboard gets the same treatment - `TRC-D1` is that guard. The alternative considered was an authored page a stage updates: rejected because it would drift silently, and because the proposal's value is that the page *cannot* disagree with the registry.
- **Decided by:** spec-author, at the requirements review
- **Governance reference:** INT-4; the precedent in `docs/system-spec.md`
- **Spec change:** none - `TRC-D1` already carries it.
- **Status:** resolved

### Q3 - what the registry does about an artifact nobody registered

- **Question:** Raised by the spec's own closing section. If a stage writes a document and does not register it, the dashboard will not show it, and nothing here notices.
- **Resolution:** **Out of scope, and assigned rather than merely excluded.** It belongs to `adaptive-artifact-composition`, which decides what an issue earns - that issue is where a document becomes *expected*, and only something that expects a document can notice its absence from the register. This issue builds the record; it cannot know what should have been in it. Recorded here so a later reader sees a decision rather than an oversight, and so the receiving issue's triage inherits it.
- **Decided by:** jed72, 2026-08-23
- **Governance reference:** n/a
- **Spec change:** none - the spec's "What this cannot do" already names it.
- **Status:** resolved

### Q4 - what "status" a registry entry can carry

- **Question:** `TRC-A1` requires a status and never says which values exist. An open vocabulary makes `TRC-C2` unfalsifiable - any string would satisfy "has a status".
- **Resolution:** A closed set, enforced by the schema: **`draft`, `awaiting-approval`, `approved`, `superseded`, `omitted`.** `omitted` is the one that carries `TRC-A2`, and pairing it with a required reason is what makes an omission a decision rather than a gap. The set is taken from the proposal's own worked example, which uses `approved` and `omitted`, plus the states its dashboard mock-up displays - "Awaiting approval", "Draft", "Required". "Required" is not included: it describes something that does not exist yet, which is `adaptive-artifact-composition`'s question, not this one's.
- **Decided by:** spec-author, at the requirements review
- **Governance reference:** `TRC-A1`, `TRC-A3`, `TRC-C2`
- **Spec change:** none - this constrains the schema the design writes.
- **Status:** resolved

---

## Gate

- [x] No ambiguity left `open` - four entries, four resolved.
- [x] `acceptance-criteria.md` updated to reflect every resolution - no edit needed; all four constrain the design rather than changing a scenario.
- [x] Non-engineering roles in play have reviewed - none are in play. `role: engineer`, no `prd.md`, no claims, no UI contract. The spec's role-guide block carries the QA, product-owner and architect readings.

### Definition of Ready

- [x] **Summary is filled** - Goal, Approach, Why now / what changes, all written prose.
- [x] **Problem traces up** - the companion proposal, quoted by section, plus the two measurements that produced `TRC-D1` and the item-3 split.
- [x] **Behaviour is Given/When/Then** - all thirteen, each with an observable `Then`. The presence-shaped ones are named in the governance QA above.
- [x] **Traceability ids assigned** - TRC-A1 to TRC-E1, thirteen, each with a linked intent; 14 slots because `TRC-C4` serves two.
- [x] **Affected surface named** - `schemas/task.schema.json`, the CLI's artifact resolver, a new dashboard generator, and the prose in `commands/`, `skills/` and `templates/`.
- [x] **No open questions** - four resolved.
- [x] **Approach still fits** - nothing found here changes a dimension. The issue is still large and cross-cutting after item 3 left.

Next stage: **design** (`/compass:design`).
