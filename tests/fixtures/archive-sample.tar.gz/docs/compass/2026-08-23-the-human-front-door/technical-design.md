# Plan - the-human-front-door

> **Phase:** design · **Date:** 2026-08-23 · **Owning agent:** planner
> **Delivery approach:** initiative · 8 gates · streams unbounded by policy
> **Builds on:** `acceptance-criteria.md` (13 scenarios), `requirements-review.md` (4 resolutions)

---

## 0. Summary

Three pieces, in dependency order.

The **registry** is a list under `artifacts:` in `task.yml`, schema-enforced: a
closed status vocabulary and a required reason on every entry. The reason is the
whole value - a filename with no reason is a directory listing.

The **resolver** stays `artifact_path()` for the 14 call sites that want a path,
and gains a sibling that returns *why* - found by registry, found by flat
filename, deliberately omitted, or unresolvable. The last two are different
answers and conflating them is how a document stops being read while the page
says everything is accounted for.

The **dashboard** is generated from the registry, committed, and guarded for
staleness the way `docs/system-spec.md` already is.

---

## 1. Approach

`schemas/task.schema.json` gains an `artifacts:` array. `cli/compass_pkg/core.py`
gains `resolve_artifact()` beside the existing `artifact_path()`.
`cli/compass_pkg/dashboard.py` renders `README.md` into the issue directory. A
new check reports a stale dashboard. The prose sweep corrects the instructions
that ask for raw output to be pasted into a document a person reads.

---

## 2. Interaction - the four answers a lookup can give

The resolver's shape is the design, so it gets the diagram.

```mermaid
flowchart TD
    A[resolve_artifact task_dir, kind] --> B{registry entry<br/>for this kind?}
    B -- no --> C{flat filename<br/>on disk?}
    C -- yes --> D[FOUND via flat<br/>path returned]
    C -- no --> E[ABSENT<br/>no entry, no file]
    B -- "yes, status: omitted" --> F[OMITTED<br/>reason returned]
    B -- "yes, has path" --> G{registered path<br/>on disk?}
    G -- yes --> H[FOUND via registry<br/>path returned]
    G -- no --> I{flat filename<br/>on disk?}
    I -- yes --> J[FOUND via flat<br/>compatibility fallback]
    I -- no --> K[UNRESOLVABLE<br/>entry names a path<br/>that is not there]

    style K fill:#8a1c1c,color:#fff
    style F fill:#1f6f3f,color:#fff
```

**The red box is the one this issue exists to get right.** `UNRESOLVABLE` and
`OMITTED` both mean "no document here", and they mean opposite things: one is a
decision, the other is a broken record. A resolver that returns nothing for both
lets a document quietly stop being read while the dashboard reports it as
deliberately left out.

`ABSENT` is the state every one of the 88 landed issues is in for most kinds,
and it is not a fault - `TRC-B2` requires it to be reported as ordinary.

---

## 3. The shape of the change

**The registry entry:**

```yaml
artifacts:
  - id: ART-DESIGN
    kind: design
    path: design.md
    status: approved
    reason: an initiative earns a full design; the resolver has a real choice in it
  - id: ART-THREAT
    kind: threat-model
    status: omitted
    reason: no auth, privacy or trust-boundary surface changes in this issue
```

`status` is a closed set - `draft`, `awaiting-approval`, `approved`,
`superseded`, `omitted` - and `reason` is required on every entry, including the
omitted ones. That pairing is what makes an omission a decision.

**The resolver, beside the existing one:**

```python
def artifact_path(task_dir, name):
    """The on-disk path of a per-issue artifact, by its v2 filename.

    Unchanged for its 14 call sites. Registry-aware: it prefers a registered
    path and falls back to the flat filename, so existing callers get the right
    file without knowing the registry exists.
    """

def resolve_artifact(task_dir, kind):
    """Where a document is, and WHY that is the answer.

    Returns (state, path, reason) where state is one of:
      FOUND        - path is real; reason says which route found it
      OMITTED      - the registry records a deliberate omission, with its reason
      UNRESOLVABLE - an entry names a path that is not there, and no flat
                     filename either. Reports both paths tried.
      ABSENT       - no entry and no file. Ordinary for an issue that predates
                     the registry; never a fault on its own.

    OMITTED and UNRESOLVABLE are deliberately distinct. Both mean "no document",
    and treating them alike is how a broken record reads as a decision.
    """
```

---

## 4. Design decisions

### DD-1 - `artifact_path` keeps its signature; a sibling carries the reason

- **Context:** 14 call sites across 6 modules take a path string. The new information - *why* - has no room in a string.
- **Decision:** `artifact_path()` keeps returning a path and becomes registry-aware internally. `resolve_artifact()` is new and returns the four-state answer.
- **Alternatives considered:** *Change `artifact_path`'s return type* - touches 14 call sites for information 12 of them do not want, and every one becomes a place to get the unpacking wrong. *Put the registry lookup only in the new function* - then the 14 existing callers keep reading flat filenames and the registry does nothing for them, which defeats the compatibility strategy.
- **Consequences:** Two functions over one lookup, which must not diverge. They share the resolution internally so there is one order, not two.
- **Governance tie:** `requirements-review.md` Q1; `TRC-B1`, `TRC-B2`

### DD-2 - four states, not a nullable path

- **Context:** The obvious resolver returns a path or `None`.
- **Decision:** Four named states. `OMITTED` and `UNRESOLVABLE` are never collapsed.
- **Alternatives considered:** *Path or `None`* - the caller then decides what `None` means, and every caller decides differently. The proposal's own value is that omission is *visible*; a nullable path makes an omission and a broken entry indistinguishable at exactly the moment the distinction matters.
- **Consequences:** Callers must handle four cases. That is the point, and `TRC-B3` is where it is enforced.
- **Governance tie:** `requirements-review.md` Q1; `TRC-B3`

### DD-3 - the dashboard is generated, committed and guarded

- **Context:** "Regenerated after every stage" makes it derived.
- **Decision:** Generated from the registry, never hand-edited, with a currency check that reports it stale - the same treatment `docs/system-spec.md` has.
- **Alternatives considered:** *An authored page a stage updates* - it drifts silently, and the proposal's value is that the page cannot disagree with the registry. *Generated but unguarded* - this repository's own derived spec went stale twice on 2026-08-23; an unguarded generated page is trusted anyway, which is worse than no page.
- **Consequences:** One more thing that can be stale, and one more check that says so. `TRC-D1` is the guard.
- **Governance tie:** `requirements-review.md` Q2; `TRC-D1`; the precedent in `test_system_spec_currency.py`

### DD-4 - the schema enforces the reason, not a convention

- **Context:** Every entry needs a reason and nothing would stop one being written without.
- **Decision:** `reason` is `required` in the schema, and `status` is an `enum`. `compass issue lint` fails on an entry missing either.
- **Alternatives considered:** *Require it by convention and check it in a test* - a test over this repository's own issues would pass while an adopter's registry rotted. The schema travels with the framework.
- **Consequences:** A registry entry cannot be added casually, which is the intended friction.
- **Governance tie:** `requirements-review.md` Q4; `TRC-A3`

---

## 5. Governance check

Against `governance/guardrails.yml` (v1.10.1), `governance/strategies.md`, and
`governance/routing-policy.yml` (v2.1.2).

### Walk 1 - guardrails (hard, evidence)

| Guardrail | Result | The plan element that clears it |
|---|---|---|
| G1 tested before it lands | clears | 13 scenarios across two new test files; cleared at verify with the run |
| G2 acceptance before code | clears | 13 scenarios hardened before this design |
| G3 traceability holds | clears | §6 maps every unit to its scenario ids |
| G4 evidence, not assertion | clears | `TRC-B4` checks the compatibility claim against the real archive, not a fixture |
| G5 human signs off | does not apply | risk cross-cutting, not critical; no auth, payments, personal data or migrations |

### Walk 2 - strategies (judgement, not evidence)

| Strategy | Assessment |
|---|---|
| S1 BDD / S2 TDD | followed |
| S3 simplest thing | followed - `artifact_path` keeps its signature rather than 14 call sites changing for information they do not want |
| S6 regression baseline | **applies** - `RP-ADV-001` fired. The schema and the resolver are shared surface; capture the suite green before touching them and re-run after. |
| S10 mutation proof | followed. `TRC-C1` to `TRC-C4` and `TRC-E1` are presence-shaped, and `TRC-C4` asserts an **absence** - its mutation must plant evidence into the page, not delete a marker. Three empty checks have been found this session, all whole-file searches; every assertion here reads the thing its scenario names. |
| S11 measure before arguing | followed - the item-3 split rested on 24 verbs and 247 print sites, and `TRC-D1` exists because a derived artifact went stale twice in one day |
| S14 correct every place at once | followed - `artifact_path` is made registry-aware rather than leaving 14 call sites on the old path |
| Voice strategies | n/a - no marketer, no claims |

**Departures:** none.

### Walk 3 - routing policy

The plan assumes what `delivery-approach.md` revision 2 records: initiative,
eight gates, `RP-REQUIRE-003` fired, no ceiling on streams. It skips no stage.

**`verify.fitness` will clear on a check that runs nothing** - this repository
declares no project guardrails. Stated at triage, at the requirements review,
and owed again in the verification report.

**Result: pass.**

---

## 6. Work units

| Unit | Scenario group(s) | Surface | Independent of |
|---|---|---|---|
| U0 | none - S6 baseline | records the suite green before the schema changes | prerequisite |
| U1 | A - TRC-A1, A2, A3 | `schemas/task.schema.json` | U5 |
| U2 | B - TRC-B1, B2, B3, B4 | `cli/compass_pkg/core.py` resolver | depends on U1 |
| U3 | C - TRC-C1, C2, C3, C4 | `cli/compass_pkg/dashboard.py` (new) | depends on U1; independent of U2 |
| U4 | D - TRC-D1 | the currency check | depends on U3 |
| U5 | E - TRC-E1 | `commands/`, `skills/`, `templates/` prose | independent of all |

**Parallelism assessment:** U2 and U3 are genuinely independent - different
files, disjoint scenarios, both reading U1. U5 shares nothing with any of them.
So the honest decomposition is three streams once U1 lands. Policy sets no
ceiling, so nothing is capped away; this repository does not use worktrees by
standing decision, so it runs solo in order U0 → U1 → U2 → U3 → U4 → U5.

---

## Gate

- [x] Every scenario in `acceptance-criteria.md` is covered by a work unit - all 13.
- [x] Governance check passes; no strategy departure to record.
- [x] Parallel work is possible and §6 is the map; three streams, no policy ceiling, solo in practice by standing decision - recorded as cap-free rather than as a de-scope.

Next stage: **break down the work** (`/compass:breakdown`) - solo, so straight to **implement**.
