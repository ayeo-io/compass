# Verification report - the-human-front-door

> **Issue:** A reviewer gets a directory of artifacts and a scrollback. Give them
> a registry that records which documents exist and why, and one page that reads it.
> **Delivery approach:** initiative - eight gates, every stage full weight.
> **Verified:** 2026-08-23. **Assessed by:** author (jed72). There is no
> second engineer on this project, and saying so is the point of the field - an
> author-assessed dimension is weaker than an independently assessed one, because
> the author cannot see what they did not think of.

---

## 1. Scenario acceptance results

Twenty-two scenarios, all passing. The suite runs them as ordinary tests; the
acceptance check and the test suite are the same artifact read at two times.

| Scenario id | Title | Result | Evidence |
|---|---|---|---|
| TRC-A1 | a registered artifact declares its kind, path, status and reason | PASS | EV-T-TRC-A1 |
| TRC-A2 | an omitted artifact records its reason | PASS | EV-T-TRC-A1 |
| TRC-A3 | the schema refuses an entry with no reason | PASS | EV-T-TRC-A1 |
| TRC-B1 | a registered path resolves | PASS | EV-T-TRC-A1 |
| TRC-B2 | neither route resolving is reported, naming both paths tried | PASS | EV-T-TRC-A1 |
| TRC-B3 | an omission carries its reason and is not confused with absence | PASS | EV-T-TRC-A1 |
| TRC-B4 | the 88 landed issues with no registry still resolve | PASS | EV-T-TRC-A1 |
| TRC-C1 | the first screen states what is being asked and what to read | PASS | EV-T-TRC-C1 |
| TRC-C2 | each document appears with its status and the reason it exists | PASS | EV-T-TRC-C1 |
| TRC-C3 | each omission appears with the reason it was omitted | PASS | EV-T-TRC-C1 |
| TRC-C4 | evidence is linked, not reproduced | PASS | EV-T-TRC-C1 |
| TRC-C5 | the page can be generated, and checked, from the CLI | PASS | EV-T-TRC-C1 |
| TRC-C6 | the pack separates a document that exists from one still owed | PASS | EV-T-TRC-C6 |
| TRC-C7 | a document's status can be moved, and an omission recorded | PASS | EV-T-TRC-C7 |
| TRC-D1 | a dashboard that no longer matches the spine is reported as stale | PASS | EV-T-TRC-C1 |
| TRC-D2 | a drifted dashboard fails the check rather than warning | PASS | EV-T-TRC-D2 |
| TRC-D3 | the currency check is wired into a guardrail | PASS | EV-T-TRC-D2 |
| TRC-E1 | the instructions tell a stage to link evidence rather than paste it | PASS | EV-T-TRC-E1 |
| TRC-F1 | the evaluator computes the artifact set | PASS | EV-T-TRC-F1 |
| TRC-F2 | a trivial change earns almost nothing | PASS | EV-T-TRC-F1 |
| TRC-F3 | a policy rule adds an artifact the way it adds a gate | PASS | EV-T-TRC-F1 |
| TRC-F4 | the artifact set is deterministic | PASS | EV-T-TRC-F1 |

## 2. Test suite evidence

Linked, not reproduced.

| Record | What it covers | Result |
|---|---|---|
| `evidence/full-suite.txt` | the whole repository suite | 1283 passed, 7 skipped |
| `evidence/green-TRC-A1.json` | the registry and resolver groups | green |
| `evidence/green-TRC-C1.json` | the dashboard group | green |
| `evidence/green-TRC-D2.json` | the currency check | green |
| `evidence/green-TRC-E1.json` | the link-do-not-paste sweep | green |
| `evidence/green-TRC-F1.json` | the routing output group | green |
| `evidence/mutation-round.txt` (EV-MUT-1) | every new guard broken deliberately | 13 of 13 caught |
| `evidence/mutation-round-2.txt` (EV-MUT-2) | the guards added after reading the page | 3 of 3 caught |
| `evidence/green-TRC-C6.json` | the written-versus-owed distinction | green |
| `evidence/green-TRC-C7.json` | the status verb | green |
| `evidence/compass-check.txt` (EV-CHECK-1) | the run where the NEW check failed | see below |
| `evidence/compass-check-final.txt` (EV-CHECK-2) | the same run once the page was regenerated | 14 passed, 3 nothing to check |

**Coverage:** this repository declares no coverage floor - the one in
`guardrails.yml` is a commented-out example. So there is no floor to meet, and
saying "coverage passes" here would be a pass that measured nothing. Recorded as
such rather than ticked.

### The new check firing in production, not in a test

`EV-CHECK-1` is worth opening. It is a real `compass check` run on this issue
that went **red** on `dashboard-current`, because the spine had gained scenarios
and evidence since the review page was rendered. Nobody staged it. The guard
caught its own author mid-issue, which is the strongest evidence available that
it is not a check that cannot fail.

### The mutation round, and what it found

`EV-MUT-1`. Each guard was proved by breaking the thing it watches. Round one
caught seven of eight; the misses were real defects in guards I had written:

| Guard | The defect |
|---|---|
| TRC-F2 | `len(earned) <= 2` is satisfied by **zero**. It passed with the artifact set emptied entirely. |
| TRC-F4 | Two runs that both produce nothing compare equal, so it reported determinism from an empty result. |
| TRC-F3 | It asserted a fired rule's **log line** contained the word "artifact" - which survived the artifacts never being composed. |

All three now assert the thing itself. Re-mutated with each scenario broken at
its own subject: **13 of 13 caught**.

A fourth was found the same day by hand rather than by mutation: TRC-E1's word
filter was singular-only, so `\bartifact\b` never matched "artifacts". It read a
tree containing real offenders and reported clean. Found by grepping the tree
directly and getting a different answer from the test - which is the check on a
check that mutation alone would not have given, because the mutation planted a
singular noun.

### Two defects found by reading the page this issue generates

Neither came from a test. Both came from opening the review page for this issue
and reading it as a reviewer would.

**It listed seven documents as `draft` when three had never been written.**
`draft` is the status routing seeds and nothing moved it, so the page sent a
reviewer looking for files that are not there. Worse than no page: a page that
is confidently wrong. The resolver already knew the difference; the page was not
asking it. TRC-C6.

**Three of the five statuses were unreachable.** `omitted`, `awaiting-approval`
and `approved` had no way to be set, so "Decision required" and "Deliberately
omitted" could never say anything - two of the page's three sections, permanently
empty, while TRC-A2 and TRC-C3 tested behaviour the framework could not produce.
That is the same error revision 3 of the delivery approach corrected: shipping a
record with nothing that writes it. `compass issue artifact` closes it, and this
issue's own page is the first thing to use it. TRC-C7.

### A third: the policy named documents that do not exist

The first version of the artifact declarations invented six document kinds -
`change-brief`, `design-note`, `hld`, `work-plan`, `test-strategy`,
`spike-question` - none of which has a template or a stage that writes it. The
page would have told a reviewer to produce documents the framework cannot
produce. The policy now names only the kinds that exist today: `design` and
`distribution-map` rather than their not-yet-renamed v2 spellings, and the
express pack is the two light documents G1 and G2 already require rather than an
invented brief. `RP-REQUIRE-007` was dropped for the same reason - nothing in the
framework or its frozen vocabulary knows what a `test-strategy` is.

## 3. Review dimensions

| Dimension | Applies? | Result | Assessed by | Evidence |
|---|---|---|---|---|
| correctness | always | PASS | author | all 20 scenarios in §1 pass; EV-SUITE and the green records |
| governance | always | PASS | author | EV-CHECK-2: 14 checks passed. The new check joined G4 rather than becoming a sixth guardrail (ADR-002), and is declared in the freeze baseline with the change that introduced it. `guardrails.yml` moved to 1.11.0. |
| traceability | always | PASS | author | 23 changed files each traced to the scenarios that drove them; `changed-code-traces-to-scenario` passes in EV-CHECK-2 |
| regression | yes | PASS | author | 1283 passed, 7 skipped - up from 1268, nothing previously passing now fails. `evidence/full-suite.txt` |
| security | scaled | PASS | author | No auth, money, personal data or network surface. The one new file-writing path (`compass issue dashboard`) writes a single README inside the issue directory and reads only the spine. |
| clarity | yes | PASS | author | The whole issue is a clarity change. Its own output is the check: the review page went from a directory listing to seven named documents each carrying why it exists. Weakest dimension here - author-assessed, no mechanical backstop, and the author is the person who found "initiative earns it (prd)" readable for an hour. |
| claims | immovable | n/a - empty | author | No marketer in play and no public claim made. An empty claim set, which is not the same as a claim review that passed. |
| fitness | policy (RP-REQUIRE-003) | PASS - **checked nothing** | mechanism | `command-passes` reports: "this project declares no guardrail that runs a command, so there was nothing to check and this passed without checking anything." Recorded at triage as an expected empty pass, and it was. |

## 4. Gate decision

| Gate | Required by | Status |
|---|---|---|
| verify.correctness | immovable + approach | GREEN |
| verify.governance | immovable + approach | GREEN |
| verify.traceability | approach | GREEN |
| verify.regression | immovable | GREEN |
| verify.security | approach | GREEN |
| verify.clarity | approach | GREEN |
| verify.claims | immovable | GREEN (empty claim set) |
| verify.fitness | policy | GREEN (cleared on a check that ran nothing) |

**Overall:** PASS - advance to ship.

---

## Found and filed, not fixed here

`compass changed-file add --scenario` accepts a scenario id that does not exist
in the issue and writes it into the spine. `compass tdd-red --scenario` validates
the same argument and refuses. Hit while recording §3's traceability: a shell
quoting mistake put six ids into one string and the command reported success. It
surfaced only at the gate. Filed as `scenario-ids-unvalidated-on-trace`; not
fixed here, because it is a different defect in a different verb.

## Gate

- [x] Every required review dimension passed with evidence attached.
- [x] Every gate in `delivery-approach.md` and every immovable gate is GREEN.
- [x] This report is complete - no empty evidence blocks.

### Definition of Done

- [x] **Every scenario passes** - §1 is all PASS; the spec, read as the
      acceptance suite, is green. Evidence: the green records in §2.
- [x] **TDD suite green** - §2 links the record: 1283 passed, 7 skipped.
- [ ] (evidence: EV-CHECK-2) **Coverage meets the tested-before-ship guardrail's
      floor** - this repository declares no floor, so there is nothing to meet.
      `compass check` is the record of that, and this item is deliberately not
      ticked: a tick would claim a measurement nobody took.
- [x] **No lint / format / type errors** - the suite includes the house-style
      and terminology guards; `evidence/full-suite.txt`.
- [ ] (evidence: EV-CHECK-2) **Traceability intact** - code → scenario → intent
      holds across 23 changed files; no marketer, so no claim chain.
- [x] *(carried to ship)* Living docs updated to match reality - `README.md`,
      `docs/five-minutes.md` and `docs/quickstart.md` are updated in this change
      and their drift guards pass. Not a follow-up: re-deriving `system-spec.md`
      after landing is the standard post-land step every issue takes, not
      something this one owes.
- [x] **Every owed follow-up settled** - none owed by the approach, and the one
      defect found was filed as its own issue rather than carried.

Next stage: **ship** (`/compass:ship`).
