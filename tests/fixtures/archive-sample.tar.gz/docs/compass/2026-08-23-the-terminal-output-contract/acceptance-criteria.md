# Spec - the-terminal-output-contract

> **Phase:** define · **Last updated:** 2026-08-23 · **Owning agent:** spec-author
> **Familiarity:** existing behaviour measured first, then new scenarios

## Summary

**Goal:** A person running a Compass command gets an answer they can act on in
one screen, instead of a transcript addressed to the agent that produced the
work.

**Approach:** Two output kinds, not one rule for everything. A **hand-off** -
any verb that ends a stage or renders a verdict - fits in twelve lines and says
what was decided, what to read, and what reply is wanted. A **report** - a verb
someone runs deliberately *to get detail*, like `calibration` or `terminology` -
keeps its detail, but must open with a summary of five lines or fewer so a
reader can stop there. Five flags select the mode: `--quiet`, `--summary`
(the default), `--verbose`, `--json`, and `--evidence-out PATH`. A shared
formatter owns the shape so 34 verbs do not each invent one.

**Why now / what changes:** Today `compass check` spends 45 lines - 14 of them
`PASS` lines nobody asked for - to tell you 4 things failed, and
`compass approach evaluate` prints a raw Python dict at a human. After this,
`check` opens with the verdict and the failures, the passes move to
`--verbose`, and nothing that a person needs in order to decide is more than a
screen away. What a reader will notice: the answer is at the top, and the
identifiers are still there with their meanings attached.

---

## How each role reads this file

- **Product owner / manager** - reads for *intent fidelity*: do these scenarios deliver the outcome in `prd.md`?
- **Product marketer** - reads for *claims*: every line of launch copy must point at a scenario id here.
- **Engineer** - reads for *tests*: scenarios are the acceptance suite and seed the TDD red→green cycle.
- **QA** - reads for *coverage*: which scenarios are exercised, which edges are not.
- **Designer** - UI behaviour authored in `ui-contract.md` flows in here as scenarios.

---

## Intent links

| Intent id | Source | Statement |
|---|---|---|
| INT-1 | the issue's bug report, quoting the proposal | Default output for a completed stage fits in roughly twelve lines and contains no raw command output. |
| INT-2 | the same | The terminal is a notification surface, not the artifact - raw evidence is linked and stored, never pasted. |
| INT-3 | the same | Five modes select how much a reader gets: quiet, summary, verbose, json, evidence-out. |
| INT-4 | ADR-017, an accepted architecture decision | An identifier is a key, not jargon - attach its meaning, never delete the id. |
| INT-5 | triage question 1, `delivery-approach.md` §4c | A verb whose purpose is detail is not improved by being cut to twelve lines. |

---

## What the numbers are, so no scenario has to guess

Measured at HEAD on 2026-08-23, and quoted here because three scenarios below
are stated as thresholds and a threshold with no measurement behind it is a
guess with a number on it.

| | Today |
|---|---|
| `compass check` on a triaged issue | 45 lines, 14 of them PASS lines |
| `compass flow` | 156 lines |
| `compass approach evaluate` | 4 lines, one of which is a raw Python dict |
| print calls inside verb bodies | 208, across 34 verbs |
| verbs holding more than half of them | 5 (`calibration` 38, `route_evaluate` 23, `check` 20, `flow` 18, `terminology` 17) |

---

## Scenario group A - the hand-off contract

**Independence note:** Separable. This group is the shared formatter and the
verbs that end a stage; group C's flags are the mode selector that sits above
it, and group B is a different output kind.

### Scenario: a stage hand-off fits on one screen
<!-- traceability id: TRC-A1 · serves: INT-1 -->

Twelve lines is the proposal's number and it is kept, because it is the point
at which a reader stops scrolling rather than an arbitrary budget.

```gherkin
Scenario: a stage hand-off fits on one screen
  Given a verb that ends a stage or renders a verdict
  When it is run in the default mode and succeeds
  Then its output is at most twelve lines
  And no line is raw command output, a stack trace, or a pasted file
```

### Scenario: the hand-off says what was decided and what to read
<!-- traceability id: TRC-A2 · serves: INT-1 -->

Twelve lines of the wrong twelve things is not an improvement. This is the
positive half: the budget is a ceiling, and these are the contents.

```gherkin
Scenario: the hand-off says what was decided and what to read
  Given a verb that hands a decision to a person
  When it is run in the default mode
  Then the first line states the outcome
  And the output names the one artifact to read
  And it names the reply that is wanted, or states that none is
```

### Scenario: a hand-off with nothing to decide is shorter, not padded
<!-- traceability id: TRC-A3 · serves: INT-1 -->

The common case. Most verbs are not a decision point, and a contract that only
describes the decision case leaves each verb to guess at the other one - which
is how this surface drifted in the first place.

```gherkin
Scenario: a hand-off with nothing to decide is shorter, not padded
  Given a verb that completed with no decision to hand to a person
  When it is run in the default mode
  Then its output is at most five lines
  And it says what changed and what the next action is
  And it does not invent a decision, a concern, or a reply prompt
```

### Scenario: at most three key choices and three concerns
<!-- traceability id: TRC-A4 · serves: INT-1 -->

```gherkin
Scenario: at most three key choices and three concerns
  Given a hand-off that has more than three key choices or more than three concerns
  When it is rendered in the default mode
  Then at most three of each appear
  And the output says how many were not shown and where to read them
```

The second Then is the whole scenario. A silent truncation reads as "there were
three", which is a claim the command did not check - and this repository has
already found four checks that cleared by not looking.

### Scenario: the budget cannot be met by making the lines longer
<!-- traceability id: TRC-A5 · serves: INT-1 -->

Added at the requirements review. `compass check`'s longest line today is **252
characters**, so joining its 45 lines into 12 would satisfy a line-count
assertion exactly and improve nothing. A budget counted only in lines is a check
that clears by reformatting.

```gherkin
Scenario: the budget cannot be met by making the lines longer
  Given a verb whose output is within its line budget
  When any line of it exceeds 100 characters
  Then the guard fails
```

### Scenario: the gate verdict keeps its guidance one flag away
<!-- traceability id: TRC-A6 · serves: INT-1 -->

Added at the requirements review, and the most visible change in the issue.
`compass check` reports a failure in four lines - what failed, why it matters,
how to fix it - which is why a failing check reads as support rather than
bureaucracy. Three failures is thirteen lines before the verdict, so the budget
and that format cannot both survive untouched. `why` is the part a reader can
fetch when they want it.

```gherkin
Scenario: the gate verdict keeps its guidance one flag away
  Given a check run with failures
  When it is run in the default mode
  Then the verdict is the first line
  And each shown failure states what failed and how to fix it
  And the reason it matters is available under --verbose rather than removed
  And the output says how many failures were not shown
```

---

## Scenario group B - the report contract

**Independence note:** Separable from A. These are the five heavy verbs, and
they share no code with the stage hand-offs.

### Scenario: a report opens with a summary a reader can stop at
<!-- traceability id: TRC-B1 · serves: INT-5 -->

The answer to triage question 1. `compass calibration` and `compass terminology`
exist to give detail; cutting them to twelve lines would remove the reason to
run them. So the rule for a report is different from the rule for a hand-off,
and stating that difference is what stops "twelve lines" being applied where it
does harm.

```gherkin
Scenario: a report opens with a summary a reader can stop at
  Given a verb whose purpose is to produce detail
  When it is run in the default mode
  Then the first five lines or fewer state the finding
  And the detail follows, in full, below the summary
  And the summary alone is enough to know whether the detail needs reading
```

### Scenario: a report's own detail is never truncated by the contract
<!-- traceability id: TRC-B2 · serves: INT-5 -->

Stated as a criterion so a later reading of "twelve lines" cannot quietly cost a
report its content.

```gherkin
Scenario: a report's own detail is never truncated by the contract
  Given a report with more findings than fit on a screen
  When it is run in the default mode
  Then every finding is printed
  And the twelve-line hand-off budget is not applied to it
```

---

## Scenario group C - the modes

**Independence note:** Separable. The flags are a parser change plus one
resolver; groups A and B consume the resolved mode rather than reading flags.

### Scenario: every verb accepts every mode flag
<!-- traceability id: TRC-C1 · serves: INT-3 -->

The failure this prevents: a flag that works on four verbs and is silently
ignored on the other thirty, which is worse than not having it.

```gherkin
Scenario: every verb accepts every mode flag
  Given the five mode flags: --quiet, --summary, --verbose, --json, --evidence-out
  When any verb is run with any one of them
  Then the flag is accepted rather than reported as unknown
  And the verb honours it rather than accepting and ignoring it
```

### Scenario: quiet prints nothing on success
<!-- traceability id: TRC-C2 · serves: INT-3 -->

The answer to triage question 3.

```gherkin
Scenario: quiet prints nothing on success
  Given a verb run with --quiet
  When it succeeds and has no decision to hand over
  Then it prints nothing
  And its exit code carries the result
  When it fails, or has a decision to hand over
  Then it prints that, and nothing else
```

### Scenario: json is the machine mode and carries no prose
<!-- traceability id: TRC-C3 · serves: INT-3 -->

```gherkin
Scenario: json is the machine mode and carries no prose
  Given a verb run with --json
  When it completes
  Then its entire output parses as one JSON document
  And no human-facing sentence is written to that stream
```

### Scenario: evidence-out writes the raw capture rather than printing it
<!-- traceability id: TRC-C4 · serves: INT-2 -->

```gherkin
Scenario: evidence-out writes the raw capture rather than printing it
  Given a verb run with --evidence-out PATH
  When it produces raw command output
  Then that output is written to PATH
  And the terminal shows the summary and a link to PATH, not the capture
```

### Scenario: verbose is where detail goes, not where the contract is escaped
<!-- traceability id: TRC-C5 · serves: INT-3 -->

```gherkin
Scenario: verbose is where detail goes, not where the contract is escaped
  Given a verb run with --verbose
  When it completes
  Then it prints the diagnostic detail the default mode omitted
  And the default mode still honours its own budget when run without the flag
```

### Scenario: every verb declares which contract it is under
<!-- traceability id: TRC-C6 · serves: INT-5 -->

Added at the requirements review. The spec has two contracts and had no rule for
assigning a verb to one. If that is a judgement made at each print site it will
be made 34 different ways and drift again within a release - the defect this
issue exists to fix, reintroduced by its own fix. A verb that declares nothing
fails, because a default is how the 35th verb quietly becomes whatever was
easiest.

```gherkin
Scenario: every verb declares which contract it is under
  Given the CLI's registered verbs
  When the suite runs
  Then each one declares itself a hand-off or a report, where it is registered
  And a verb that declares neither fails, rather than defaulting to one
```

### Scenario: evidence-out on a verb with nothing to capture
<!-- traceability id: TRC-C7 · serves: INT-2 -->

Added at the requirements review, resolving a contradiction: TRC-C1 says every
verb honours every flag, and TRC-C4 defines this one only for verbs producing
raw output - which most do not. Not an error, because a script passing the flag
uniformly across a pipeline should not break on the verbs that have nothing to
say.

```gherkin
Scenario: evidence-out on a verb with nothing to capture
  Given a verb that produces no raw command output
  When it is run with --evidence-out PATH
  Then it writes no file
  And it says in one line that there was nothing to capture
  And under --quiet it says nothing at all
```

---

## Scenario group D - what compression must not cost

**Independence note:** Not separable - these constrain groups A, B and C rather
than adding surface. They are listed apart because they are the regressions this
change is most likely to cause.

### Scenario: an identifier survives compression with its meaning attached
<!-- traceability id: TRC-D1 · serves: INT-4 -->

ADR-017, and the reason it is a scenario rather than a note: a twelve-line
budget creates constant pressure to drop `(RP-FLOOR-001, floor)` from a line to
save room, and that is exactly the deletion the decision forbids. Compression
removes whole lines. It never strips the id from a line it keeps.

```gherkin
Scenario: an identifier survives compression with its meaning attached
  Given output that names a rule, guardrail, check or gate by its id
  When it is compressed to fit the default mode
  Then every line that remains still carries both the id and its meaning
  And no line is kept with the meaning removed to save room
  And no line is kept with the id removed to save room
```

### Scenario: the meaning still comes before the code
<!-- traceability id: TRC-D2 · serves: INT-4 -->

`tests/test_plain_language.py` already enforces this, and
`evaluator-prints-code-before-meaning` was closed on the strength of it. Named
here so a reshaping of these exact lines cannot quietly revert it.

```gherkin
Scenario: the meaning still comes before the code
  Given a line reporting a fired policy rule
  When it is rendered in any mode
  Then the meaning is stated before the identifier
```

### Scenario: retired vocabulary stays out of printed strings
<!-- traceability id: TRC-D3 · serves: INT-4 -->

```gherkin
Scenario: retired vocabulary stays out of printed strings
  Given the printed strings of every verb after the rewrite
  When they are scanned for retired stage names
  Then none appears
```

### Scenario: an expected string is updated only when the test's intent still holds
<!-- traceability id: TRC-D4 · serves: INT-1 -->

Added at the requirements review, from a measurement the spec had not made: **37
test files assert a literal string in stdout, 130 assertions in all.** The
obvious way to land this change is to run the suite, see 130 failures, and edit
each expected string to match the new output. That proves nothing - every
assertion would pass by construction, and any behaviour genuinely lost would be
papered over in the same motion.

```gherkin
Scenario: an expected string is updated only when the test's intent still holds
  Given a test asserting on a verb's output, and that verb moved to the contract
  When the assertion no longer matches
  Then the change records whether the test's intent still holds or the new
       output is wrong
  And a verb is moved to the contract on its own, so a failure names one verb
```

---

## Failure-mode scenarios

### Scenario: a verb prints past its budget and the guard says which one
<!-- traceability id: TRC-E1 · serves: INT-1 -->

The guard on the guard. A budget check that reports "some verb was too long" is
not actionable, and this repository has learned that an unactionable failure
gets suppressed rather than fixed.

```gherkin
Scenario: a verb prints past its budget and the guard says which one
  Given a verb whose default output exceeds its budget
  When the suite runs
  Then it fails, naming the verb, its line count, and its budget
```

### Scenario: the budget guard fails when the budget is breached
<!-- traceability id: TRC-E2 · serves: INT-1 -->

Stated as a criterion because a line-count assertion is the easiest kind of
check to write so that it cannot fail - a budget of `<= 1000` passes everything,
and an empty verb list passes by having nothing to check.

```gherkin
Scenario: the budget guard fails when the budget is breached
  Given the budget guard and a verb deliberately made to print one line too many
  When the guard runs
  Then it fails
  And when the verb list it reads is empty, it reports nothing to check rather
      than passing
```
