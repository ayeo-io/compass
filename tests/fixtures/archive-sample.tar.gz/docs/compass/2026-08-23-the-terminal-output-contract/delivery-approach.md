# Delivery approach - the-terminal-output-contract

> **Issue:** The terminal reports to the agent that produced the work, not to
> the person approving it. Give the output a contract.
> **Triaged:** 2026-08-23 by jed72 · **Revision:** 1
> **Reference shape:** initiative

---

## 1. The assessment

| Dimension | Value | Justification |
|---|---|---|
| **Risk** | cross-cutting | It changes the shared output surface of every verb and adds global flags to the parser, so a mistake shows up in commands the change never touched. Two existing guards already constrain this surface and must keep passing. Not `critical` - no data loss, no auth, no money, and a clean revert. |
| **Familiarity** | brownfield-mapped | The code is mapped, and mapped by measurement rather than by memory - see §2. What is *not* written down is what each verb's output is supposed to say, but that is the thing this issue creates, and an unwritten target is what the define stage is for, not a gap in familiarity. |
| **Size** | large | 208 print calls inside verb bodies across 34 verbs, plus five global flags that every one of them has to honour. |
| **Goal & role** | delivery · engineer | |

**Labels:** `cli`, `public-api`, `docs`. `docs` is new since the issue was
filed: five new flags are public surface and the CLI blocks in `README.md` and
`docs/five-minutes.md` have a drift guard that will fail without them.

**Urgency:** none.

---

## 2. The reach, measured at HEAD rather than quoted

The bug report says "24 CLI verbs and 247 print sites", measured on 2026-08-23
before three issues landed. Re-measured now:

| | Filed | At HEAD |
|---|---|---|
| print calls in the CLI package | 247 | **253** |
| of those, directly in a verb body | not counted | **208** |
| verbs (`cmd_*` functions) | 24 | **34** |

The 45 print calls that are *not* in a verb body sit in helpers, which is where
a shared formatter would go - they are the change's natural home rather than 45
more sites to edit.

**The distribution matters more than the total.** Five verbs hold more than half
of it:

| Verb | Print calls |
|---|---|
| `cmd_calibration` | 38 |
| `cmd_route_evaluate` | 23 |
| `cmd_check` | 20 |
| `cmd_flow` | 18 |
| `cmd_terminology` | 17 |
| *(remaining 29 verbs)* | 92 |

So this is not 208 evenly-spread edits. It is a handful of heavy reports and a
long tail of verbs printing two or three lines each, and those two groups want
different treatment - see §4c.

---

## 3. Policy rules that fired

- Policy file: `governance/routing-policy.yml`, version 2.3.0.

| Kind | Triggered by | Effect | Rationale, quoted |
|---|---|---|---|
| shape | large + cross-cutting | candidate **initiative** | "Large work - full weight, plausibly parallel" (`RP-SHAPE-004`) |
| requirement | risk = cross-cutting | gate `verify.fitness` added | "Architectural fitness checked before cross-cutting or critical changes land" (`RP-REQUIRE-003`) |

**Advisory strategy:** `regression-baseline` (`RP-ADV-001`). Capture the suite
green before the change and re-run after. Worth honouring literally here: the
suite is the only thing that will catch a verb whose output this change breaks
in passing.

---

## 4. The delivery approach

**initiative.** Every stage full weight. Eight gates: correctness, governance,
traceability, regression, security, clarity, claims, **fitness**.

### 4a. Per-stage weight

| Stage | Weight | Why |
|---|---|---|
| Define acceptance criteria | full | The contract is the deliverable. If the twelve-line rule is not stated as checkable criteria, this becomes a taste exercise across 208 sites. |
| Requirements review | full | §4c names three questions that need deciding rather than correcting. |
| Design | full | Where the shared formatter lives, and how five flags reach 34 verbs without every verb parsing them, is a real architectural choice. |
| Break down the work | full | The distribution map records whether the heavy reports and the long tail are genuinely separable. |
| Implement | full | Test surface scaled to cross-cutting risk. |
| Test and review | full - 8 gates | 4b. |
| Ship | full | |

### 4b. Gate set

Eight. Two notes, recorded now so the verification report states them rather
than a reader assuming they exercised something:

- **`verify.fitness` will clear on a check that runs nothing**, because this
  repository declares no project guardrail that runs a command. Same as the last
  three issues.
- **`verify.claims` records an empty claim set**, there being no marketer. That
  is different from a claim review that passed.

### 4c. The questions this issue has to answer

Named now so the requirements review argues them rather than the implementation
discovering them.

1. **Does the twelve-line rule apply to a diagnostic?** The proposal's rule is
   for "a completed stage". `compass calibration` and `compass terminology` are
   reports a person runs deliberately *to get detail* - compressing them to
   twelve lines would remove the reason to run them. Either the contract is
   scoped to stage hand-offs, or `--verbose` becomes the default for that group,
   and those are different answers with different blast radii.

2. **ADR-017 constrains the compression, and it is easy to breach by accident.**
   "An identifier is a key, not jargon - attach its meaning, never delete the
   id." A twelve-line budget creates constant pressure to drop
   `(RP-FLOOR-001, floor)` from a line to save room. That is exactly the
   deletion ADR-017 forbids, and `tests/test_plain_language.py` is the guard
   that would catch it. The contract has to say how an id survives compression.

3. **What does `--quiet` do when there is nothing to hand off?** Most verbs are
   not a decision point. "Errors and the decision hand-off only" leaves the
   common case unstated, and an unstated case in a mode flag becomes each
   verb's own guess - which is how the surface drifted in the first place.

### 4d. Topology

Policy sets no ceiling. This repository runs solo by standing decision, so the
distribution map records that as cap-free rather than as a de-scope.

---

## 5. The de-scope ledger

**Empty.** An initiative de-scopes nothing.

---

## 6. What must not be undone

Two guards already constrain this surface. A rewrite that breaks either is a
regression, not a trade-off:

- `tests/test_plain_language.py` - a fired-rule line states the meaning before
  the code. `evaluator-prints-code-before-meaning` is closed on the strength of
  it.
- `tests/test_printed_output_vocabulary.py` - retired stage names are banned in
  printed strings.

---

## 7. Owed follow-ups

None owed by the approach.

**Dependency, now settled:** the contract's `Start:` line points at the
per-issue `README.md`, which did not exist when this was filed. It landed on
2026-08-23 in `the-human-front-door` (PR #76), so nothing blocks this issue.

---

## 8. Recorded decisions

| What was decided | Choice | Who | Why |
|---|---|---|---|
| `docs` added to the labels | added | jed72 | Five new flags are public surface, and the CLI blocks in README and five-minutes have a drift guard that fails without them. |
| Familiarity | brownfield-mapped, not unmapped | jed72 | The unwritten thing is the target contract, which the define stage produces. The existing code was mapped by measurement in minutes. |
| Risk | cross-cutting, not critical | jed72 | It reaches every verb, but loses no data, touches no auth or money, and reverts cleanly. |

No override of a computed value.

---

## 9. Confirmation

- [x] Every dimension carries a justification.
- [x] De-scope ledger empty, as an initiative requires.
- [x] Approach presented to the invoker and confirmed, 2026-08-23.
