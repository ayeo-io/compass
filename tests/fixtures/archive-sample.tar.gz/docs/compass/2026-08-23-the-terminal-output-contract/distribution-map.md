# Distribution map - the-terminal-output-contract

> **Phase:** design · **Written:** 2026-08-23
> **Topology:** solo. Four streams were available; none is used.

## The streams that exist

| Stream | Work unit | Scenarios | Files it would own |
|---|---|---|---|
| S1 | U1 - the emitter, the flags, the guards | TRC-A5, C1, C2, C3, C5, C6, C7, E1, E2 | `cli/compass_pkg/terminal.py` (new), `cli/compass`, `tests/test_terminal_output_contract.py` (new) |
| S2 | U2 - `compass check` | TRC-A1, A2, A4, A6, D1, D2 | `cli/compass_pkg/check_cmd.py`, its tests |
| S3 | U3 - the four heavy reports | TRC-B1, B2 | `calibration.py` (the `retro` verb), `flow.py`, `terminology_cmd.py`, `analyze.py`, their tests |
| S4 | U4 - the long tail, 29 verbs | TRC-A3, C4, D3 | the remaining modules, their tests |

## Why they are independent - and where they are not

S2, S3 and S4 own **disjoint verbs and disjoint test files**, so they cannot
collide on content. Two shared edges are real and worth naming rather than
discovering:

1. **Every stream adds a line to the same declaration site.** Each verb's
   `output_kind` is declared where its parser is registered, and all 47
   registrations live in one file, `cli/compass`. Three streams editing three
   different regions of one file is a merge conflict waiting to happen - a
   textual one, not a logical one, which is the annoying kind.
2. **S1 is a hard dependency for the other three.** There is nothing to call
   until the emitter exists.

## Why it runs solo anyway

This repository does not use worktrees, by standing decision. The map records
the available parallelism so a reader can see it was considered; it is not a
de-scope, and the same four units run in sequence.

**The order is fixed by the dependency, not by preference:** S1, then S2, S3, S4
in any order. The design's PR table follows it.

## Stream count

Policy set no ceiling (`stream_ceiling: null`). The map's answer is **1** -
the standing solo constraint - with 4 recorded as what the work would support.
