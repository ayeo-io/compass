# Requirements review - the-terminal-output-contract

> **Phase:** refine · **Reviewed:** 2026-08-23 · **Reviewer:** jed72 (author)
> **Spec under review:** `acceptance-criteria.md`, 16 scenarios in five groups.

The define stage ran its own four scans - placeholders, orphan intents,
untestable Thens, ambiguous quantifiers - and this review does not repeat them.
Nothing was outstanding. What follows is the set the author could not close
alone: two contradictions, one gap that changes the shape of the work, and four
decisions.

---

## The ambiguity ledger

### AMB-1 - The spec has two contracts and no rule for assigning a verb to one

**What was unclear.** Group A binds a "hand-off" to twelve lines; group B binds
a "report" to a five-line summary and unlimited detail. Nothing says which of the
34 verbs is which, and nothing says how the 35th will know.

**Why it matters.** If the classification is a judgement made at each print
site, it will be made 34 different ways and drift again within a release - which
is the defect this issue exists to fix, reintroduced by its own fix.

**Resolved:** the kind is **declared data, not a judgement**. Each verb declares
`kind="hand-off"` or `kind="report"` where its parser is registered, in one
place a reader can scan. A verb that declares neither fails the suite rather
than defaulting, because a default is how the 35th verb quietly becomes whatever
was easiest.

**Decided by:** jed72. **Changes what gets built:** yes - it adds a
declaration to every verb's registration and a guard that every verb has one.
A scenario was added: **TRC-C6**.

---

### AMB-2 - "Twelve lines" can be met by making the lines longer

**What was unclear.** A budget counted in lines says nothing about their width.

**Why it matters, measured rather than argued.** `compass check`'s longest line
today is **252 characters**. Joining its 45 lines into 12 would satisfy a
line-count assertion exactly and improve nothing - a check that clears by
reformatting is a check that cannot fail, and this repository found four of
those in one release.

**Resolved:** the budget counts printed newlines, **and** no line exceeds 100
characters. Both, or the first is decoration. A scenario was added: **TRC-A5**.

**Decided by:** jed72. **Changes what gets built:** yes - it makes the
252-character guidance lines a thing that must be reflowed, not just moved.

---

### AMB-3 - `compass check` cannot fit twelve lines and keep what makes it good

**What was unclear.** `check` is a verdict, so group A binds it to twelve lines.
Its failure format is four lines each - the failure, then `why` it matters, then
how to `fix` it. Three failures is already thirteen lines before the verdict.

**Why it matters.** That format is not padding. It is the reason a failing check
reads as support rather than bureaucracy, and it was built deliberately. A
twelve-line rule applied naively deletes the best thing about the command.

**Resolved:** the default shows the verdict, then **`what` and `fix`** for at
most three failures, then a line saying how many were not shown. `why` moves to
`--verbose`. Eleven lines for the common case, and the guidance is one flag
away rather than gone. `--verbose` keeps today's full format unchanged.

**Rejected alternative:** reclassifying `check` as a report. It is the gate
verdict - the single most important hand-off in the pipeline - and exempting it
would mean the contract does not apply where it matters most.

**Decided by:** jed72. **Changes what gets built:** yes, and it is the
most visible change in the issue. A scenario was added: **TRC-A6**.

---

### AMB-4 - `--evidence-out` on a verb that captures nothing

**What was unclear.** TRC-C1 says every verb honours every flag. TRC-C4 defines
`--evidence-out` only for verbs that produce raw command output. Most do not.
The two scenarios contradict each other for about thirty verbs.

**Resolved:** `--evidence-out` is accepted everywhere and, on a verb with
nothing to capture, writes no file and says so in one line - suppressed under
`--quiet` like any other success line. **Not an error**, because a script that
passes the flag uniformly across a pipeline should not break on the verbs that
happen to have nothing to say. TRC-C4's wording was scoped to "a verb that
produces raw command output" and **TRC-C7** was added for the other case.

**Decided by:** jed72. **Changes what gets built:** marginally - one
branch, but it removes an inconsistency that would otherwise be discovered
thirty times.

---

### AMB-5 - `--json` already exists, so TRC-C3 is partly a compatibility rule

**What was unclear.** The spec reads as though `--json` is new. It is not:
`compass approach evaluate --json` ships today and emits valid JSON.

**Why it matters.** ADR-006 makes backward compatibility non-negotiable within a
major version. An existing flag's output shape is public surface, so this is not
a free hand.

**Resolved:** `approach evaluate --json` keeps its current keys. New keys may be
added; none is renamed or removed in this change. Extending `--json` to the
other verbs is new surface and unconstrained. Recorded rather than assumed,
because "make every verb emit JSON" reads like permission to redesign the one
that already does.

**Decided by:** jed72. **Changes what gets built:** it constrains it -
one verb's output is now fixed rather than open.

---

### AMB-6 - The gap: 37 test files assert on the strings this change rewrites

**What was unclear - and this is a gap, not an ambiguity.** No scenario says
what happens to the existing suite. Measured:

| | Count |
|---|---|
| test files touching CLI output at all | 108 of 157 |
| test files asserting a literal string in stdout | **37** |
| such assertions | **130** |

**Why it matters.** The obvious way to land this change is to run the suite, see
130 failures, and update each expected string to match the new output. That
would be a rewrite which proves nothing: every assertion would pass by
construction, and any behaviour genuinely lost would be papered over in the same
motion. It is the largest risk in the issue and the spec did not mention it.

**Resolved:** two rules, and they are binding on the design.

1. **Per-verb, not big-bang.** Verbs move to the contract one at a time, so a
   failure always names a single verb's change.
2. **An expected string may only be updated when the test's *intent* still
   holds.** If a test asserted that output contained something a reader needed,
   and the new output does not have it, the finding is that the new output is
   wrong - not that the test is stale. Each updated assertion carries a one-line
   note saying which of the two it was.

A scenario was added: **TRC-D4**.

**Decided by:** jed72. **Changes what gets built:** yes - it rules out
the fastest way to do the work, deliberately.

---

### AMB-7 - Is the budget guard a `compass check` check or a test?

**What was unclear.** TRC-E1 and TRC-E2 describe a guard that fails when a verb
prints past its budget. Nothing says where it lives.

**Resolved:** a **pytest test**, not a `compass check` check. The distinction is
in ADR-002 and it is about audience: `compass check` runs against one issue's
spine and evidence and speaks to the person shipping that issue. A verb printing
too much is a property of this repository's source, like the line caps and the
house-style guard, and it belongs with them. Adding it as a `CHECK_FN` would
also make it fire on every adopter project, where it would check their verbs
against our budget.

**Decided by:** jed72. **Changes what gets built:** it settles where,
not what.

---

## Governance QA

| Guardrail | Held? | How |
|---|---|---|
| G1 - tested before it lands | yes | Every scenario has a test in `task.yml`; the budget guard is itself mutation-proved by TRC-E2. |
| G2 - acceptance before code | yes | 21 scenarios written before any implementation. |
| G3 - traceability | yes | Every scenario traces to one of five intents; the four new scenarios trace too. |
| G4 - evidence, not assertion | yes, and it is the subject | TRC-C4 and TRC-C7 make raw capture a written record rather than a paste, which is the guardrail applied to the terminal itself. |
| G5 - human signs off on the irreversible | not applicable | No data loss, money, auth or privacy surface. |

**Strategies.** S10, a guard is accepted on a failure: TRC-E2 exists for exactly
that and is written to catch the two ways a line-count check passes without
looking - a budget so high nothing breaches it, and an empty verb list.
S11, measure before arguing: AMB-2, AMB-3 and AMB-6 are all resolved on numbers
taken from the tree rather than on an opinion about how long output feels.

**ADR-017 is the binding architectural constraint** and TRC-D1 carries it.
**ADR-006** constrains `--json` as recorded in AMB-5. **ADR-002** settles AMB-7.

---

## Does the delivery approach still fit?

Yes, and more firmly than at triage. AMB-6 found a coupling - 37 test files,
130 assertions - that was not in the assessment and makes the work larger rather
than smaller, and `large` was already the top of the scale. Nothing found here
argues for less process. **No re-assessment.**

The one thing the design stage must now carry that triage did not anticipate:
the per-verb sequencing rule from AMB-6.

---

## Scenarios added by this review

| Id | Why it was added |
|---|---|
| TRC-A5 | AMB-2 - the width bound, without which the line budget can be met by reformatting |
| TRC-A6 | AMB-3 - what `compass check` shows by default and what moves to `--verbose` |
| TRC-C6 | AMB-1 - every verb declares its output kind, and one that declares neither fails |
| TRC-C7 | AMB-4 - `--evidence-out` on a verb with nothing to capture |
| TRC-D4 | AMB-6 - an expected string may only be updated when the test's intent still holds |

---

### Definition of Ready

- [x] **Summary is filled** - Goal, Approach and Why now are written prose, not
      placeholders.
- [x] **Problem traces up** - no `prd.md` (recorded as a deliberate omission at
      triage); every scenario traces to one of the five intents drawn from the
      bug report and ADR-017.
- [x] **Behaviour is Given/When/Then** - every scenario has an observable Then.
      The two that assert an absence (TRC-D1, TRC-E2) say what must still be
      present, so neither can pass by producing nothing.
- [x] **Traceability ids assigned** - 21 scenarios, TRC-A1 to TRC-E2.
- [x] **Affected surface named** - 208 print calls in 34 verbs, five of which
      hold 116 of them; 37 test files with 130 output assertions. Counted in
      `delivery-approach.md` §2 and AMB-6.
- [x] **No open questions** - seven findings, all resolved above with a decision
      and a decider. None deferred.
- [x] **Route still fits** - initiative, unchanged. AMB-6 makes the work larger,
      not smaller.

Next stage: **design** (`/compass:design`).
