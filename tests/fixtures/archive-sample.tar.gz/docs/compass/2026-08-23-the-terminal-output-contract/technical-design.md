# Design - the-terminal-output-contract

> **Phase:** design · **Written:** 2026-08-23 · **Owning agent:** planner
> **Built on:** `acceptance-criteria.md` (21 scenarios) and
> `requirements-review.md` (seven findings, all resolved).

## The shape in one paragraph

A new module, `cli/compass_pkg/terminal.py`, owns every line a person reads. A
verb stops calling `print()` and calls one of two functions - `hand_off(...)` or
`report(...)` - passing the *pieces* of what it wants to say rather than
pre-formatted text. The module decides how those pieces render in the mode the
user asked for. Five flags are attached to every verb by walking the parser tree
once, rather than being written out 47 times. Verbs convert one at a time.

---

## D1 - Verbs hand the emitter pieces, not strings

**Chosen.** A verb builds a small structure and passes it:

```python
hand_off(outcome="4 checks failed",
         read="verification-report.md",
         items=[...], concerns=[...], reply=None)
```

**Rejected: verbs keep printing and the emitter wraps stdout.** A filter that
counts lines after the fact cannot re-order, cap at three, or move a line to
`--verbose` - it can only truncate, and truncation is precisely what TRC-A4
forbids doing silently. It would also make `--json` impossible: you cannot
recover structure from prose you have already flattened.

**Rejected: each verb returns a result object and `main()` renders it.** Cleaner
in the abstract, but it changes 34 function signatures at once, which is the
big-bang the requirements review ruled out (AMB-6). A function call converts one
verb at a time and leaves the other 33 working.

**Cost, stated plainly:** two ways of printing coexist until the last verb
converts. The guard in D6 is what stops that being permanent.

---

## D2 - Five flags are attached by walking the parser tree

**Chosen.** After the parser is built, walk it recursively and add the five
flags to every leaf parser.

**Rejected: `parents=[global_flags]` on each `add_parser` call.** 47 edits, and
the 48th verb is added without them. This is the same failure the requirements
review identified for the hand-off/report declaration: anything a person must
remember to repeat is a thing that will eventually not be repeated.

**Rejected: flags before the verb (`compass --quiet check`).** Nobody types that.
`compass check --quiet` is what a person expects, and an interface that is
correct but unexpected is a worse interface.

**Why this is not a guard that cannot fail.** The tree has **13 nested subparser
groups** (`issue`, `bdd`, `gate`, `evidence`, `adr` and eight more) under 47
`add_parser` calls. A walk that fails to recurse reaches the top level and
silently misses everything nested. TRC-C1 asserts every leaf accepts every flag,
and a non-recursive walk fails it - so the guard has a real way to break.

---

## D3 - The output kind is declared beside `func=`

**Chosen.** `set_defaults(func=..., output_kind="hand-off")`, and a guard walks
the same tree asserting every leaf declares one.

**Rejected: infer the kind from the verb name or module.** Inference is a rule
nobody can read at the call site, and it gets the next verb wrong.

**Rejected: default to hand-off when undeclared.** A default is how the 35th
verb quietly becomes whatever was easiest - the requirements review's words, and
the reason TRC-C6 requires a failure rather than a fallback.

---

## D4 - The budget is enforced twice, on purpose

**Chosen.** The emitter renders **within** budget by construction: it caps lists
at three and appends the "and N more" line itself, so a verb cannot forget it.
The pytest guard then runs real invocations and counts what actually reached the
terminal.

**Why both.** The emitter alone would be trusted without being checked - and a
verb that still uses `print()` bypasses it entirely, which is the whole
transition period. The test alone would catch breaches only where somebody
remembered to write a case.

**The width bound goes in the same place.** 100 characters, enforced by the same
guard, because a line budget alone is met by joining lines - measured, not
supposed: `compass check`'s longest line today is **252 characters**.

---

## D5 - `compass check` renders what and fix; why moves to verbose

**Chosen**, per AMB-3. Verdict first, then `what` and `fix` for at most three
failures, then a count of what was not shown.

**Rejected: reclassify `check` as a report.** It is the gate verdict, the most
important hand-off in the pipeline. Exempting it would mean the contract does
not apply where it matters most.

**Rejected: drop `fix` and keep `why`.** `fix` is what a person acts on; `why`
is what convinces them it was worth acting on. When only one fits, keep the one
that changes what they do next.

---

## D6 - `print()` becomes an error in a converted module

**Chosen.** Once a module is converted, a guard forbids a bare `print()` in it.
The list of converted modules is explicit and grows as the work proceeds.

**Why.** D1's cost is two coexisting styles. Without a ratchet, a converted
module gets a new `print()` added a week later and quietly leaves the contract.
An explicit list makes each conversion a visible, reviewable step and makes the
end state ("every module is on the list") checkable.

**Rejected: ban `print()` everywhere at the end.** That defers all the risk to
the last step, which is the big-bang under another name.

---

## D7 - ADR-017 is enforced where compression happens

**Chosen.** The emitter never edits the inside of a line. It selects whole lines
and drops whole lines; it has no code path that strips an identifier or a
meaning from a line it keeps.

**Why it is a design decision and not a rule to remember.** "Do not delete the
id to save room" is exactly the kind of instruction that loses to a twelve-line
budget at 5pm. Making the emitter structurally incapable of editing line
interiors means the pressure has nowhere to act.

---

## Governance check

Run against `governance/guardrails.yml`, `governance/strategies.md`,
`governance/routing-policy.yml`. Structural validation:

```
compass policy lint: PASS - routing-policy.yml and guardrails.yml are
structurally valid.
```

| Guardrail | Verdict | How the design holds it |
|---|---|---|
| G1 tested before it lands | holds | Every one of the 21 scenarios has a test path in the spine; D4 makes the budget itself testable rather than a convention. |
| G2 acceptance before code | holds | The spec was written and hardened before this design. |
| G3 traceability | holds | Each work unit below names the scenarios it satisfies. |
| G4 evidence, not assertion | holds, and is the subject | `--evidence-out` (D1's `report`) writes raw capture to a file and links it, which is the guardrail turned on the terminal itself. |
| G5 human signs off on the irreversible | not applicable | No data loss, money, auth or privacy surface. |

**No guardrail is crossed, so no revision was needed.**

**Strategies.** S10 (a guard is accepted on a failure): D2 records exactly how
its guard can break, which is the question S10 asks. S11 (measure before
arguing): D4 and D5 are settled on counts from the tree - 252 characters, 45
lines, 130 assertions - not on how long output feels. **One departure recorded:**
S14 says correct every place at once, and D1 deliberately does not - the
requirements review ruled the all-at-once path out because it would rewrite 130
assertions in one motion and prove nothing. D6's ratchet is what replaces S14's
guarantee.

**ADRs.** ADR-017 is carried by D7. ADR-006 constrains `approach evaluate
--json` to its existing keys (AMB-5). ADR-002 keeps the budget guard a pytest
test rather than a `CHECK_FN` (AMB-7).

**No new ADR is proposed.** D1 to D7 are decisions within this issue's surface;
none changes a framework-wide invariant.

---

## Work units

| Unit | What | Scenarios | Depends on |
|---|---|---|---|
| **U1** | `terminal.py`, mode resolution, the parser walk, the `output_kind` declaration and its guard, the budget guard | TRC-C1, C2, C3, C5, C6, C7, A5, E1, E2 | - |
| **U2** | `compass check` converted - the gate verdict | TRC-A1, A2, A4, A6, D1, D2 | U1 |
| **U3** | The four other heavy verbs as reports: `retro`, `flow`, `terminology`, `analyze` | TRC-B1, B2 | U1 |
| **U4** | The long tail - 29 verbs, mostly two or three lines each | TRC-A3, C4, D3 | U1 |
| **U5** | Test migration, interleaved with U2-U4 rather than separate | TRC-D4 | per verb |

**Independence.** U2, U3 and U4 touch disjoint verbs and are genuinely parallel
once U1 exists. U5 is not a unit in its own right - it is a rule that binds each
of the others, and listing it separately would invite it being done last, in one
sweep, which is the thing AMB-6 forbids.

**U1 is a hard dependency, not a soft one.** Nothing else can start: there is no
emitter to call and no flag to honour.

---

## Sequencing, and what it means for shipping

This is **four pull requests, not one**, and that follows directly from AMB-6's
per-verb rule rather than from preference. Landing U1 through U4 in one branch
would present a reviewer with 130 changed assertions across 37 files and no way
to tell a deliberate change from an accident.

| PR | Unit | Rough size |
|---|---|---|
| 1 | U1 | one new module, the parser walk, three guards |
| 2 | U2 | one verb, its assertions |
| 3 | U3 | four verbs, their assertions |
| 4 | U4 | 29 verbs, mostly small |

**Stated so it is a decision rather than a surprise:** the issue is not done
until PR 4 lands, and `compass check` will report the issue incomplete until
then. Each PR is independently green and independently useful.

---

## Topology

Policy set no ceiling. U2, U3 and U4 could run as three parallel streams after
U1. This repository runs **solo** by standing decision - no worktrees - so the
distribution map records the parallelism as available but unused. That is a
standing constraint, not a de-scope of this issue.
