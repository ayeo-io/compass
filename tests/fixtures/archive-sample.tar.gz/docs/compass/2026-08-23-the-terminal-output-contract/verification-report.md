# Verification report - the-terminal-output-contract

> **Issue:** The terminal reported to the agent that produced the work, not to
> the person approving it. This gave the output a contract.
> **Delivery approach:** initiative - eight gates, every stage full weight,
> landed as four pull requests (#78, #79, #80, #81).
> **Verified:** 2026-08-24. **Assessed by:** author (jed72), with an
> independent fresh-eyes pass by three readers (S9) - see §5.

**The S9 fresh-eyes pass was run, and it changed the answer.**
`governance/strategies.md` S9 says a sweep is verified by readers who have not
seen the change. This one touched 34 verbs and 56 test assertions, so it
plainly qualified. Three reviewers read it - one the production code, one the
guards, one running the CLI cold as a newcomer - each told not to trust the
commit messages. They raised more than forty findings.

An earlier revision of this report said PASS on every dimension with no
independent reader. That verdict was wrong, and the record of what it missed is
in §5. It is left in the history rather than quietly replaced, because "the
author signed off and the author was wrong" is the whole argument for S9 and
this issue is now the worked example of it.

---

## 1. Scenario acceptance results

Twenty-one criteria, all passing. Run as the acceptance suite: 36 distinct
tests, exit 0. Evidence: `evidence/acceptance-run.txt`.

| Group | Criteria | Result |
|---|---|---|
| A - the hand-off contract | TRC-A1 to TRC-A6 | all PASS |
| B - the report contract | TRC-B1, TRC-B2 | all PASS |
| C - the modes | TRC-C1 to TRC-C7 | all PASS |
| D - what compression must not cost | TRC-D1, TRC-D2, TRC-D3 | all PASS |
| D - the test-migration rule | TRC-D4 | narrative - see below |
| E - the guard on the guard | TRC-E1, TRC-E2 | all PASS |

**TRC-D4 is marked narrative, and that is a real answer rather than a dodge.**
It says an expected string is updated only when the test's intent still holds.
No test can observe whether an author checked that before editing - it is a
decision procedure, and the framework's `verifiable: narrative` marking exists
for exactly this. What can be shown is that it was followed: 56 re-pointed
assertions across four pull requests, each file carrying a note saying which
detail moved and why the assertion still holds. None was edited to match new
output.

**Two scenarios point at guards that already existed** rather than at
duplicates written here. TRC-D2 (meaning before the code) is held by
`test_plain_language.py`; TRC-D3 (no retired vocabulary in printed strings) by
`test_printed_output_vocabulary.py`. The criteria named both as things this
change must not undo, and pointing at them is what "must not be undone" means.

**Found at verification, not before:** the spine's `tests:` list was the
placeholder names generated when the criteria were written - `test_trc_a1`
rather than `test_trc_a1_and_a5_a_hand_off_fits_one_screen_and_is_not_widened`.
Most did not resolve. `compass check` did not catch it because
`declared-tests-resolve` reports "declared tests are still a plan, not a claim"
until correctness is claimed, which is now. All 21 are corrected and run.

## 2. Test evidence

Linked, not reproduced.

| Record | What it covers | Result |
|---|---|---|
| `evidence/full-suite.txt` | the whole suite, working tree | 1315 passed, 7 skipped |
| `evidence/clean-clone.txt` (EV-CLEAN-1) | the suite as CI sees it | 1309 passed, 13 skipped |
| `evidence/acceptance-run.txt` | the 21 criteria as the acceptance suite | 36 passed |
| `evidence/compass-check.txt` (EV-CHK-1) | the mechanical gate | PASS, 14 checks |
| `evidence/mutation-round-u1.txt` (EV-MUT-U1) | part 1's guards, broken deliberately | 10 of 10 caught |
| `evidence/mutation-round-u2.txt` (EV-MUT-U2) | part 2's guards | 10 of 10 caught |
| `evidence/mutation-round-u3.txt` (EV-MUT-U3) | part 3's guards | 9 of 9 caught |
| `evidence/mutation-round-u4.txt` (EV-MUT-U4) | part 4's guards | 7 of 7 caught |
| `evidence/s9-fresh-eyes.txt` (EV-S9-1) | the S9 findings, each re-broken after its fix | 8 of 8 caught |

**Coverage:** this repository declares no coverage floor - the one in
`guardrails.yml` is a commented-out example. There is nothing to meet, and
saying "coverage passes" would be a pass that measured nothing.

### What the change actually did to the output

| Verb | Before | After |
|---|---|---|
| `compass check` | 45 lines, 14 of them PASS lines | 9 |
| `compass approach evaluate` | 16 lines incl. a raw Python dict at 151 chars | 5 |
| `compass flow` | 157 lines, no summary | 157, opening with a 2-line count |
| `compass retro` | the signal 18 lines down | the signal on line 1 |

### The mutation rounds, and the six defects they found

44 mutations across five rounds, every one caught after the fixes below. The
rounds are the reason this report can say the guards work rather than that they
pass.

| Found | What was wrong |
|---|---|
| TRC-F2 (earlier issue) | "at most two documents" is satisfied by **zero** |
| TRC-F4 (earlier issue) | two empty runs compare equal, reporting determinism from nothing |
| TRC-F3 (earlier issue) | asserted a rule's **log line**, which survived the thing never happening |
| TRC-C6 | the output kind was **derived**, so a verb that forgot to declare was impossible |
| TRC-B1 | read the first five lines of the whole report, so a section header supplied the number and the summary was never checked |
| TRC-E1 (analyze determinism) | a rename disabled its line filter, so it failed one run in ten |

**Five mutations were badly chosen and re-run rather than counted.** One broke
the source, so a SyntaxError failed the run instead of the guard. One widened a
line that goes through the emitter, which renders within the bound by
construction - the only way a verb can breach it is by bypassing the emitter
with a raw `print()`, which is what the guard exists to catch. Recorded in the
evidence files with the diagnosis, because a mutation that "passed" for the
wrong reason proves nothing.

### The path defect, and why it is listed as one finding rather than three

A path shortened to fit the width bound becomes a link a reader cannot open -
worse than a wide line, because one fails at the thing it exists for and the
other is merely untidy. It was fixed three times, at three call sites, on three
separate days: the hand-off's Read line, the report's summary, then the
one-line helper. The third time it was fixed at the class instead - the
exemption moved inside the fitting function, so no caller can get it wrong.
A rule every caller must remember is a rule the fourth caller forgets.

## 3. Review dimensions

| Dimension | Applies? | Result | Assessed by | Evidence |
|---|---|---|---|---|
| correctness | always | PASS | author | 21 criteria pass; 36 tests; suite 1315 |
| governance | always | PASS | author | EV-CHK-1. The new check joined G4 rather than becoming a sixth guardrail (ADR-002); `guardrails.yml` and `routing-policy.yml` both version-bumped and re-pinned |
| traceability | always | PASS | author | 24 changed files each traced; `changed-code-traces-to-scenario` passes |
| regression | yes | PASS | author | 1315 in the working tree, 1309 in a clean clone, up from 1283 at the start. The clean-clone check was added to the routine after it caught a CI failure in part 3 |
| security | scaled | PASS | author | No auth, money, personal data or network surface. `--evidence-out` writes one file to a caller-supplied path; nothing else new touches the filesystem |
| clarity | yes | PASS | **three independent readers** | EV-S9-1. A cold newcomer ran the CLI and rated the failure messages, the flags and the output; a second read the production code; a third broke the guards. Their findings are §5 and are fixed. This is the only dimension here that was not author-assessed, and it is the one that needed it most |
| claims | immovable | n/a - empty | author | No marketer, no public claim. An empty claim set, which is different from a claim review that passed |
| fitness | policy (RP-REQUIRE-003) | PASS - **checked nothing** | mechanism | `command-passes` reports: this project declares no guardrail that runs a command, so it passed without checking anything. Recorded at triage as an expected empty pass, and it was |

## 4. Gate decision

| Gate | Required by | Status | Evidence |
|---|---|---|---|
| verify.correctness | immovable + approach | GREEN | EV-T-TRC-A1, EV-T-TRC-B1, EV-T-TRC-C1 |
| verify.governance | immovable + approach | GREEN | EV-CHK-1 |
| verify.traceability | approach | GREEN | EV-CHK-1 |
| verify.regression | immovable | GREEN | EV-T-TRC-A6 |
| verify.security | approach | GREEN | EV-CLEAN-1 |
| verify.clarity | approach | GREEN | EV-REVIEW-1 (this report) |
| verify.claims | immovable | GREEN (empty claim set) | EV-CHK-1 |
| verify.fitness | policy | GREEN (cleared on a check that ran nothing) | EV-CHK-1 |

**Overall:** PASS - advance to ship.

---

## 5. What the fresh-eyes pass found

Twelve defects this change caused, all fixed in PR #82 and each with a mutation
proving it fails if it returns (`EV-S9-1`, eight mutations, all caught).

### Behaviour that was lost

| Finding | Why it mattered |
|---|---|
| `compass check` stated a failure count and listed fewer, sometimes with no marker at all | The verdict counted check RUNS; the list was deduplicated by name. A failure vanished and the page read as complete. TRC-A4 asserted that a marker EXISTS rather than that the arithmetic holds, so it passed. |
| The adoption-mode banner had moved to `--verbose` | An advisory run showed FAIL, exited 0, and said nothing about why - the exact mistake the banner exists to prevent. I re-pointed the test that owned it, which is the case my own rule calls "the output is wrong, not the test". |
| The "guardrail ABSENT from this project's governance" warning | In neither the default view nor `--json`. Silence was the original defect. |
| A spike with no `spike_guardrails:` | Printed "FAIL - 1 of 1" and named nothing; the explanation was verbose-only. |
| `compass ci` did not forward its mode | CI logs got a summary ending "run with --verbose", and `ci --verbose` printed the same summary. The one place a reader cannot re-run interactively was the one place that advice was dead. |

### Flags that did nothing

`--evidence-out` was advertised on all 47 verbs and wrote no file anywhere.
About a third of verbs accepted every flag and honoured none - **the exact
failure TRC-C1 was written to prevent, passing a test written to prevent it**,
because the test checked "accepted" while its docstring promised "honoured".
`next_step` was declared, written into the JSON, and never rendered.

### Guards that could not fail

Three, all mine:

- The identifier test's filter matched the **verdict headline**, so replacing
  every per-failure line with "3 check(s) failed" - the exact output it forbids
  - passed it. Its two sibling tests already carried the fix, with a comment
  explaining the trap. I wrote that comment and did not apply it three
  functions later.
- Two tail tests skipped a verb that exited non-zero, so a verb could ignore a
  flag AND fail and be counted as fine.
- The guidance test walked the guidance table rather than the check registry,
  so five checks with no entry were invisible to a test whose message claims it
  covers them.

### And one that was nobody's finding but mine to own

`pyproject.toml` was committed by accident in part 2. `git add -A` swept up a
file no commit message mentions, declaring `version = "0.1.0"` and
`requires-python = ">=3.13"` in a project that deliberately ships pip-free.
Nothing in the suite caught it.

### Three fixes that initially had no guard

After fixing the banner, the absent-guardrail notice and `next_step`, a
mutation round showed all three could regress silently - I had corrected the
behaviour and written nothing that would catch its return. That is the same
error in a smaller frame, and it is the argument for mutating **after** fixing
rather than only before.

## Found and filed, not fixed here

| Issue | What |
|---|---|
| `tests-can-depend-on-untracked-local-state` | Four tests read `.compass/work/`, which is gitignored. Green locally, red in CI. |
| `entry-point-cap-measures-the-wrong-thing` | Raised three times in a week; it measures verb count, not what it names. |
| `scenario-ids-unvalidated-on-trace` | `changed-file add --scenario` accepts an id that does not exist; `tdd-red` refuses. |
| `spine-writers-leave-the-page-stale` | Six verbs write `task.yml` and none regenerates the review page. |
| `lint-demands-a-key-it-then-rejects` | `issue lint` says `issue:` is missing and that `issue` is not allowed, in one block. The key is `task:` and no message says so. |
| `one-concept-many-names-in-one-command` | The human view and the spine use different names for seven of eight stages, so a reader cannot grep for what they were shown. |
| `pass-that-inspected-nothing-reads-as-pass` | `check` labels twelve PASS while its own JSON records five as `nothing-to-check`. |
| `redirect-stdout-without-try-finally` | `retro` enters a stdout redirect by hand with no `try/finally`; one exception poisons stdout for an in-process test run. |

## Gate

- [x] Every required review dimension passed with evidence attached.
- [x] Every gate is GREEN with a resolving evidence pointer.
- [x] This report is complete - no empty evidence blocks.

### Definition of Done

- [x] **Every scenario passes** - §1; 36 tests, exit 0.
- [x] **TDD suite green** - 1315 passed, 7 skipped; 1309 in a clean clone.
- [ ] (evidence: EV-CHK-1) **Coverage meets the tested-before-ship guardrail's
      floor** - this repository declares no floor, so there is nothing to meet.
      Deliberately not ticked: a tick would claim a measurement nobody took.
- [x] **No lint / format / type errors** - the suite includes the house-style,
      terminology and printed-vocabulary guards.
- [ ] (evidence: EV-CHK-1) **Traceability intact** - 24 changed files traced;
      no marketer, so no claim chain.
- [x] *(carried to ship)* Living docs updated - `docs/five-minutes.md` shows
      the default view and the `--verbose` block; `README.md` carries the new
      verbs. The living spec is re-derived after landing, as every issue does.
- [x] **Every owed follow-up settled** - none owed by the approach. Four
      defects found were filed as their own issues rather than carried.

Next stage: **ship** (`/compass:ship`).
