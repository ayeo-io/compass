# Acceptance criteria - headless-runner

## Summary

- **Goal:** one stage of one issue runs without a person in the session, and stops safely.
- **Approach:** `compass run <slug> --stage build|verify --stop-file PATH` starts `claude -p` once per cycle, through the launcher the eval harness uses, and decides between cycles from the files on disk alone.
- **Why now:** loop ceilings (B15, #301) make an unattended loop safe to bound.

From a planning spec (`a private planning document`), issue #302, narrowed by the architect's ruling of 2026-10-03 (no live run, no secret) and amended by the requirements review.

| Id | Criterion |
|---|---|
| HR-A | Given a project, then `compass run` exits 2 and starts no session and writes no record when: the project has no `.compass/`; the issue does not exist; the stage is not `build` or `verify`; `--stop-file` is not given; `claude` cannot be found; or `--max-cycles` or `--max-minutes` is below 1 cycle, not above 0 minutes, or above its ceiling (RP-LOOP-006 `run_cycles` 30, RP-LOOP-007 `run_minutes` 240). An omitted flag takes the policy limit. |
| HR-B | Given a run whose sessions change the issue's records but never finish the stage, when it reaches its cycle ceiling, then it exits 4, adds a `runs:` entry to the manifest with `outcome: stopped` and a `stopped_reason` of `{reason, evidence, at}` naming the ceiling and the run record, writes the run record to `docs/compass/<created>-<slug>/run-<n>.md` with each cycle's exit code and outcome, and the issue is not landed. |
| HR-C | Given a stop file, then the runner checks it before every cycle, the first included: a stop file present at the start means no session, and one that appears during a run means no further session. Either way the run exits 4 with the stop file as the reason. A running session is not interrupted. |
| HR-D | Given a run, then it ends with exit 0 and `outcome: done` when the stage is done: for verify, every gate passes; for build, at least one scenario and every scenario has a green record. The runner never writes a gate. A session that lands the issue stops the run with exit 4. |
| HR-E | Given a session whose error output carries a credential (`sk-ant-`, `ghp_`, `gho_`, `github_pat_`, `AKIA`, a bearer token, or the value of an environment variable named KEY, TOKEN, SECRET or PASSWORD), then the run record, the manifest and the runner's printed output hold the text with the credential replaced by `[REDACTED]`. The test fails when redaction is switched off. |
| HR-F | Given any run, then each cycle starts a new `claude -p` session that resumes nothing, loads the Compass plugin the running CLI belongs to, names the stage's command (`build` runs `/compass:implement`, `verify` runs `/compass:verify`), says the session is unattended, forbids landing, pushing and merging, and names `git push`, `gh pr merge` and `compass ship-commit` in `--disallowedTools`. The parent environment passes through unchanged. A guard fails the tests if anything but the stub ran. |
| HR-G | Given sessions that change nothing in the manifest or `evidence/` (the runner's own `runs:` entry left out), then the run stops when the repeated-error ceiling's number of cycles in a row made no progress. A manifest the runner cannot read stops the run. |
| HR-H | Given a run that passes its minute ceiling during a session, then the session is ended and the run stops with the minute ceiling as the reason. `--max-minutes` takes a decimal. |
| HR-I | Given the eval harness, then it starts `claude` through the same launcher function `compass run` uses. |
| HR-J | Given the change, then ADR-030 records the exception to ADR-025 with status `proposed`; `ci/headless-verify.yml` runs only on `workflow_dispatch`, names the secret it needs, and nothing is added under `.github/workflows/`; and `docs/headless-runner.md`, listed in the "Owning docs" table of `docs/README.md`, says the live CI acceptance is not met. |

## Not in scope

- A live run, and a quick-fix example run in CI. Both cost money on every run; the maintainer decides.
- Running every subtask of a map; cost ceilings; notifications.
