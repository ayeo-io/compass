# Distribution map - headless-runner

| Subtask | Scenarios | Files | Wave |
|---|---|---|---|
| subtask-1 | HR-A to HR-I | every file in the technical design | 1 |

One subtask: the runner, the launcher and the tests share the launcher's interface, so a second builder would wait on the first.
