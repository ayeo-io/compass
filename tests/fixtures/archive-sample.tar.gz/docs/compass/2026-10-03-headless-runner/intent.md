# Intent - headless-runner

## Problem

Compass cannot run a stage of an issue without a person in a Claude Code session. Unattended runs fail in known ways: one long session runs out of context; a stop file nobody checks never stops anything; and an error message can carry a credential into a record.

## Desired outcome

- `compass run <slug> --stage build|verify` runs one stage of one issue through `claude -p`, with the Compass plugin loaded.
- Each cycle is a fresh session. Between cycles the runner reads only the manifest and the evidence on disk, and decides to continue or to stop with a reason.
- The run stops at a cycle ceiling and a minute ceiling. A run that stops is recorded as stopped, never as landed.
- The runner checks a stop file before every cycle, and refuses to start without one.
- Error text is redacted before it reaches any record.
- Each run leaves a run record beside the issue's documents.
- A reference GitHub Actions workflow shows how to run the verify stage, started only by hand.

## Success signals

- A run that reaches its cycle ceiling ends with a stop reason recorded and the issue not landed, pinned by a test.
- A planted credential in error text does not reach the run record, pinned by a test that fails without redaction.

## Constraints

- The runner starts `claude -p` and nothing else. It does not embed a model client and is not a daemon.
- It refuses in a project without `.compass/`.
- It never lands, ships, pushes, merges or publishes.
- It reuses the eval harness's launcher instead of adding a second one.
- No test calls the real `claude`.

## Non-goals

- Running every subtask of a map in waves.
- An Agent SDK adapter, notifications, cost ceilings.
- A live run or a stored credential. The maintainer decides on both.

## Affected roles

Engineer, and QA for the verify stage.

From a planning spec (`a private planning document`) and intent 4 of a private analysis, narrowed by the architect's ruling of 2026-10-03.
