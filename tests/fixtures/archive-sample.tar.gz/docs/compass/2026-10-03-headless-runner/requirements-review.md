# Requirements review - headless-runner

## Summary

The nine criteria cover the loop, the ceilings, the stop file and redaction, and each one can run against a stub `claude` executable. The set is not ready to build yet, for three reasons:

- Four limits in the architect's ruling (`.compass/rulings/headless-runner.md`) have no criterion:
  - the guard against a real `claude`;
  - the redaction test that must fail with redaction switched off;
  - the inactive reference workflow;
  - stopping when a session lands the issue.
- Six criteria use a term the reader cannot pin down. Examples are "progress", "credential", "finish the stage" for build, and a minute ceiling that a test cannot reach in seconds.
- Exit code 3 already means "this install is incomplete" (`cli/compass_pkg/__init__.py`, `_incomplete_install`). A CI job could not tell a stopped run from a broken install.

Each gap and open question below has a recommended answer. The technical design (`technical-design.md` in this directory) already takes most of them. Once the criteria are amended as listed, the Definition of Ready is met. No edit beyond the criteria is needed.

Sources read:

- `intent.md` and `acceptance-criteria.md` in this directory;
- `.compass/work/headless-runner/delivery-approach.md`;
- the ruling;
- a planning spec (`a private planning document`);
- ADR-025;
- `evals/harness.py` (`_common_claude_args`, `_invoke_claude`);
- `cli/compass_pkg/loop_ceilings.py`;
- `governance/routing-policy.yml`.

## Criteria

| Id | Verdict | Note |
|---|---|---|
| HR-A | Amend | Each refusal can be tested with a stub. Three changes are needed: <br>- "its ceiling in the routing policy" has nothing to point at. `loop_ceilings.CEILINGS` holds only `builder_attempts`, `review_rounds`, `replans` and `repeated_error`, so no cycle or minute ceiling exists. Name the two new rules: RP-LOOP-006 `run_cycles` and RP-LOOP-007 `run_minutes`. <br>- State that an omitted flag takes the policy limit, and that a value below 1 is refused. <br>- State the exit code (2, the CLI's `CompassError` code) and that a refusal writes no run record. |
| HR-B | Amend | This is the spec's second acceptance and can be tested with a stub. Exit code 3 clashes with the incomplete-install exit, so use 4. Name where the stop reason lives: the manifest's `runs:` entry, as `stopped_reason` in the shape B15 already uses (`reason`, `evidence`, `at`). `evidence` is the run record's path. "Not landed" means the manifest `status` is not `landed`. |
| HR-C | Amend | Can be tested with a stub. Say that the check runs before every cycle, including the first. A stop file that exists at the start means zero sessions, exit 4 and the stop file recorded as the reason. Say that a session already running is not interrupted, because the minute ceiling bounds it. |
| HR-D | Amend | Can be tested with a stub. State that the runner reads gate status from the manifest and never writes a gate itself. "Records the stage as done" means `outcome: done` in the `runs:` entry. Build has no matching criterion (see the gaps below). |
| HR-E | Amend | "A credential" is open-ended. Name the shapes: Anthropic (`sk-ant-`), GitHub (`ghp_`, `gho_`, `github_pat_`), AWS (`AKIA`), bearer tokens, and the value of any environment variable whose name contains KEY, TOKEN, SECRET or PASSWORD. Extend the scope to the runner's own printed output. Limit it to what the runner writes, because the runner cannot redact what a session writes. Add the ruling's condition: the test must fail when redaction is switched off. |
| HR-F | Amend | Can be tested from the stub's argument log. Spell out the mapping `build` -> `/compass:implement` and `verify` -> `/compass:verify`, because no `build` command exists. "Resumes nothing" means no `--resume` and no `--continue`. Add three points: `--disallowedTools` names `git push`, `gh pr merge` and `compass ship-commit`; the parent environment passes through unchanged; `claude` is the only process the runner starts. |
| HR-G | Amend | "No progress" needs a definition. Use this one: the digest of the manifest and the `evidence/` folder is unchanged since the previous cycle, leaving out the runner's own `runs:` entry. Without that exclusion, the runner's own write counts as progress. A `claude` exit code other than zero counts as a cycle. Using `repeated_error` (RP-LOOP-005, limit 3) as the count stretches that rule's stated rationale, but it is acceptable. Say so in the owning doc. |
| HR-H | Amend | A test cannot wait a minute per case. Let `--max-minutes` take a decimal (for example `0.05`) so a stub that sleeps can pass the ceiling in seconds. "Ended" means the launcher's timeout kills the process. `_invoke_claude` has no timeout now, so the shared launcher needs one. |
| HR-I | Pass | Can be tested by patching the shared launcher and running the harness's existing tests. `cli/` must not import from `evals/`, so the launcher lives under `cli/compass_pkg/` and the harness imports it. The harness already puts `cli/` on `sys.path`. The `--max-budget-usd` and `--resume` arguments stay in the harness, because cost ceilings are a non-goal for `compass run`. |

## Gaps

Each item is an intent outcome or ruling limit with no criterion. The recommended criterion follows it.

1. **A session lands the issue** (intent constraint and ruling). Given a session that sets the manifest `status` to `landed`, the run stops at once with exit 4 and a stop reason saying the session landed the issue.
2. **No test calls the real `claude`** (ruling). A guard test puts a stub first on the path and fails if any cycle leaves no stub marker.
3. **Build stage done.** Given a build run, the stage is done when every scenario in the manifest has a test and a green `test-run` record dated after the run started. The run then exits 0 with `outcome: done`.
4. **Run record.** Each run that starts a session writes `docs/compass/<created>-<slug>/run-<n>.md` inside the issue directory. The record holds the stage, start and end times, the cycles, the outcome, the stop reason and the redacted error text. The technical design puts it at `docs/compass/<created>-<slug>-run-<n>.md`, beside the directory instead. `.gitignore` ignores `/docs/compass/*/` (directories only), so a flat file there would be tracked and seen by the style scans.
5. **Reference workflow** (intent and ruling). `ci/headless-verify.yml` exists and has `workflow_dispatch` as its only trigger. It names the secret it needs but does not create it. Nothing is added under `.github/workflows/`.
6. **ADR** (ruling). ADR-030 exists with status `proposed` and states the exception: only `compass run` starts a host session, only `claude -p`, and never from a hook or another verb. The status stays `proposed` because accepting the exception is the maintainer's decision.
7. **Docs** (ruling, `verify.claims`). The owning doc names the three new modules and says plainly that a planning spec's first acceptance, a quick-fix example run assess-to-ship in CI, is not met. `docs/README.md` lists the doc in its "Owning docs" table.
8. **Unreadable manifest** (from the technical design). If the manifest cannot be read after a cycle, the run stops with exit 4 and records why. It fails closed.

## Open questions

The maintainer is offline. Each recommendation will be followed unless it is wrong.

1. **Is the stage value `build` or `implement`?** The manifest's stage key is `implement` (`route_shapes` in `governance/routing-policy.yml`). The intent and the spec say `build`. Recommendation: keep `build` as the intent states it, and map it to `/compass:implement` in HR-F. Changing the flag would contradict the intent.
2. **What exit code does a stopped run use?** Recommendation: 0 means done, 2 means refused, and 4 means stopped. Exit 3 stays the incomplete-install code.
3. **What are the default ceilings?** The ruling says "use B15 defaults", but B15 has no cycle or minute ceiling. Recommendation: RP-LOOP-006 `run_cycles: 30` and RP-LOOP-007 `run_minutes: 240`, as the technical design proposes. A flag can lower a limit, never raise it. These defaults are new, not from B15. They go through the PR because they change `governance/routing-policy.yml` and both schemas.
4. **Which plugin does a session load?** Recommendation: `--plugin-dir` set to the Compass install the running `cli/compass` belongs to, so the session and the runner use the same version.
5. **Is the stop file path relative or absolute?** Recommendation: a relative path resolves from the project root, and the path is required, not the file. The file's existence means "stop".
6. **Does the manifest get a `runs:` list?** Recommendation: yes. It makes the stop reason readable by `compass check` and by the spec's acceptance wording (`stopped_reason`). Add it to `schemas/manifest.schema.json`.

## Definition of Ready

Definition of Ready: not met. It is met once `acceptance-criteria.md` takes the amendments to HR-A to HR-H and adds criteria for the eight gaps, with the answers above.

## Resolution

The amendments were taken into `acceptance-criteria.md` on 2026-10-03: HR-A to HR-H were tightened, the eight gaps were folded into HR-B, HR-D, HR-F and HR-G, and HR-J was added for the decision record, the reference workflow and the owning doc. Each open question takes the recommended answer.

Definition of Ready: met.
