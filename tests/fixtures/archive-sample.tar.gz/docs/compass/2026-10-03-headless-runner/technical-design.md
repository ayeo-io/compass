# Technical design - headless-runner

## Decision record

ADR-030, "compass run is the one verb that starts a host session", proposes a bounded exception to ADR-025, with status `proposed` until the maintainer accepts it: only `compass run` starts a process that is a model session, only `claude -p`, and never from a hook or another verb. The multiagent interface of ADR-025 is unchanged; the orchestrator still launches nothing.

## Modules

| File | Role |
|---|---|
| `cli/compass_pkg/host_launch.py` | New. `launch_claude(claude_exe, message, args, cwd, env, timeout)` starts one `claude -p` call and returns its exit code, standard output and standard error, or a timeout. `session_summary(stdout)` reads the stream-json `result` event: session id, cost, whether it ended in error. |
| `evals/harness.py` | `_invoke_claude` calls `launch_claude` instead of starting the process itself (HR-I). Its event parsing stays its own. |
| `cli/compass_pkg/redact.py` | New. `redact(text, env)` replaces credential shapes (Anthropic, GitHub, AWS and bearer tokens, `key=value` secrets) and the value of any environment variable whose name says key, token, secret or password. |
| `cli/compass_pkg/run_cmd.py` | New. `compass run`: refusals, the cycle loop, the decision after each cycle, the run record and the manifest's `runs:` entry. |
| `cli/compass_pkg/loop_ceilings.py` | Two more ceilings: `run_cycles` and `run_minutes`. |
| `governance/routing-policy.yml` | RP-LOOP-006 `run_cycles` 30 and RP-LOOP-007 `run_minutes` 240. A flag can lower a ceiling, never raise it. |
| `schemas/manifest.schema.json`, `schemas/routing-policy.schema.json` | `runs:` and the two ceiling names. |
| `ci/headless-verify.yml` | Reference workflow, `workflow_dispatch` only, outside `.github/workflows/`. It names the secret it would need. |
| `docs/headless-runner.md` | The owning doc for the three new modules. |

## The loop

1. Refuse before any session (HR-A): no `.compass/`, unknown issue, stage not `build` or `verify`, no `--stop-file`, no `claude` (from `--claude` or the path), or a flag above its ceiling.
2. Before each cycle: stop if the stop file exists (HR-C), the cycle ceiling is reached (HR-B), or the minute ceiling is spent (HR-H).
3. Start one fresh session (HR-F) with the prompt: the stage command (`/compass:implement` for build, `/compass:verify` for verify), the issue slug, a line saying nobody will answer a question, and a line forbidding land, ship, push and merge. Arguments: stream-json output, `--plugin-dir` set to the Compass install, `acceptEdits`, and `--disallowedTools` naming `git push`, `gh pr merge` and `compass ship-commit`. No `--resume` or `--continue`. The parent environment passes through unchanged. The session's timeout is the minutes left; the launcher gains a timeout for this.
4. After the session, read the manifest and the evidence folder:
   - done (HR-D): verify when every gate passes; build when there is at least one scenario and every scenario has a green record. The runner never writes a gate;
   - landed by the session: stop, because a run must never land;
   - no progress (HR-G): the digest of the manifest, without the runner's own `runs:` entry, and the evidence folder is unchanged; at the `repeated_error` ceiling in a row, stop;
   - an unreadable manifest: stop, fail closed.
5. Every stop and the end are written to `docs/compass/<created>-<slug>/run-<n>.md`, inside the issue's ignored documents folder, and to the manifest's `runs:` list, `{n, stage, started, ended, cycles, outcome, stopped_reason}`. `stopped_reason` has the shape B15 gave subtasks: `{reason, evidence, at}`, with the run record as the evidence. All text is redacted first (HR-E). Exit 0 when done, 4 when stopped, 2 when refused; 3 already means an incomplete install.

## Tests

`tests/test_headless_runner.py` puts a stub `claude` first on the path. The stub logs its arguments, writes a marker file per call, and follows a script per cycle: change the records, pass every gate, create the stop file, print a credential, sleep. A guard asserts one marker per cycle, so the test fails if anything but the stub ran.

## Breakdown

One builder, solo, recorded as `subtask-1`.
