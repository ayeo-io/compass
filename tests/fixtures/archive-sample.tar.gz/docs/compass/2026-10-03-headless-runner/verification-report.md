# Verification report - headless-runner

**Result:** pass, with the live acceptance not met · **Date:** 2026-10-03

## 1. Scenario acceptance results

| Check | Result | Evidence |
|---|---|---|
| HR-A: refusals before any session, exit 2 | pass | `EV-T-HR-A` |
| HR-B: the cycle ceiling stops the run unlanded; record numbers never repeat; one run per issue at a time | pass | `EV-T-HR-B` |
| HR-C: a stop file at the start or during the run | pass | `EV-T-HR-C` |
| HR-D: done for verify and build; a session that lands stops the run | pass | `EV-T-HR-D` |
| HR-E: credentials redacted, also when the cut would split one | pass; fails with redaction switched off | `EV-T-HR-E` |
| HR-F: fresh unattended session per cycle; the stub guard fails when another `claude` runs | pass | `EV-T-HR-F` |
| HR-G: no progress, an unreadable manifest, a broken `runs:` | pass | `EV-T-HR-G` |
| HR-H: the minute ceiling ends the session and what it started; SIGINT and SIGTERM end it too | pass | `EV-T-HR-H` |
| HR-I: the eval harness uses the shared launcher | pass | `EV-T-HR-I` |
| HR-J: ADR-030 proposed, inactive reference workflow, owning doc | pass | `EV-T-HR-J` |
| The full suite, on the tree that ships | pass | `EV-T-HR-D` |
| Live acceptance: a quick-fix example run assess-to-ship in CI | **not met**: needs a secret and paid sessions, left to the maintainer | - |

## 2. Review

- Round 1 failed with six defects: six verb-list tests broke, a cut could leak part of a credential, record numbers could repeat, a broken manifest could be overwritten after a timeout, a timeout left the session's children running, and the stub guard could not fail. Each was fixed test-first.
- Round 2 failed with two defects the fixes introduced: an interrupted run left its session running, and a removed lock crashed the run. Both were fixed test-first, with SIGTERM covered too.
- Round 3 passed. Its non-blocking findings are issue #303.

Three rounds is this cross-cutting issue's review-round ceiling, so it lands within it.

## 3. Failure modes de-scoped at define

None.

## 4. Decisions taken for the user

- Scope follows the architect's ruling: built against a stub, no live run, no secret. The live acceptance waits for the maintainer.
- ADR-030 is `proposed`: accepting the exception to ADR-025 is the maintainer's decision.
- Exit codes are 0 done, 4 stopped, 2 refused, because 3 already means an incomplete install.
- The run record lives inside the issue's documents folder, which is ignored, not beside it.
- New ceilings RP-LOOP-006 (30 sessions) and RP-LOOP-007 (240 minutes); no source set them, so these are a starting point.
- Not acted on from review: a process that leaves the session's group can hold the runner until it exits; the docs name rule ids before their meaning.
