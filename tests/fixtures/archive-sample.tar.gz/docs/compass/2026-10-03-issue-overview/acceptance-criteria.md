# Acceptance criteria - issue-overview

## Summary

- **Goal:** a reviewer sees an issue's traceability chain, from intent to scenario to test to evidence, in a preview with no extension.
- **Approach:** two new sections on the page `compass issue dashboard` already writes and `compass check` already keeps current: a scenario table and a Mermaid flowchart.
- **Why now:** the chain is recorded but only readable as YAML and JSON.

From a planning spec (`a private planning document`) and a planning spec, issue #296.

| Id | Criterion |
|---|---|
| IO-A | Given an issue's scenarios and its red and green records, then the page has one table row per scenario with its title, a red mark, a green mark and its evidence path, using ✓ and ○. |
| IO-B | Given the same issue, then the page has a Mermaid flowchart from each intent to its scenarios, tests and evidence, and a scenario with a red but no green is styled as open. |
| IO-C | Given more than 25 scenarios, then the flowchart shows a summary node instead of every scenario, and the table still lists them all. |
| IO-D | Given a green recorded after the page was written, then `compass check` fails the page as stale and names `compass issue dashboard` as the fix. |
| IO-E | Given the status line, then it names the gates passed out of the gates required. |

The PRD's new `compass render` verb and separate `overview.md` are not built: the page already exists, is generated, and is checked for staleness, so extending it adds no verb. The PRD's YAML front matter becomes the status line, because the generated-file header comes first.
