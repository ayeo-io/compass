# Technical design - issue-overview

## Files

- `cli/compass_pkg/dashboard.py` - a "Traceability" section (table and Mermaid flowchart) and gates on the status line.
- `tests/test_issue_overview.py`.

## Flowchart

`flowchart LR`: an intent node per intent, a scenario node per scenario, a test node per test path, an evidence node per green record. `classDef open` styles a scenario with a red and no green. Past 25 scenarios, one summary node per intent counts its scenarios and their proven share.
