# Verification report - issue-overview

**Result:** pass · **Date:** 2026-10-03

## 1. Scenario acceptance results

| Check | Result | Evidence |
|---|---|---|
| IO-A: one row per scenario with red, green, acceptance and evidence marks; unbound records listed | pass | `EV-T-IO-C` |
| IO-B: a Mermaid chain from intent to scenario to test to evidence; unproven scenarios styled open; a shared test never leads an open scenario to evidence; ids and labels safe | pass; mermaid-cli parses all 229 charts in the local archive | `EV-T-IO-C`, `evidence/review.md` |
| IO-C: past 25 scenarios, one summary node per intent, counting green or acceptance as proven | pass | `EV-T-IO-C` |
| IO-D: a later green makes a current-format page stale; a page from before this format declines instead of failing | pass | `EV-T-IO-C` |
| IO-E: the status line counts gates passed out of required | pass | `EV-T-IO-C` |
| The full suite, on the tree that ships | pass | `EV-T-IO-C` |

## 2. Review

Round 1 failed: a test node shared by two scenarios led an open scenario's arrows to the other scenario's evidence, on 85 real scenarios. Round 2 passed; its point that the two chart modes disagreed about acceptance was fixed test-first.

## 3. Failure modes de-scoped at define

None.

## 4. Decisions taken for the user

- The PRD's `compass render` verb and separate `overview.md` are not built; the dashboard page is extended instead, as the spec's check at assess allowed. Recorded in `delivery-approach.md`.
- Pages generated before this format decline rather than fail, so upgrading turns no issue red (ADR-006). `governance/guardrails.yml` names the case, at version 1.25.1.
