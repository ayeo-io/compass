# Acceptance criteria - loop-ceilings

## Summary

- **Goal:** a multiagent run stops at a limit, and a run that goes past one lands only with a recorded reason.
- **Approach:** limits are rules in `governance/routing-policy.yml`. `compass issue subtask` refuses to open work past them, and `compass check` refuses to land a run past them without a reason.
- **Why now:** the headless runner (a planning spec) runs this loop with nobody watching, and 16 of the 49 subtasks on record went past three attempts or two review rounds.

From a planning spec (`a private planning document`), issue #300.

| Id | Criterion |
|---|---|
| LC-A | Given the shipped routing policy, then an issue's ceilings resolve from `routing_guardrails.loop_ceilings` rules with RP- ids: 3 builder attempts, 2 review rounds for trivial and contained risk and 3 otherwise, 2 replans, and 3 repeats of one error; the lowest matching limit wins; and a policy without the rules gives no ceiling and a drift report naming the missing ids. |
| LC-B | Given a subtask whose builder reported the same error three times, when another attempt is asked for, then `compass issue subtask update --attempt` refuses it and names the repeated error, and `compass issue subtask next` lists the subtask as refused. |
| LC-C | Given a subtask at its attempt ceiling, when another attempt is asked for, then the update refuses it and names the ceiling and its rule id. |
| LC-D | Given a multiagent issue whose subtask has more review rounds than its ceiling, then `compass check` fails it until a stop reason is recorded with an evidence file, and a subtask stopped that way passes without being done. |
| LC-E | Given an issue created before the ceilings existed, then `compass check` judges it as before, whatever its counts. |
| LC-F | Given a run at its replan ceiling, when another replan is recorded, then `compass issue subtask replan` refuses it and names the ceiling. |

## Not in scope

- A ceiling on tokens or cost. `subtasks[].cost` already records cost against a budget.
- Replanning by the CLI. The CLI refuses; the orchestrator replans.
- Ceilings keyed by route shape. Only multiagent routes reach these commands, and the intent's defaults differ by risk, so the rules match the assessment as the caps already do.
