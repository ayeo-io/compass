# Technical design - loop-ceilings

## Refine (light)

The criteria were read against a planning spec and intent 3 of a private analysis. Two points changed them:

- The spec keys the ceilings by route shape, but the intent's defaults differ by risk, and only multiagent routes reach these commands. The rules match the assessment, as the caps do (LC-A).
- A replan ceiling with nothing that records a replan could never fail. `compass issue subtask replan` records one (LC-F).

## Policy

`governance/routing-policy.yml` gains `routing_guardrails.loop_ceilings`, a list of rules:

| Id | Ceiling | Limit | When |
|---|---|---|---|
| RP-LOOP-001 | `builder_attempts` | 3 | always |
| RP-LOOP-002 | `review_rounds` | 3 | always |
| RP-LOOP-003 | `review_rounds` | 2 | risk trivial or contained |
| RP-LOOP-004 | `replans` | 2 | always |
| RP-LOOP-005 | `repeated_error` | 3 | always |

For each ceiling the lowest limit among the matching rules applies, so a rule can only lower a limit another rule sets. A policy with no rule for a ceiling gives no ceiling. `governance.py` lists `loop_ceilings` among the rule sources, so the drift report names any id a project's copy lacks. `schemas/routing-policy.schema.json` describes the rule. The policy version goes from 2.13.0 to 2.14.0.

## Recording

`cli/compass_pkg/subtasks.py`:

- `loop_ceilings(task)` reads the policy in force and returns `{name: (limit, rule id)}`.
- `update --error TEXT` stores `last_error_digest`, the first 16 hex digits of the SHA-256 of the text with its whitespace collapsed, and `error_repeat_count`, which counts the same digest in a row and resets to 1 on a different one.
- `update --attempt` refuses when `attempts` has reached `builder_attempts`, or `error_repeat_count` has reached `repeated_error`. The refusal names the limit, its rule id, and `--stop-reason` as the way to close the subtask.
- `update --round` past `review_rounds` is recorded, because it records what happened, and prints that the run cannot land without a stop reason.
- `update --stop-reason TEXT --stop-evidence PATH` stores `stopped_reason: {reason, evidence, at}`. Both are needed, and the evidence must be a file inside the project.
- `next` lists a subtask past a ceiling as refused, with the reason, instead of as work to resume.
- `replan --reason TEXT` appends `{reason, at}` to the manifest's `replans:` list and refuses past `replans`.

## Check

`multiagent-run-recorded` in `cli/compass_pkg/multiagent_check.py`:

- A subtask with a `stopped_reason` whose evidence file exists counts as finished, whether or not it is done.
- For an issue created on or after 2026-10-03, a subtask with more review rounds or attempts than its ceiling, and no stop reason, fails.
- An issue created earlier is judged as before (ADR-006). Its counts are not compared.

The `governance/guardrails.yml` description of the check says so; version and content hash move.

## Docs

- `schemas/manifest.schema.json`: the new subtask keys and `replans`.
- `agents/orchestrator.md`: the stop conditions, and that a ceiling reached is a stop with a reason, not a success.
- The owning doc for multiagent runs, from `docs/README.md`.

## Breakdown

One builder, solo, recorded as `subtask-1`: every change meets in `subtasks.py` and the manifest keys it writes.
