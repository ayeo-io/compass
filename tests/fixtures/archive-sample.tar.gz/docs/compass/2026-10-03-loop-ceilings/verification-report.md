# Verification report - loop-ceilings

**Result:** pass · **Date:** 2026-10-03

## 1. Scenario acceptance results

| Check | Result | Evidence |
|---|---|---|
| LC-A: ceilings resolve from RP-LOOP rules by risk, lowest wins; a policy without them gives no ceiling and drift names the ids | pass | `EV-T-LC-A` |
| LC-B: the same error three times refuses another attempt, and `next` lists the subtask as refused | pass | `EV-T-LC-B` |
| LC-C: the attempt ceiling refuses a fourth attempt, and a refused attempt keeps the rest of the call | pass | `EV-T-LC-C` |
| LC-D: rounds past the ceiling fail the check until a stop reason with an existing evidence file is recorded | pass | `EV-T-LC-D` |
| LC-E: an issue created before 2026-10-03 is judged as before | pass; shown failing with the cutoff moved back | `EV-T-LC-E` |
| LC-F: the replan ceiling refuses a third replan | pass | `EV-T-LC-F` |
| The changed check over all 309 local manifests | pass, no failure | this report |
| The full suite, on the tree that ships | pass | `EV-T-LC-D` |

## 2. Review

- Round 1 failed: `next` marked a permitted last attempt as refused and missed a repeated error after `dispatched`; a refused attempt threw away the rest of the call. Both were fixed test-first.
- Round 2 failed: the `next` help text and the protocol doc still described the old behaviour.
- Round 3 passed. Its nitpick about non-ASCII digits was fixed.

Three rounds is the review-round ceiling for this cross-cutting issue, so it lands within it.

## 3. Failure modes de-scoped at define

None.

## 4. Decisions taken for the user

- The ceilings are keyed by the assessment, not by route shape, as the caps are (`technical-design.md`).
- `subtask replan` was added, because a replan ceiling with nothing recording replans could never fail.
- The check compares counts with ceilings only for issues created on or after 2026-10-03 (ADR-006). Refusals in `compass issue subtask` apply to any issue, because they only stop future work.
- Not acted on from review: clearing a recorded stop needs a hand edit; the refusal message leads with the rule id. Neither is a defect in this change.
