# Delivery approach - run-record-edges

**Approach:** quick fix

## Assessment

| Dimension | Value | Reason |
|---|---|---|
| Risk | trivial | one function's record-keeping in a verb that landed today; no other code reads the record |
| Familiarity | brownfield-mapped | cli/compass_pkg/run_cmd.py and its tests landed in #304 |
| Size | atomic | three small edits in one module |
| Goal | delivery | (no reason given) |
| Role | engineer | (no reason given) |

## Policy rules fired

none

## Intent

INT-1: INT-1

## Scenario

RRE-1: Given an interrupted run, a run whose last session finishes the stage but breaks the runs key, or a manifest with an empty runs key, then the run record's outcome and reason match the exit code, and a run starts on the empty key.

## De-scope ledger

| Stage | Action | Reason |
|---|---|---|
| refine | collapsed | the one scenario states the whole change |
| plan | collapsed | no design decision on this size |
| breakdown | skipped | one subtask |
